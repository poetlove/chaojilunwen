package tted.EVDcm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CarWarn extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(Exception e){}
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarWarn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub	
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String carnum= request.getParameter("carnum");
		Connection con;
		Statement sql=null;
		ResultSet rs=null;	
		String warn = null;
		
		try {

			String DBurl = "jdbc:mysql://localhost/car";
			String user = "root";
			String password = "123456";
			con = DriverManager.getConnection(DBurl, user, password);
			sql = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			
			carnum = new String(carnum.getBytes("ISO-8859-1"), "UTF-8");
			String condition = "select * from carwarn where carnum= " + "'"
					+ carnum + "'";
			rs = sql.executeQuery(condition);
			
			while(rs.next()){
			     warn = rs.getString("warn");
			}
	    }
		catch(SQLException exp){}
		
        String flag0 = warn.substring(0, 1);
        if(flag0.equals("0")){
        	request.setAttribute("flag0","正常") ;    		
        }else{
        	request.setAttribute("flag0","报警") ;    		
        }
        
        String flag1 = warn.substring(1,2);
        if(flag1.equals("0")){
        	request.setAttribute("flag1","正常") ;    		
        }else{
        	request.setAttribute("flag1","报警") ;    		
        }
        String flag2 = warn.substring(2,3);
        if(flag2.equals("0")){
        	request.setAttribute("flag2","正常") ;    		
        }else{
        	request.setAttribute("flag2","报警") ;    		
        }
        String flag3 = warn.substring(3,4);
        if(flag3.equals("0")){
        	request.setAttribute("flag3","正常") ;    		
        }else{
        	request.setAttribute("flag3","报警") ;    		
        }
        String flag4 = warn.substring(4,5);
        if(flag4.equals("0")){
        	request.setAttribute("flag4","正常") ;    		
        }else{
        	request.setAttribute("flag4","报警") ;    		
        }
        
        String flag5 = warn.substring(5,6);
        if(flag5.equals("0")){
        	request.setAttribute("flag5","正常") ;    		
        }else{
        	request.setAttribute("flag5","报警") ;    		
        }
        
        String flag6 = warn.substring(6,7);
        if(flag6.equals("0")){
        	request.setAttribute("flag6","正常") ;    		
        }else{
        	request.setAttribute("flag6","报警") ;    		
        }
        
        String flag7 = warn.substring(7,8);
        if(flag7.equals("0")){
        	request.setAttribute("flag7","正常") ;    		
        }else{
        	request.setAttribute("flag7","报警") ;    		
        }
        
        String flag8 = warn.substring(8,9);
        if(flag8.equals("0")){
        	request.setAttribute("flag8","正常") ;    		
        }else{
        	request.setAttribute("flag8","报警") ;    		
        }
        
        String flag9 = warn.substring(9,10);
        if(flag9.equals("0")){
        	request.setAttribute("flag9","正常") ;    		
        }else{
        	request.setAttribute("flag9","报警") ;    		
        }
        
        String flag10 = warn.substring(10,11);
        if(flag10.equals("0")){
        	request.setAttribute("flag10","正常") ;    		
        }else{
        	request.setAttribute("flag10","报警") ;    		
        }
        
        String flag11 = warn.substring(11,12);
        if(flag11.equals("0")){
        	request.setAttribute("flag11","正常") ;    		
        }else{
        	request.setAttribute("flag11","报警") ;    		
        }
        request.getRequestDispatcher("CarWarn.jsp").forward(request, response);	
		
   }
}
