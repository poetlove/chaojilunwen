package tted.EVDcm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.rowset.CachedRowSetImpl;

import tted.EVDcm.javabean.*;

public class CarInfor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(Exception e){}
	}  
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarInfor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * 连接数据库，并根据条件显示在Carinfor.jsp的页面上
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con;
		Statement sql=null;
		ResultSet rs=null;		
		StringBuffer presentPageResult = new StringBuffer();
		CarInforShowRecord databaseBean = null;
		HttpSession session = request.getSession(true);
		
		/**
		 * 创建javabean对象
		 */
		try{
			databaseBean = (CarInforShowRecord)session.getAttribute("database");
			if(databaseBean == null)
			{
				databaseBean = new CarInforShowRecord();                    
				session.setAttribute("database", databaseBean);
			}
		}
		catch(Exception exp)
		{
			databaseBean = new CarInforShowRecord();
			session.setAttribute("database",databaseBean);
		}
		
		int showPage = databaseBean.getShowPage();                            //获取javabean中存放的当前显示页
		int pageSize = databaseBean.getPageSize();		                      //获取javabean中存放的每页显示记录数
		String carnum = request.getParameter("carnumber");	                  //获取页面提交的车牌号	
		String carnum1 = request.getParameter("carnumber1");                  //获取页面提交的车载终端号
		
		/**
		 * 连接数据库
		 */
		try {

			String DBurl = "jdbc:mysql://localhost/car";
			String user = "root";
			String password = "123456";
			con = DriverManager.getConnection(DBurl, user, password);
			sql = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			
            //判断查找一栏是否有内容及查找的记录是否存在
			if ((carnum == null || carnum == "")
					&& (carnum1 == null || carnum1 == "")) {
				rs = sql.executeQuery("select * from carinfo");
			} else if ((carnum == null || carnum == "")) {
				String condition = "select * from carinfo where carnum1= "
						+ "'" + carnum1 + "'";
				rs = sql.executeQuery(condition);
				if (rs.next() == false) {
					request.setAttribute("message", "记录不存在");
					rs = sql.executeQuery("select * from carinfo");
				} else {
					rs = sql.executeQuery(condition);
				}
			} else if (carnum != null || carnum != " ") {
				carnum = new String(carnum.getBytes("ISO-8859-1"), "UTF-8");
				String condition = "select * from carinfo where carnum= " + "'"
						+ carnum + "'";
				rs = sql.executeQuery(condition);
				if (rs.next() == false) {
					request.setAttribute("message", "记录不存在");
					rs = sql.executeQuery("select * from carinfo");
				} else {
					rs = sql.executeQuery(condition);
				}
			}
	        
	        CachedRowSetImpl rowSet = new CachedRowSetImpl();                  //创建行集对象
	        rowSet.populate(rs);                                               //从数据库中读取的记录存入行集对象
	        con.close();                                                       //关闭数据库
	        databaseBean.setRowSet(rowSet);                                    //数据存储在databaseBean中	        
	        rowSet.last();
	        int m = rowSet.getRow();                                           //获得总行数
	        int n = pageSize;
	        int pageAllCount = ((m % n) == 0)?(m/n):(m/n+1);                   //计算分页后总页数
	        databaseBean.setPageAllCount(pageAllCount);                        //数据存储在javabean中
	        	        
	    }
		catch(SQLException exp){}
		
		/**
		 * 获取页面提交信息，控制跳转页面
		 */
		String whichPage = request.getParameter("whichPage");                   //获取上一页下一页                 
		String toPage = request.getParameter("ToPage");                         //获取要跳转到的指定页数
		
        //跳转页面		
		if(toPage != null) {      			                                                                         
			showPage=Integer.parseInt(toPage);                                  //取得指定显示的分页页数 
			databaseBean.setShowPage(showPage);                                 //存入javabean
			CachedRowSetImpl rowSet = databaseBean.getRowSet();
			
			//下面的语句判断用户输入的页数是否正确
			if(rowSet != null){
				if(showPage>=databaseBean.getPageAllCount()) {       
					showPage=databaseBean.getPageAllCount();
					databaseBean.setShowPage(showPage);
				}      
				else if(showPage<=0) {       
					showPage=1;
					databaseBean.setShowPage(showPage);
				 }
			presentPageResult = show(showPage,pageSize,rowSet);
			databaseBean.setPresentPageResult(presentPageResult);
		    }
		}
		
		//处理上一页和下一页
		if(whichPage == null || whichPage.length() == 0)
		{
			showPage = 1;
			databaseBean.setShowPage(showPage);
			CachedRowSetImpl rowSet = databaseBean.getRowSet();
			if(rowSet !=null)				
			{
				presentPageResult = show(showPage,pageSize,rowSet);
				databaseBean.setPresentPageResult(presentPageResult);
			}
		}
		else if(whichPage.equals("nextPage"))
		{
			showPage++;
			if(showPage > databaseBean.getPageAllCount())
				showPage = 1;
			databaseBean.setShowPage(showPage);
			CachedRowSetImpl rowSet = databaseBean.getRowSet();
			if(rowSet != null)
			{
				presentPageResult = show(showPage,pageSize,rowSet);
				databaseBean.setPresentPageResult(presentPageResult);
			}
		}
		else if(whichPage.equals("previousPage"))
		{
			showPage--;
			if(showPage <= 0)
				showPage = databaseBean.getPageAllCount();
			databaseBean.setShowPage(showPage);
			CachedRowSetImpl rowSet = databaseBean.getRowSet();
			if(rowSet != null)
			{
				presentPageResult = show(showPage,pageSize,rowSet);
				databaseBean.setPresentPageResult(presentPageResult);
			}
		}
		databaseBean.setPresentPageResult(presentPageResult);
		
		//请求Carinfor显示数据
		RequestDispatcher dispatcher = request.getRequestDispatcher("Carinfor.jsp");
		dispatcher.forward(request, response);                                     
	}
	
	/**
	 * 根据传入的参数显示数据
	 */
	public StringBuffer show(int page,int pageSize,CachedRowSetImpl rowSet)
	{
		StringBuffer str = new StringBuffer();
		try{
			rowSet.absolute((page - 1)*pageSize+1);                                    //计算每页起始记录位置
			//循环显示车牌号，车载终端号及状态
			for(int i= 1;i <= pageSize;i++)
			{					
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 style=color:#4682B4><a href= moreinfor?carnum="+rowSet.getString("carnum")+">" +rowSet.getString("carnum") + "</a></td>");
				str.append("<td background-color:#F5F5F5>" +rowSet.getString("carnum1") + "</td>");
				str.append("<td background-color:#F5F5F5>" +rowSet.getString("status") + "</td>");
				str.append("</tr>");
				
				if(!rowSet.next()){        
				      //跳出for循环       
				      break; 
				 }
			}
		}
		catch(SQLException exp){}
		return str;
	}

}
