package tted.EVDcm.javabean;

public class CarWarn_ShowRecord {
	
	StringBuffer presentPageResult; 
	public void setPresentPageResult(StringBuffer p)
	{
		presentPageResult = p;
	}
	public StringBuffer getPresentPageResult()
	{
		return presentPageResult;
	}


}
