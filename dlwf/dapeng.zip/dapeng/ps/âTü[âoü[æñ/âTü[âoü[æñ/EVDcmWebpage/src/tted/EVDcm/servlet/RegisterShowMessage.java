package tted.EVDcm.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RegisterShowMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
	}

    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterShowMessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//获取用户输入的内容
		response.setContentType("text/html;charset=GB2312");
		PrintWriter out=response.getWriter();
		String name = request.getParameter("name");
		String Email = request.getParameter("Email");
		
		try{
			byte bb[] = name.getBytes("ISO-8859-1");
			name = new String(bb,"gb2312");			
		}
		catch(Exception exp){}
		out.print("<Font color = blue size= 4>your name:");
		out.print(name);
		out.print("<BR><Font color = blue size = 3>your Email:");
		out.print(Email);
		out.print("<BR>恭喜您!注册成功!");
		out.print("<BR>5秒后跳转到登陆页面!");
		response.addHeader ("refresh", "5;URL=Login.jsp");
		 
	}

}