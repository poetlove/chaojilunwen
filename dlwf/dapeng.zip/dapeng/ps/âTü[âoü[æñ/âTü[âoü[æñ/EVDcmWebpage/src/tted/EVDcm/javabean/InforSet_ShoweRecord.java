package tted.EVDcm.javabean;

public class InforSet_ShoweRecord {

	StringBuffer presentPageResult; 
	public void setPresentPageResult(StringBuffer p)
	{
		presentPageResult = p;
	}
	public StringBuffer getPresentPageResult()
	{
		return presentPageResult;
	}

}
