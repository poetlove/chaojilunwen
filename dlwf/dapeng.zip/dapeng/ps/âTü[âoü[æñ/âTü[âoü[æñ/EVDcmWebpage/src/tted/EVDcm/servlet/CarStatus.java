package tted.EVDcm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tted.EVDcm.javabean.*;


public class CarStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(Exception e){}
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
 	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		Connection con;
		Statement sql=null;
		ResultSet rs=null;	
		String flag = request.getParameter("flag");
		String carnum= request.getParameter("carnum");
		
		if(flag == null || flag == ""){
			carnum = new String(carnum.getBytes("ISO-8859-1"), "UTF-8");
		}
		StringBuffer presentPageResult = new StringBuffer();
		CarStatusShowRecord carstatusbean = null;
		HttpSession session = request.getSession(true);
		
		/**
		 * 创建javabean对象
		 */
		try{
			carstatusbean = (CarStatusShowRecord)session.getAttribute("carstatus");
			if(carstatusbean == null)
			{
				carstatusbean = new CarStatusShowRecord();                    
				session.setAttribute("carstatus", carstatusbean);
			}
		}
		catch(Exception exp)
		{
			carstatusbean = new CarStatusShowRecord();
			session.setAttribute("carstatus",carstatusbean);
		}		
		try {

			String DBurl = "jdbc:mysql://localhost/car";
			String user = "root";
			String password = "123456";
			con = DriverManager.getConnection(DBurl, user, password);
			sql = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
//			carnum = new String(carnum.getBytes("ISO-8859-1"), "UTF-8");
			String condition = "select * from carstatus where carnum= " + "'"
					+ carnum + "'";
			rs = sql.executeQuery(condition);
	        presentPageResult = show(rs);
	        carstatusbean.setPresentPageResult(presentPageResult);
	        request.setAttribute("carnum",carnum);
			RequestDispatcher dispatcher = request.getRequestDispatcher("CarStatus.jsp");
			dispatcher.forward(request, response);      
			}	    
		catch(SQLException exp){}
	}
	
	public StringBuffer show(ResultSet rs)
	{
		StringBuffer str = new StringBuffer();
		try{			
			while(rs.next()){				
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5>单体蓄电池电压</td>");
				str.append("<td background-color:#F5F5F5 colspan=2 style=color:#4682B4 >" +rs.getString("voltage") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5>动力蓄电池温度</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 colspan=2>" +rs.getString("temperature") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 rowspan=3>整车数据</td>");
				str.append("<td background-color:#F5F5F5 class=left>车速:</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("drive") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 class=left>里程:</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("mileage") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 class=left>档位:</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("gear") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 rowspan=6>极值数据</td>");
				str.append("<td background-color:#F5F5F5 class=left>最高电压动力蓄电池单体所在电池包序号</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("snum") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 class=left>最高电压单体蓄电池序号</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("vnum") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 class=left>电池单体电压最高值</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("max") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 class=left>最低电压动力蓄电池包序</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("order") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 class=left>SOC</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("soc") + "</td>");
				str.append("</tr>");
				str.append("<tr>");				  
				str.append("<td background-color:#F5F5F5 class=left>最低温度值</td>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4>" +rs.getString("min") + "</td>");
				str.append("</tr>");
			}
		}
		catch(SQLException exp){}
		return str;
	}

}
