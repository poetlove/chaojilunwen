package tted.EVDcm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class InforSet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(Exception e){}
	}  
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InforSet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String flag = request.getParameter("flag");
		String carnum= request.getParameter("carnum");
		
		PrintWriter out=response.getWriter();
		String storagetime= request.getParameter("storagetime");
		String normaltime= request.getParameter("normaltime");
		String alarmtime= request.getParameter("alarmtime");
		String heartbeat= request.getParameter("heartbeat");
		String terminal= request.getParameter("terminal");
		String platform= request.getParameter(" platform");
		
		if(flag == null || flag == ""){
			carnum = new String(carnum.getBytes("ISO-8859-1"), "UTF-8");
		}
		Connection con;
		Statement sql=null;
		ResultSet rs=null;
		try {

			String DBurl = "jdbc:mysql://localhost/car";
			String user = "root";
			String password = "123456";
			con = DriverManager.getConnection(DBurl, user, password);
			sql = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE ,
					ResultSet.CONCUR_UPDATABLE);
			
			out.print(carnum);
			if ((storagetime != null && storagetime != "") && (normaltime != null && normaltime != "") 
					&& (alarmtime != null && alarmtime != "") && (heartbeat != null && heartbeat != "") 
					&& (terminal != null && terminal != "") && (platform != null && platform != "")){
				String condition="UPDATE set SET storagetime= '"+storagetime+"'"+" normaltime= "+"'"+normaltime+"'"+" alarmtime= "+"'"+alarmtime+"'"
						+" heartbeat= "+"'"+heartbeat+"'"+" terminal= "+"'"+terminal+"'"+" platform= "+"'"+platform+"' where carnum= " + "'"
			            + carnum + "'";
                sql.executeUpdate(condition);
			}
			
			String condition1 = "select * from set where carnum= " + "'"+ carnum + "'";
			rs = sql.executeQuery(condition1);
			while(rs.next()){
				out.print("!!!");
				storagetime = rs.getString("storagetime");
				normaltime =rs.getString("normaltime");
				alarmtime= rs.getString("alarmtime");
				out.print(alarmtime);
				heartbeat= rs.getString("heartbeat");
				terminal= rs.getString("terminal");
				platform= rs.getString("terminal");
				String port = rs.getString("port");
				String IP = rs.getString("IP");
				String hardwareVersion = rs.getString("hardwareVersion");
				String firmwareVersion = rs.getString("firmwareVersion");
				request.setAttribute("storagetime",storagetime);
				request.setAttribute("normaltime",normaltime);
				request.setAttribute("alarmtime",alarmtime);
				request.setAttribute("heartbeat",heartbeat);
				request.setAttribute("terminal",terminal);
				request.setAttribute("platform",platform);
				request.setAttribute("port",port);
				request.setAttribute("IP",IP);
				request.setAttribute("hardwareVersion",hardwareVersion);
				request.setAttribute("firmwareVersion",firmwareVersion);
			}
	    }
		catch(SQLException exp){}
		request.setAttribute("carnum",carnum);
		request.getRequestDispatcher("InforSet.jsp").forward(request, response);	
	}

}
