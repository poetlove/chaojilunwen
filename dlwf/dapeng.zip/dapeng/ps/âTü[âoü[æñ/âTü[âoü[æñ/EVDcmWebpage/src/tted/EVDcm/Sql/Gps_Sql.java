package tted.EVDcm.Sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Gps_Sql {
	protected static Connection conn = null;
	protected static String user = "root";
	protected static String password = "123456";
	protected static String url = "jdbc:mysql://localhost/car";
	protected static String Driver = "com.mysql.jdbc.Driver";

	public static Connection getConnection() {
		try {
			Class.forName(Driver);
			conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	public static void getRelease(Connection conn, PreparedStatement pstat, ResultSet res) {
		try {
			if (res != null)
				res.close();
			if (pstat != null)
				pstat.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
