package tted.EVDcm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class MoreInfor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(Exception e){}
	}
       
    public MoreInfor() {
        super();
    
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// TODO Auto-generated method stub
	    //获取点击Carinfor页面链接后的车牌号
		String carnum1 = null;
		String status = null;
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String carnum= request.getParameter("carnum");
		
        //连接数据库，查询该车牌号对应的车载终端号和状态
		ResultSet rs = null;		
		Connection conn = null;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              				
		Statement sql=null;		
		try {
			String DBurl = "jdbc:mysql://localhost/car";
			String user = "root";
			String password = "123456";
			conn = DriverManager.getConnection(DBurl, user, password);		
			sql = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			carnum = new String(carnum.getBytes("ISO-8859-1"), "UTF-8");
			String condition = "select * from carinfo where carnum= " + "'"+ carnum + "'";
			rs = sql.executeQuery(condition);
			while(rs.next()){
			carnum1 = rs.getString("carnum1");			
			status = rs.getString("status");			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		//发送查询结果到MoreInfor页面
		request.setAttribute("carnum1", carnum1);
		request.setAttribute("status", status);		
		request.setAttribute("carnum", carnum);		
    	request.getRequestDispatcher("MoreInfor.jsp").forward(request, response);
		
	}
}
