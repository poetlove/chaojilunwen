package tted.EVDcm.servlet;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
	}

    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}
	
	/**
	 * 验证用户
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  //获取jsp页面的输入内容 
		    String name=new String();
		    name=request.getParameter("name");                                         //获取页面提交的用户名
		    String psw=new String();
		    psw=request.getParameter("password");                                      //获取页面提交的密码

		  //连接数据库
			try{       
				String Driver = "com.mysql.jdbc.Driver";    
				String DBurl = "jdbc:mysql://localhost/car";    
				String user = "root";    
				String password = "123456";
				Connection con=null; 
				ResultSet rs=null;
				Statement sql=null;
		        try {
					Class.forName(Driver);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}       
		        con=DriverManager.getConnection(DBurl,user,password);
		        sql=con.createStatement();
		        
		        //查询数据库中是否存在获取的用户
		        String condition="select * from user where name= "+"'"+name+"'"+" and password= "+"'"+psw+"'";
		        rs=sql.executeQuery(condition);
		        if(rs.next()==false)
		          {
		        	request.setAttribute("message", "用户名或密码错误");
		        	request.getRequestDispatcher("Login.jsp").forward(request, response);}
		        else {response.sendRedirect("databaseRecord");}			    
		        con.close();
		        }
		    catch(SQLException e){
		    	System.out.println(e.getMessage());
		    }
	}
}


