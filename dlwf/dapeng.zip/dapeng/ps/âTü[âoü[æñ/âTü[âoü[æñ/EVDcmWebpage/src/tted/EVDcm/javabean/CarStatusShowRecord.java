package tted.EVDcm.javabean;

import com.sun.rowset.CachedRowSetImpl;

public class CarStatusShowRecord {
	
	StringBuffer presentPageResult; 
	public void setPresentPageResult(StringBuffer p)
	{
		presentPageResult = p;
	}
	public StringBuffer getPresentPageResult()
	{
		return presentPageResult;
	}

}
