/*************************************************************************
 **
 * File Name		RealTimeDataPacket.java
 * File Summary		DCMからのリアルタイムデータの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import tted.evdcm.server.utils.Common;

public class RealTimeDataPacket {
	/* データ採集時間 */
	String mDateTime;
	/* リアルタイムデータ */
	byte[] mData;

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public void setData(byte[] data) {
		mData = data;
	}

	public byte[] getData() {
		return mData;
	}

	/**
	 * 配列のデータをRealTimeDataPacket型のバックに変更
	 * 
	 * @param byteStream
	 *            含むRealTimeDataPacket情報の配列.
	 * @return 配列操作が正確時RealTimeDataPacket実例を返し、でなければnullを返し
	 */
	static public RealTimeDataPacket fromBytesToPacket(byte[] byteStream) {
		if(byteStream == null || byteStream.length < 6) {
			return null;
		}
		
		RealTimeDataPacket realTimeDataPacket = new RealTimeDataPacket();

		byte[] dt = new byte[6];
		Common.memcpy(dt, 0, byteStream, 0, dt.length);
		realTimeDataPacket.mDateTime = Common.dateTimeFromBytes(dt);

		byte[] data = new byte[byteStream.length - dt.length];
		Common.memcpy(data, 0, byteStream, dt.length, data.length);
		realTimeDataPacket.mData = data;

		return realTimeDataPacket;

	}
}
