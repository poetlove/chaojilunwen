/*************************************************************************
 **
 * File Name		RealTimeAlarmData.java
 * File Summary		DCMからのリアルタイムアラームデータの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class RealTimeAlarmData {
	/* 電池のアラーム標識ビットマスク：温度差異 */
	public static final int MSK_TEMPERATURE_DIFF = 0x0001;
	/* 電池のアラーム標識ビットマスク：電池極柱高温アラーム */
	public static final int MSK_BATTERY_POLE_HIGH_TEMPERATURE = 0x0002;
	/* 電池のアラーム標識ビットマスク：電池バック過電圧アラーム */
	public static final int MSK_BATTERY_PACK_HIGH_VOLTAGE = 0x0004;
	/* 電池のアラーム標識ビットマスク：電池バック低電圧アラーム */
	public static final int MSK_BATTERY_PACK_LOW_VOLTAGE = 0x0008;
	/* 電池のアラーム標識ビットマスク：SOC低アラーム */
	public static final int MSK_LOW_SOC = 0x0010;
	/* 電池のアラーム標識ビットマスク：電池過電圧アラーム */
	public static final int MSK_BATTERY_HIGH_VOLTAGE = 0x0020;
	/* 電池のアラーム標識ビットマスク：電池低電圧アラーム */
	public static final int MSK_BATTERY_LOW_VOLTAGE = 0x0040;
	/* 電池のアラーム標識ビットマスク：SOC低すぎるアラーム */
	public static final int MSK_TOO_LOW_SOC = 0x0080;
	/* 電池のアラーム標識ビットマスク：SOC高すぎるアラーム */
	public static final int MSK_HIGH_SOC = 0x0100;
	/* 電池のアラーム標識ビットマスク：電池バック不整合アラーム */
	public static final int MSK_BATTERY_PACK_UNMATCH = 0x0200;
	/* 電池のアラーム標識ビットマスク：電池の一貫性が悪い */
	public static final int MSK_BATTERY_POOR_CONSISTENCY = 0x0400;
	/* 電池のアラーム標識ビットマスク：絶縁故障 */
	public static final int MSK_INSULATION_FAULT = 0x0800;
	
	/* 車両ナンバー */
	String mCarNumber;
	/* データ採集時間 */
	String mDateTime;

	/* 情報タイプマーク */
	int mInfoTypeFlag = 0x06;

	/* 動力バッテリー警報マーク */
	int mBatteryAlarmFlag;
	/* 動力バッテリー他の故障数n */
	int mBatteryOtherFaultsCnt;
	/* 動力バッテリー他の故障コード */
	ArrayList<Integer> mBatteryOtherFaultCodes;
	/* 電機故障数N */
	int mMotorFaultsCnt;
	/* 電機故障コード */
	ArrayList<Integer> mMotorFaultCodes;
	/* 他の故障数M */
	int mOtherFaultsCnt;
	/* 他の故障コード */
	ArrayList<Integer> mOtherFaultCodes;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getInfoTypeFlag() {
		return mInfoTypeFlag;
	}

	public void setBatteryAlarmFlag(int value) {
		mBatteryAlarmFlag = value;
	}

	public void setBatteryOtherFaultsCnt(int value) {
		mBatteryOtherFaultsCnt = value;
	}

	public void setBatteryOtherFaultCodes(ArrayList<Integer> value) {
		mBatteryOtherFaultCodes = value;
	}

	public void setMotorFaultsCnt(int value) {
		mMotorFaultsCnt = value;
	}

	public void setMotorFaultCodes(ArrayList<Integer> value) {
		mMotorFaultCodes = value;
	}

	public void setOtherFaultsCnt(int value) {
		mOtherFaultsCnt = value;
	}

	public void setOtherFaultCodes(ArrayList<Integer> value) {
		mOtherFaultCodes = value;
	}

	public int getBatteryAlarmFlag() {
		return mBatteryAlarmFlag;
	}

	public int getBatteryOtherFaultsCnt() {
		return mBatteryOtherFaultsCnt;
	}

	public ArrayList<Integer> getBatteryOtherFaultCodes() {
		return mBatteryOtherFaultCodes;
	}

	public int getMotorFaultsCnt() {
		return mMotorFaultsCnt;
	}

	public ArrayList<Integer> getMotorFaultCodes() {
		return mMotorFaultCodes;
	}

	public int getOtherFaultsCnt() {
		return mOtherFaultsCnt;
	}

	public ArrayList<Integer> getOtherFaultCodes() {
		return mOtherFaultCodes;
	}

	/**
	 * 配列のデータをRealTimeAlarmData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param dateTime
	 *            データの採取時間.
	 * @param byteStream
	 *            含むParamSetData情報の配列.
	 * @param offset
	 *            byteStream配列の位置ずれ.
	 * @return 配列操作が正確時RealTimeAlarmData実例を返し、でなければnullを返し
	 */
	static public RealTimeAlarmData fromBytesToPacket(String carNumber,String dateTime,
			byte[] byteStream, int offset) {
		RealTimeAlarmData rtad = new RealTimeAlarmData();

		rtad.mCarNumber = carNumber;
		rtad.mDateTime = dateTime;

		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			dataInputStream.skipBytes(offset);
			rtad.mInfoTypeFlag = Common.byteToInt(dataInputStream.readByte());

			rtad.mBatteryAlarmFlag = dataInputStream.readShort();
			rtad.mBatteryOtherFaultsCnt = Common.byteToInt(dataInputStream.readByte());
			if (rtad.mBatteryOtherFaultsCnt > 0) {
				rtad.mBatteryOtherFaultCodes = new ArrayList<Integer>();
				for (int i = 0; i < rtad.mBatteryOtherFaultsCnt; i++) {
					rtad.mBatteryOtherFaultCodes.add(Common.byteToInt(dataInputStream
							.readByte()));
				}
			}
			rtad.mMotorFaultsCnt = Common.byteToInt(dataInputStream.readByte());
			if (rtad.mMotorFaultsCnt > 0) {
				rtad.mMotorFaultCodes = new ArrayList<Integer>();
				for (int i = 0; i < rtad.mMotorFaultsCnt; i++) {
					rtad.mMotorFaultCodes.add(Common.byteToInt(dataInputStream.readByte()));
				}
			}
			rtad.mOtherFaultsCnt = Common.byteToInt(dataInputStream.readByte());
			if (rtad.mOtherFaultsCnt > 0) {
				rtad.mOtherFaultCodes = new ArrayList<Integer>();
				for (int i = 0; i < rtad.mOtherFaultsCnt; i++) {
					rtad.mOtherFaultCodes.add(Common.byteToInt(dataInputStream.readByte()));
				}
			}

			return rtad;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * RealTimeAlarmData型のバックは使ったバイト数を計算
	 * 
	 * @param null
	 *            
	 * @return RealTimeAlarmData型のバックは使ったバイト数
	 */
	public int getDataInfoStructLength() {
		int len = 1;

		len += 2;
		len += 1;
		len += mBatteryOtherFaultsCnt;
		len += 1;
		len += mMotorFaultsCnt;
		len += 1;
		len += mOtherFaultsCnt;

		return len;
	}

}
