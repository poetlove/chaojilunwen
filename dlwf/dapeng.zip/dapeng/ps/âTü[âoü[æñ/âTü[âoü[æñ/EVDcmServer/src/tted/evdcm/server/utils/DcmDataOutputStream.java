/*************************************************************************
 **
 * File Name		DcmDataOutputStream.java
 * File Summary		データ出力ストリーム許可アプリケーションは適当な方式で
 *                  基本的にJavaデータを出力ストリームに書き込みタイプ。
 *                  そして、アプリケーションが使用データ入力ストリームにデータを読み込む
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.utils;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class DcmDataOutputStream {
	/* java提供の基本的なタイプのデータ出力ストリーム変数 */
	DataOutputStream mDataOutputStream;
	/* バイト流の順序変数 */
	boolean mNetWorkOrder = true;

	/**
	 * データ出力ストリームの創建と初期化.
	 * 
	 * @param out
	 *            出力ストリーム
	 * @return null
	 */
	public DcmDataOutputStream(OutputStream out) {
		mDataOutputStream = new DataOutputStream(out);
	}

	/**
	 * データ出力ストリームの創建と初期化.
	 * 
	 * @param out
	 *            出力ストリーム
	 * @param netWorkOrder
	 *            バイト流の使う順序
	 * @return null
	 */
	public DcmDataOutputStream(OutputStream out, boolean netWorkOrder) {
		mDataOutputStream = new DataOutputStream(out);
		mNetWorkOrder = netWorkOrder;
	}
	
	/**
	 * 整数を配列に入れ、低位データが低く位バイトを入れ、高位デートが高めるバイトを入れ
	 * 
	 * @param n
	 *            処理の整数
	 * @return 保存する整数の配列
	 */
	public static byte[] intToLH(int n) {
		byte[] b = new byte[4];
		
		b[0] = (byte) (n & 0xff);
		b[1] = (byte) ((n >> 8) & 0xff);
		b[2] = (byte) ((n >> 16) & 0xff);
		b[3] = (byte) ((n >> 24) & 0xff);
		
		return b;
	}
	
	/**
	 * char型数を配列に入れ、低位データが低く位バイトを入れ、高位デートが高めるバイトを入れ
	 * 
	 * @param n
	 *            処理のchar型数
	 * @return 保存するchar型数の配列
	 */
	public static byte[] charToLH(char n) {
		byte[] ret = new byte[2];
		
		ret[0] = (byte)(n & 0xff) ;
		ret[1] = (byte)((n >> 8) & 0xff) ;

		return ret;
	}
	
	/**
	 * short型数を配列に入れ、低位データが低く位バイトを入れ、高位デートが高めるバイトを入れ
	 * 
	 * @param n
	 *            処理のshort型数
	 * @return 保存するshort型数の配列
	 */ 
	public static byte[] shortToLH(int n) {
	   byte[] b = new byte[2];
	   
	   b[0] = (byte) (n & 0xff);
	   b[1] = (byte) ((n >> 8) & 0xff);
	   
	   return b;
	 } 
	
	/**
	 * long型数を配列に入れ、低位データが低く位バイトを入れ、高位デートが高めるバイトを入れ
	 * 
	 * @param n
	 *            処理のlong型数
	 * @return 保存するlong型数の配列
	 */ 
	public static byte[] longToLH(long n) {
		byte[] b = new byte[8];
		
		b[0] = (byte) (n & 0xff);
		b[1] = (byte) ((n >> 8) & 0xff);
		b[2] = (byte) ((n >> 16) & 0xff);
		b[3] = (byte) ((n >> 24) & 0xff);
		b[4] = (byte) ((n >> 32) & 0xff);
		b[5] = (byte) ((n >> 40) & 0xff);
		b[6] = (byte) ((n >> 48) & 0xff);
		b[7] = (byte) ((n >> 56) & 0xff);
		
		return b;
	}
    


	/**
	 * バイト配列のデータをリバース
	 * 
	 * @param b
	 *            バイト配列
	 * @param off
	 *            バイト配列bのスタートオフセット量    
	 * @param len
	 *            処理の最大バイト数      
	 * @return 交換後のバイト配列
	 */
	public static byte[] bytesReverseOrder(byte[] b, int off, int len) {
		byte[] result = new byte[len];
		
		for (int i = 0; i < len; i++) {
			result[len - i - 1] = b[i + off];
		}
		return result;
	}
	
	/**
	 * データ出力ストリームをクリア。このようにすべての緩衝の出力バイトれ流に書く
	 * 
	 * @param null
	 *           
	 * @return null
	 */
	public final void flush() throws IOException {
		mDataOutputStream.flush();
	}

	/**
	 * データ出力ストリームのバイト数を獲得
	 * 
	 * @param null
	 *           
	 * @return データ出力ストリームのバイト数
	 */
	public final int size() {
		return mDataOutputStream.size();
	}

	/**
	 * 出力ストリームに指定byte配列からオフセットoffからのlenバイトを書き込み。
	 * 
	 * @param b
	 *            データ
	 * @param off
	 *            データの中のスタートオフセット量
	 * @param len
	 *            書き込む最大バイト数          
	 * @return null
	 */
	public final void write(byte[] b, int off, int len) throws IOException {
		if (mNetWorkOrder) {
			mDataOutputStream.write(b, off, len);
		} else {
			byte[] byteAr = bytesReverseOrder(b, off, len);
			mDataOutputStream.write(byteAr, off, len);
		}
	}

	/**
	 * 出力ストリームに指定数の低位8つのビットを書き込み。
	 * 
	 * @param b
	 *            書き込みデータ           
	 * @return null
	 */
	public final void write(int b) throws IOException {
			mDataOutputStream.write(b);
	}

	/**
	 * 出力ストリームに1つのビット（true: 1, false: 0）を書き込み。
	 * 
	 * @param v
	 *            書き込みboolean値           
	 * @return null
	 */
	public final void writeBoolean(boolean v) throws IOException {
		mDataOutputStream.writeBoolean(v);
	}

	/**
	 * 出力ストリームに指定数の低位8つのビットを書き込み。
	 * 
	 * @param v
	 *            書き込みデータ           
	 * @return null
	 */
	public final void writeByte(int v) throws IOException {
			mDataOutputStream.writeByte(v);
	}

	/**
	 * 出力ストリームにバイトの順序に従って文字列を書き込み。
	 * 
	 * @param s
	 *            書き込み文字列           
	 * @return null
	 */
	public final void writeBytes(String s) throws IOException {
		mDataOutputStream.writeBytes(s);
	}

	/**
	 * 出力ストリームに一つのchar値（2-byte値）フォーマットを書き込み、先に書き込み高バイト
	 * 
	 * @param v
	 *            書き込みchar値           
	 * @return null
	 */
	public final void writeChar(int v) throws IOException {
		if (mNetWorkOrder) {
			mDataOutputStream.writeChar(v);
		} else {
			byte[] byteAr = charToLH((char) v);
			mDataOutputStream.write(byteAr,0,2);
		}
	}

	/**
	 * 出力ストリームに一つのdouble値（8-byte値）フォーマットを書き込み、先に書き込み高バイト
	 * 
	 * @param v
	 *            書き込みdouble値           
	 * @return null
	 */
	public final void writeDouble(double v) throws IOException {
			mDataOutputStream.writeDouble(v);
	}

	/**
	 * 出力ストリームに一つのfloat値（4-byte値）フォーマットを書き込み、先に書き込み高バイト
	 * 
	 * @param v
	 *            書き込みfloat値           
	 * @return null
	 */
	public final void writeFloat(float v) throws IOException {
			mDataOutputStream.writeFloat(v);
	}

	/**
	 * 出力ストリームに一つの整数値（4-byte値）フォーマットを書き込み、先に書き込み高バイト
	 * 
	 * @param v
	 *            書き込み整数値           
	 * @return null
	 */
	public final void writeInt(int v) throws IOException {
		if (mNetWorkOrder) {
			mDataOutputStream.writeInt(v);
		} else {
			mDataOutputStream.write(intToLH(v),0,4);
		}
	}

	/**
	 * 出力ストリームに一つのlong値（8-byte値）フォーマットを書き込み、先に書き込み高バイト
	 * 
	 * @param v
	 *            書き込みlong値           
	 * @return null
	 */
	public final void writeLong(long v) throws IOException {
		if (mNetWorkOrder) {
			mDataOutputStream.writeLong(v);
		} else {
			mDataOutputStream.write(longToLH(v),0,8);
		}
	}

	/**
	 * 出力ストリームに一つのshort値（2-byte値）フォーマットを書き込み、先に書き込み高バイト
	 * 
	 * @param v
	 *            書き込みshort値           
	 * @return null
	 */
	public final void writeShort(int v) throws IOException {
		if (mNetWorkOrder) {
			mDataOutputStream.writeShort(v);
		} else {
			byte[] byteAr = shortToLH(v);
			mDataOutputStream.write(byteAr,0,2);
		}
	}
	
	/**
	 * このデータ出力ストリームをクロス.
	 * 
	 * @param null
	 *            
	 * @return null
	 */
	public void close() throws IOException  {
		mDataOutputStream.close();
	}
}
