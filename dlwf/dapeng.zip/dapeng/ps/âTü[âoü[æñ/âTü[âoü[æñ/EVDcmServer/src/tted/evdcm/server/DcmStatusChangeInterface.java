package tted.evdcm.server;

public interface DcmStatusChangeInterface {
	// 当登录的车辆与服务器断开连接时调用此接口
		public void callOutLine();
}
