/*************************************************************************
 **
 * File Name		RegistData.java
 * File Summary		DCMからの登録データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class RegistData {
	/* 登録の時間 */
	String mDateTime;
	/* 登録通し番号 */
	int mRegistSerialNumber;
	/* 車両ナンバー */
	String mCarNumber;

	// String mCarTerminalNumber;
	/* 車載端末番号 メーカーのコード */
	String mMakerCode;
	/* 車載端末番号 端末ロット */
	String mTerminalNumber;
	/* 車載端末番号 通し番号 */
	int mSerialNumber;

	/* 動力バッテリーパック数N */
	int mBatteryPackCount;
	/* 動力バッテリーパック表 */
	ArrayList<BatteryPacket> mBatteryPackets;
	/* リザーブ */
	byte[] mReserve;

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public void setRegistSerialNumber(int num) {
		mRegistSerialNumber = num;
	}

	public int getRegistSerialNumber() {
		return mRegistSerialNumber;
	}

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	// public void setCarTerminalNumber(String num) {
	// mCarTerminalNumber = num;
	// }
	// public String getCarTerminalNumber() {
	// return mCarTerminalNumber;
	// }
	public void setMakerCode(String v) {
		mMakerCode = v;
	}

	public String getMakerCode() {
		return mMakerCode;
	}

	public void setTerminalNumber(String v) {
		mTerminalNumber = v;
	}

	public String getTerminalNumber() {
		return mTerminalNumber;
	}

	public void setSerialNumber(int v) {
		mSerialNumber = v;
	}

	public int getSerialNumber() {
		return mSerialNumber;
	}

	public void setBatteryPackCount(int cnt) {
		mBatteryPackCount = cnt;
	}

	public int getBatteryPackCount() {
		return mBatteryPackCount;
	}

	public void setBatteryPackets(ArrayList<BatteryPacket> abp) {
		mBatteryPackets = abp;
	}

	public ArrayList<BatteryPacket> getBatteryPackets() {
		return mBatteryPackets;
	}

	/**
	 * 配列のデータをRegistData型のバックに変更
	 * 
	 * @param byteStream
	 *            含むRegistData情報の配列.
	 * @return 配列操作が正確時RegistData実例を返し、でなければnullを返し
	 */
	static public RegistData fromBytesToPacket(byte[] byteStream) {
		RegistData registData = new RegistData();
		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			registData.mDateTime = Common.dateTimeFromBytes(dt);
			registData.mRegistSerialNumber = dataInputStream.readShort();

			byte[] carNumber = new byte[8];
			dataInputStream.read(carNumber, 0, carNumber.length);
			registData.mCarNumber = Common.strFromBytes(carNumber);

			byte[] carTerminalNumber = new byte[4];
			dataInputStream
					.read(carTerminalNumber, 0, carTerminalNumber.length);
			registData.mMakerCode = Common.strFromBytes(carTerminalNumber);

			carTerminalNumber = new byte[6];
			dataInputStream
					.read(carTerminalNumber, 0, carTerminalNumber.length);
			registData.mTerminalNumber = Common.strFromBytes(carTerminalNumber);

			registData.mSerialNumber = dataInputStream.readShort();

			registData.mBatteryPackCount = Common.byteToInt(dataInputStream.readByte());

			int len = byteStream.length;
			int size = 6 + 2 + 8 + 12 + 1 + 20 * registData.mBatteryPackCount
					+ 11;
			if (len != size) {
				return null;
			}
			if (registData.mBatteryPackCount > 0) {
				registData.mBatteryPackets = new ArrayList<BatteryPacket>();
				for (int i = 0; i < registData.mBatteryPackCount; i++) {
					byte[] batteryBuf = new byte[20];
					dataInputStream.read(batteryBuf, 0, batteryBuf.length);
					BatteryPacket bp = BatteryPacket
							.fromBytesToPacket(batteryBuf);
					registData.mBatteryPackets.add(bp);
				}
			} else {
				registData.mBatteryPackets = null;
			}

			return registData;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
