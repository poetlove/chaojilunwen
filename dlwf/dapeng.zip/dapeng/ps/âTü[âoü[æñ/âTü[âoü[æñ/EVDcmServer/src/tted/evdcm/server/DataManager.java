/*************************************************************************
 **
 * File Name		DataManager.java
 * File Summary		受信データの解析、再構成と送信データの生成
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import tted.evdcm.server.struct.DcmDataPacket;
import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.DcmParam;
import tted.evdcm.server.struct.DcmParamData;
import tted.evdcm.server.struct.ParamSetData;
import tted.evdcm.server.struct.RealTimeAlarmData;
import tted.evdcm.server.struct.RealTimeDataPacket;
import tted.evdcm.server.struct.RealTimeExtremumData;
import tted.evdcm.server.struct.RealTimeGPSData;
import tted.evdcm.server.struct.RealTimeTemperatureData;
import tted.evdcm.server.struct.RealTimeVehicleData;
import tted.evdcm.server.struct.RealTimeVoltageData;
import tted.evdcm.server.struct.RegistData;
import tted.evdcm.server.struct.StatusData;
import tted.evdcm.server.utils.Common;

public class DataManager {
	/* DCMからデータの中に登録の命令標識 */
	static final int CMD_REGIST = 0x01;
	/* DCMからデータの中にリアルタイムの命令標識 */
	static final int CMD_REAL_TIME = 0x02;
	/* DCMからデータの中に情報の命令標識 */
	static final int CMD_STATUS = 0x03;
	/* DCMからデータの中に心拍の命令標識 */
	static final int CMD_HEART = 0x04;
	/* DCMからデータの中に追給情報の命令標識 */
	static final int CMD_REISSUED = 0x05;
	/* DCMからデータの中に検索の命令標識 */
	static final int CMD_QUERY = 0x80;
	/* DCMからデータの中に設定の命令標識 */
	static final int CMD_SET = 0x81;
	/* DCMからデータの中にコントロールの命令標識 */
	static final int CMD_DCM_CONTROL = 0x82;

	/* 受信のデータが正しい応答標識 */
	static final int RESPONSE_SUCCESS = 0x01;
	/* 設定失敗応答標識 */
	static final int RESPONSE_MODIFY_ERR = 0x02;
	/* データバックが命令バックの標識 */
	static final int RESPONSE_CMD = 0xfe;

	/* 情報タイプ標識：電池電圧データ */
	static final int REAL_TIME_VOLTAGE = 0x01;
	/* 情報タイプ標識：電池温度データ */
	static final int REAL_TIME_TEMPERATURE = 0x02;
	/* 情報タイプ標識：車データ */
	static final int REAL_TIME_VEHICLE = 0x03;
	/* 情報タイプ標識：GPSデータ */
	static final int REAL_TIME_GPS = 0x04;
	/* 情報タイプ標識：極値データ */
	static final int REAL_TIME_EXTERMUM = 0x05;
	/* 情報タイプ標識：アラーム電圧データ */
	static final int REAL_TIME_ALARM = 0x06;

	/**
	 * 車のナンバーと ソケットの実例を保存
	 */
	static HashMap<String, Socket> mSocketCarNumberMap = new HashMap<String, Socket>();
	/**
	 * 車のナンバーとDCMのローカルパラメータを保存
	 */
	static HashMap<String, DcmLocalParam> mDcmLocalParamMap = new HashMap<String, DcmLocalParam>();

	/**
	 * Dcmからデータを解析と検証.
	 * 
	 * @param indata
	 *            DCMからのデータ.
	 * @return データ解析と検証が正確時データパックを返し、でなければnullを返し
	 */
	static public DcmDataPacket dcmDataPacketCheck(byte[] indata) {
		if(indata == null) {
			return null;
		}
		
		if (!bccCheck(indata)) {
			return null;
		}

		DcmDataPacket dcmDataPacket = DcmDataPacket.fromBytesToPacket(indata);

		if (!basicCheck(dcmDataPacket)) {
			return null;
		}

		switch (dcmDataPacket.getCmdFlag()) {
		case CMD_REGIST: {
			if (!registDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		case CMD_REAL_TIME: {
			if (!realTimeDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		case DataManager.CMD_QUERY: {
			if (!paramQueryDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		case DataManager.CMD_SET: {
			if (!paramSetDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		case DataManager.CMD_DCM_CONTROL: {
			if (!dcmControlDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		case DataManager.CMD_REISSUED: {
			if (!reissuedDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		case DataManager.CMD_STATUS: {
			if (!statusDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		case DataManager.CMD_HEART: {
			if (!heartDataCheck(dcmDataPacket)) {
				return null;
			}
			break;
		}
		default:
			return null;
		}
		return dcmDataPacket;
	}

	/**
	 * DcmからデータをDBに保存.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean dataStoreDbProcess(String carNumber, DcmDataPacket ddp) {
		if(ddp == null) {
			return false;
		}
		
		switch (ddp.getCmdFlag()) {
		case CMD_REGIST: {
			RegistData registData = RegistData.fromBytesToPacket(ddp.getData());
			DBManager.registDataSave(registData);
			break;
		}
		case CMD_REISSUED:
		case CMD_REAL_TIME: {
			return realTimeDataStoreDbProcess(carNumber, ddp);
		}
		case CMD_STATUS: {
			StatusData statusData = StatusData.fromBytesToPacket(carNumber,
					ddp.getData());
			DBManager.statusDataSave(statusData);
			break;
		}
		default:
			return false;
		}
		return true;
	}

	/**
	 * Dcmに応答データを生成.
	 * 
	 * @param cmd
	 *            命令型.
	 * @param vin
	 *            車両の識別コード.
	 * @return Dcmにの応答データ
	 */
	static public byte[] responsePacketSet(int cmd, String vin) {
		DcmDataPacket ddp = new DcmDataPacket();
		ddp.setStartFlag("##");
		ddp.setCmdFlag(cmd);
		ddp.setResponseFlag(RESPONSE_SUCCESS);
		ddp.setIdentifier(vin);
		ddp.setRsa(0x00);
		ddp.setDataLength(0);
		ddp.setData(null);
		ddp.setBcc(0);
		byte[] temp = ddp.fromPacketToBytes();
		ddp.setBcc(getBcc(temp, 0, temp.length - 1));

		return ddp.fromPacketToBytes();
	}

	/**
	 * Dcmにパラメータのデータを生成.
	 * 
	 * @param command
	 *            命令型.
	 * @param vin
	 *            車両の識別コード.
	 * @param data
	 *            DCMにの真正なデータ.
	 * @return Dcmにのパラメータのデータ
	 */
	static public byte[] dcmParamPacketSet(int command, String vin, byte[] data) {
		DcmDataPacket ddp = new DcmDataPacket();
		ddp.setStartFlag("##");
		ddp.setCmdFlag(command);
		ddp.setResponseFlag(RESPONSE_CMD);
		ddp.setIdentifier(vin);
		ddp.setRsa(0x00);
		ddp.setDataLength(data.length);
		ddp.setData(data);
		ddp.setBcc(0);
		byte[] temp = ddp.fromPacketToBytes();
		ddp.setBcc(getBcc(temp, 0, temp.length - 1));

		return ddp.fromPacketToBytes();
	}

	/**
	 * 車のナンバーで取得登録システムのソケット.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @return 登録システムのソケット
	 */
	static public Socket getSocketByString(String carNumber) {
		if(carNumber == null) {
			return null;
		}
		if (mSocketCarNumberMap.isEmpty()) {
			return null;
		}
		if (!mSocketCarNumberMap.containsKey(carNumber)) {
			return null;
		}
		return mSocketCarNumberMap.get(carNumber);
	}

	/**
	 * 登録システムのソケットで車のナンバーを取得.
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @return 車のナンバー
	 */
	static public String getStringBySocket(Socket sk) {
		if (mSocketCarNumberMap.isEmpty()) {
			return null;
		}
		if (!mSocketCarNumberMap.containsValue(sk)) {
			return null;
		}
		Set<String> ks = mSocketCarNumberMap.keySet();
		Iterator<String> is = ks.iterator();
		while (is.hasNext()) {
			String key = is.next();
			Socket sock = mSocketCarNumberMap.get(key);
			if (sock.equals(sk)) {
				return key;
			}
		}

		return null;
	}

	/**
	 * 登録システムのソケットと車のナンバーを保存.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param sk
	 *            ソケットの実例.
	 * @return データ保存が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean saveSocketInList(String carNumber, Socket sk) {
		if (mSocketCarNumberMap.containsKey(carNumber)) {
			mSocketCarNumberMap.remove(carNumber);
		}
		mSocketCarNumberMap.put(carNumber, sk);
		return true;

	}

	/**
	 * 車のナンバーでリストの登録システムのソケットを削除.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @return データ削除が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean deleteSocketInList(String carNumber) {
		if (mSocketCarNumberMap.containsKey(carNumber)) {
			ConnectManager.withDcmSocketClose(carNumber);
			mSocketCarNumberMap.remove(carNumber);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * サーバー本地のDCMのパラメータリストを取得.
	 * 
	 * @param null
	 * 
	 * @return 本地のDCMのパラメータリスト
	 */
	static public HashMap<String, DcmLocalParam> getDcmLocalParamList() {
		return mDcmLocalParamMap;
	}

	/**
	 * 車のナンバーでサーバー本地のDCMのパラメータを取得.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @return 本地のDCMのパラメータ
	 */
	static public DcmLocalParam getDcmLocalParamByString(String carNumber) {
		if (mDcmLocalParamMap.isEmpty()) {
			return null;
		}
		if (!mDcmLocalParamMap.containsKey(carNumber)) {
			return null;
		}
		return mDcmLocalParamMap.get(carNumber);
	}

	/**
	 * サーバー本地のDCMのパラメータと車のナンバーを保存.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param dlp
	 *            本地のDCMのパラメータ.
	 * @return データ保存が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean saveDcmLocalParamInList(String carNumber,
			DcmLocalParam dlp) {
		if (mDcmLocalParamMap.containsKey(carNumber)) {
			mDcmLocalParamMap.remove(carNumber);
		}
		mDcmLocalParamMap.put(carNumber, dlp);
		return true;

	}

	/**
	 * 車のナンバーでリストのサーバー本地のDCMのパラメータを削除
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @return データ削除が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean deleteDcmLocalParamInList(String carNumber) {
		if (mDcmLocalParamMap.containsKey(carNumber)) {
			mDcmLocalParamMap.remove(carNumber);
			return true;
		} else {
			return false;
		}
	}

	// //------------------internal------------------------
	/**
	 * 指定の配列でBCC値を計算.
	 * 
	 * @param bf
	 *            計算する必要なバイト配列.
	 * @param offset
	 *            bfのスタートオフセット量.
	 * @param length
	 *            計算する時使用の最大バイト数.
	 * @return 計算したBCC値
	 */
	static byte getBcc(byte[] bf, int offset, int length) {
		byte bcc = 0;
		if (offset + length > bf.length) {
			return bcc;
		}
		for (int i = 0; i < length; i++) {
			bcc = (byte) (bcc ^ bf[offset + i]);
		}
		return bcc;
	}

	/**
	 * 配列の最後バイト値と配列の前N-1バイトのbcc値を比較
	 * 
	 * @param bf
	 *            検索する必要の配列.
	 * @return bccの検索結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean bccCheck(byte[] bf) {
		if (bf.length < 2) {
			return false;
		}

		byte calcBcc = getBcc(bf, 0, bf.length - 1);
		byte bcc = bf[bf.length - 1];
		if (calcBcc == bcc) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * DcmDataPacketの中に基本データをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return 基本データをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean basicCheck(DcmDataPacket dp) {
		if (!dp.getStartFlag().equals("##")) {
			return false;
		}
		if (dp.getIdentifier().equals("")) {
			return false;
		} else {
			String vinNum = dp.getIdentifier().substring(
					dp.getIdentifier().length() - 5);
			if (!Common.isNumeric(vinNum)) {
				return false;
			}
			String vinCharNum = dp.getIdentifier().substring(0,
					dp.getIdentifier().length() - 5);
			if (!Common.isCharNumeric(vinCharNum)) {
				return false;
			}
		}
		if((dp.getDataLength() == 0) && (dp.getData() == null)) {
			return true;
		} else if (dp.getDataLength() != dp.getData().length) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * DcmDataPacketの中に登録データをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return 登録データをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean registDataCheck(DcmDataPacket dp) {
		byte[] data = dp.getData();
		int cnt = data[28];
		int registDataSize = cnt * 20 + 6 + 2 + 8 + 12 + 1 + 11;
		if (registDataSize != dp.getDataLength()) {
			return false;
		}
		if(dp.getResponseFlag() != RESPONSE_CMD) {
			return false;
		}
		return true;
	}

	/**
	 * DcmDataPacketの中にリアルタイムデータをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return リアルタイムデータをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean realTimeDataCheck(DcmDataPacket ddp) {
		if(ddp.getResponseFlag() == RESPONSE_CMD) {
			return false;
		}
		
		RealTimeDataPacket rtdp = RealTimeDataPacket.fromBytesToPacket(ddp
				.getData());

		byte[] data = rtdp.getData();
		int offset = 0;
		while (offset < data.length) {
			switch (data[offset]) {
			case REAL_TIME_VOLTAGE: {
				RealTimeVoltageData realTimeVoltageData = RealTimeVoltageData
						.fromBytesToPacket(null, null, data, offset);
				offset += realTimeVoltageData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_TEMPERATURE: {
				RealTimeTemperatureData realTimeTemperatureData = RealTimeTemperatureData
						.fromBytesToPacket(null, null, data, offset);
				offset += realTimeTemperatureData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_VEHICLE: {
				offset += RealTimeVehicleData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_GPS: {
				offset += RealTimeGPSData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_EXTERMUM: {
				offset += RealTimeExtremumData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_ALARM: {
				RealTimeAlarmData realTimeAlarmData = RealTimeAlarmData
						.fromBytesToPacket(null, null, data, offset);
				offset += realTimeAlarmData.getDataInfoStructLength();
				break;
			}
			default:
				return false;
			}
		}
		if (offset == data.length) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * DcmDataPacketの中にDCMからのパラメータデータをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return DCMからのパラメータデータをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean paramQueryDataCheck(DcmDataPacket dp) {
		DcmParamData dcmParamData = DcmParamData.fromBytesToPacket(dp
				.getData());
		if (dcmParamData == null) {
			return false;
		}
		if(dcmParamData.getDataInfoStructLength() != dp.getDataLength()) {
			return false;
		}
		if(dp.getResponseFlag() == RESPONSE_CMD) {
			return false;
		}
		return true;
	}

	/**
	 * DcmDataPacketの中にDCMからのパラメータデータをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return DCMからのパラメータデータをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean paramSetDataCheck(DcmDataPacket dp) {
		ParamSetData paramSetData = ParamSetData.fromBytesToPacket(null,
				dp.getData());
		if (paramSetData == null) {
			return false;
		}
		if(paramSetData.getDataInfoStructLength() != dp.getDataLength()) {
			return false;
		}
		if(dp.getResponseFlag() == RESPONSE_CMD) {
			return false;
		}
		return true;
	}

	/**
	 * DcmDataPacketの中にDCMからのコントロールデータをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return DCMからのコントロールデータをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean dcmControlDataCheck(DcmDataPacket dp) {
		byte[] data = dp.getData();
		switch (data[6]) {
		case DcmParam.CTRLID_REMOTE_UPDATE:
		case DcmParam.CTRLID_DCM_SHUTDOWN:
		case DcmParam.CTRLID_DCM_RESET:
		case DcmParam.CTRLID_DCM_RESTORE_SETTINGS:
		case DcmParam.CTRLID_CLOSE_CONNECTION:
		case DcmParam.CTRLID_DCM_ALARM: {
			break;
		}
		case DcmParam.CTRLID_NONE:
		default: {
			return false;
		}
		}
		if(dp.getResponseFlag() == RESPONSE_CMD) {
			return false;
		}
		return true;
	}

	/**
	 * DcmDataPacketの中に追給データをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return 追給データをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean reissuedDataCheck(DcmDataPacket dp) {
		return realTimeDataCheck(dp);
	}

	/**
	 * DcmDataPacketの中に端末情報データをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return 端末情報データをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean statusDataCheck(DcmDataPacket dp) {
		if (dp.getData().length != 11) {
			return false;
		}
		if(dp.getResponseFlag() != RESPONSE_CMD) {
			return false;
		}
		return true;
	}

	/**
	 * DcmDataPacketの中にハートデータをチェック
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return ハートデータをチェック結果が正確時trueを返し、でなければfalseを返し
	 */
	static boolean heartDataCheck(DcmDataPacket dp) {
		if (dp.getDataLength() != 0) {
			return false;
		}
		if(dp.getResponseFlag() != RESPONSE_CMD) {
			return false;
		}
		return true;
	}

	/**
	 * リアルタイムデータをデータベースに保存
	 * 
	 * @param carNumber
	 *            車のナンバー
	 * @param dp
	 *            DCMからのデータパック.
	 * @return データ保存操作が正確時trueを返し、でなければfalseを返し
	 */
	static boolean realTimeDataStoreDbProcess(String carNumber, DcmDataPacket ddp) {
		RealTimeDataPacket rtdp = RealTimeDataPacket.fromBytesToPacket(ddp
				.getData());
		String dateTime = rtdp.getDateTime();
		byte[] data = rtdp.getData();
		int offset = 0;
		while (offset < data.length) {
			switch (data[offset]) {
			case REAL_TIME_VOLTAGE: {
				RealTimeVoltageData realTimeVoltageData = RealTimeVoltageData
						.fromBytesToPacket(carNumber, dateTime, data, offset);
				DBManager.realTimeVoltageDataSave(realTimeVoltageData);
				offset += realTimeVoltageData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_TEMPERATURE: {
				RealTimeTemperatureData realTimeTemperatureData = RealTimeTemperatureData
						.fromBytesToPacket(carNumber, dateTime, data, offset);
				DBManager.realTimeTemperatureDataSave(realTimeTemperatureData);
				offset += realTimeTemperatureData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_VEHICLE: {
				RealTimeVehicleData realTimeVehicleData = RealTimeVehicleData
						.fromBytesToPacket(carNumber, dateTime, data, offset);
				DBManager.realTimeVehicleDataSave(realTimeVehicleData);
				offset += RealTimeVehicleData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_GPS: {
				RealTimeGPSData realTimeGPSData = RealTimeGPSData
						.fromBytesToPacket(carNumber, dateTime, data, offset);
				DBManager.realTimeGPSDataSave(realTimeGPSData);
				offset += RealTimeGPSData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_EXTERMUM: {
				RealTimeExtremumData realTimeExtremumData = RealTimeExtremumData
						.fromBytesToPacket(carNumber, dateTime, data, offset);
				DBManager.realTimeExtremumDataSave(realTimeExtremumData);
				offset += RealTimeExtremumData.getDataInfoStructLength();
				break;
			}
			case REAL_TIME_ALARM: {
				RealTimeAlarmData realTimeAlarmData = RealTimeAlarmData
						.fromBytesToPacket(carNumber, dateTime, data, offset);
				DBManager.realTimeAlarmDataSave(realTimeAlarmData);
				offset += realTimeAlarmData.getDataInfoStructLength();
				break;
			}
			default:
				return false;
			}
		}

		return true;

	}

}
