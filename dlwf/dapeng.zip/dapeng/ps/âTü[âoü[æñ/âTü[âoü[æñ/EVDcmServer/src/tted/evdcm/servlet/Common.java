package tted.evdcm.servlet;

public class Common {
	static public final String DBDriver = "com.mysql.jdbc.Driver";
	static public final String DBUrl = "jdbc:mysql://localhost/dcmseverdb";
	static public final String DBUser = "root";
	static public final String DBPassword = "123456";
	
	static public final String USERS_TABLE = "users";
	static public final String USER_NAME_COLUMN = "username";
	static public final String PASSWORD_COLUMN = "password";
	static public final String EMAIL_COLUMN = "email";
	
}
