/*************************************************************************
 **
 * File Name		RealTimeExtremumData.java
 * File Summary		DCMからのリアルタイム極値データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class RealTimeExtremumData {
	/* 車両ナンバー */
	String mCarNumber;
	/* データ採集時間 */
	String mDateTime;

	/* 情報タイプマーク */
	int mInfoTypeFlag = 0x05;

	/* 最高電圧動力バッテリー単体所在バッテリーパック番号 */
	int mMaxVoltageBatteryPackNumber;
	/* 最高電圧単体バッテリー番号 */
	int mMaxVoltageBatteryNumber;
	/* バッテリー単体電圧最高値 */
	int mBatteryMaxVoltage;
	/* 最低電圧動力バッテリーパック番号 */
	int mMinVoltageBatteryPackNumber;
	/* 最低電圧単体バッテリー番号 */
	int mMinVoltageBatteryNumber;
	/* バッテリー単体電圧の最低値 */
	int mBatteryMinVoltage;
	/* 最高温度動力バッテリーパック番号 */
	int mMaxTempBatteryPackNumber;
	/* 最高温度プローブ番号 */
	int mMaxTempProbeNumber;
	/* 最高温度値 */
	int mMaxTemperature;
	/* 最低温度動力バッテリーパック番号 */
	int mMinTempBatteryPackNumber;
	/* 最低温度プローブ番号 */
	int mMinTempProbeNumber;
	/* 最低温度値 */
	int mMinTemperature;
	/* 総電圧 */
	int mTotalVoltage;
	/* 総電流 */
	int mTotalCurrent;
	/* SOC */
	int mSOC;
	/* 余剰エネルギー */
	int mRemainEnergy;
	/* 絶縁抵抗 */
	int mInsulationResistance;
	/* リザーブ */
	byte[] mReserve;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getInfoTypeFlag() {
		return mInfoTypeFlag;
	}

	public void setMaxVoltageBatteryPackNumber(int value) {
		mMaxVoltageBatteryPackNumber = value;
	}

	public void setMaxVoltageBatteryNumber(int value) {
		mMaxVoltageBatteryNumber = value;
	}

	public void setBatteryMaxVoltage(int value) {
		mBatteryMaxVoltage = value;
	}

	public void setMinVoltageBatteryPackNumber(int value) {
		mMinVoltageBatteryPackNumber = value;
	}

	public void setMinVoltageBatteryNumber(int value) {
		mMinVoltageBatteryNumber = value;
	}

	public void setBatteryMinVoltage(int value) {
		mBatteryMinVoltage = value;
	}

	public void setMaxTempBatteryPackNumber(int value) {
		mMaxTempBatteryPackNumber = value;
	}

	public void setMaxTempProbeNumber(int value) {
		mMaxTempProbeNumber = value;
	}

	public void setMaxTemperature(int value) {
		mMaxTemperature = value;
	}

	public void setMinTempBatteryPackNumber(int value) {
		mMinTempBatteryPackNumber = value;
	}

	public void setMinTempProbeNumber(int value) {
		mMinTempProbeNumber = value;
	}

	public void setMinTemperature(int value) {
		mMinTemperature = value;
	}

	public void setTotalVoltage(int value) {
		mTotalVoltage = value;
	}

	public void setTotalCurrent(int value) {
		mTotalCurrent = value;
	}

	public void setSOC(int value) {
		mSOC = value;
	}

	public void setRemainEnergy(int value) {
		mRemainEnergy = value;
	}

	public void setInsulationResistance(int value) {
		mInsulationResistance = value;
	}

	public int getMaxVoltageBatteryPackNumber() {
		return mMaxVoltageBatteryPackNumber;
	}

	public int getMaxVoltageBatteryNumber() {
		return mMaxVoltageBatteryNumber;
	}

	public int getBatteryMaxVoltage() {
		return mBatteryMaxVoltage;
	}

	public int getMinVoltageBatteryPackNumber() {
		return mMinVoltageBatteryPackNumber;
	}

	public int getMinVoltageBatteryNumber() {
		return mMinVoltageBatteryNumber;
	}

	public int getBatteryMinVoltage() {
		return mBatteryMinVoltage;
	}

	public int getMaxTempBatteryPackNumber() {
		return mMaxTempBatteryPackNumber;
	}

	public int getMaxTempProbeNumber() {
		return mMaxTempProbeNumber;
	}

	public int getMaxTemperature() {
		return mMaxTemperature;
	}

	public int getMinTempBatteryPackNumber() {
		return mMinTempBatteryPackNumber;
	}

	public int getMinTempProbeNumber() {
		return mMinTempProbeNumber;
	}

	public int getMinTemperature() {
		return mMinTemperature;
	}

	public int getTotalVoltage() {
		return mTotalVoltage;
	}

	public int getTotalCurrent() {
		return mTotalCurrent;
	}

	public int getSOC() {
		return mSOC;
	}

	public int getRemainEnergy() {
		return mRemainEnergy;
	}

	public int getInsulationResistance() {
		return mInsulationResistance;
	}

	/**
	 * 配列のデータをRealTimeExtremumData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param dateTime
	 *            データの採取時間.
	 * @param byteStream
	 *            含むRealTimeExtremumData情報の配列.
	 * @param offset
	 *            byteStream配列の位置ずれ.
	 * @return 配列操作が正確時RealTimeExtremumData実例を返し、でなければnullを返し
	 */
	static public RealTimeExtremumData fromBytesToPacket(String carNumber,
			String dateTime, byte[] byteStream, int offset) {
		RealTimeExtremumData rted = new RealTimeExtremumData();

		rted.mCarNumber = carNumber;
		rted.mDateTime = dateTime;

		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			dataInputStream.skipBytes(offset);
			rted.mInfoTypeFlag = Common.byteToInt(dataInputStream.readByte());

			rted.mMaxVoltageBatteryPackNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mMaxVoltageBatteryNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mBatteryMaxVoltage = dataInputStream.readShort();

			rted.mMinVoltageBatteryPackNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mMinVoltageBatteryNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mBatteryMinVoltage = dataInputStream.readShort();

			rted.mMaxTempBatteryPackNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mMaxTempProbeNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mMaxTemperature = Common.byteToInt(dataInputStream.readByte());

			rted.mMinTempBatteryPackNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mMinTempProbeNumber = Common.byteToInt(dataInputStream.readByte());
			rted.mMinTemperature = Common.byteToInt(dataInputStream.readByte());

			rted.mTotalVoltage = dataInputStream.readShort();
			rted.mTotalCurrent = dataInputStream.readShort();
			rted.mSOC = Common.byteToInt(dataInputStream.readByte());
			rted.mRemainEnergy = dataInputStream.readShort();
			rted.mInsulationResistance = dataInputStream.readShort();

			return rted;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * RealTimeExtremumData型のバックは使ったバイト数を計算
	 * 
	 * @param null
	 *            
	 * @return RealTimeExtremumData型のバックは使ったバイト数
	 */
	public static int getDataInfoStructLength() {
		int len = 1 + 1 + 1 + 2 + 1 + 1 + 2 + 1 + 1 + 1 + 1 + 1 + 1 + 2 + 2 + 1 + 2
				+ 2 + 5;
		return len;
	}

}
