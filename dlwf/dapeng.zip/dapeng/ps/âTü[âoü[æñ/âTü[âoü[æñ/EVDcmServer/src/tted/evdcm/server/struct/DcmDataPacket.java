/*************************************************************************
 **
 * File Name		DcmDataPacket.java
 * File Summary		DCMからのデータでパックに作成
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;
import tted.evdcm.server.utils.DcmDataOutputStream;

public class DcmDataPacket {
	/* 開始符 "##" */
	String mStartFlag;
	/* 命令標識 */
	int mCmdFlag;
	/* 応答標識 */
	int mResponseFlag;
	/* 識別コード */
	String mIdentifier;
	/* データ暗号化方式 */
	int mRsa;
	/* データの長さ */
	int mDataLength;
	/* データ */
	byte[] mData;
	/* 検査コード */
	int mBcc;

	public void setStartFlag(String flag) {
		mStartFlag = flag;
	}

	public String getStartFlag() {
		return mStartFlag;
	}

	public void setCmdFlag(int flag) {
		mCmdFlag = flag;
	}

	public int getCmdFlag() {
		return mCmdFlag;
	}

	public void setResponseFlag(int flag) {
		mResponseFlag = flag;
	}

	public int getResponseFlag() {
		return mResponseFlag;
	}

	public void setIdentifier(String identifier) {
		mIdentifier = identifier;
	}

	public String getIdentifier() {
		return mIdentifier;
	}

	public void setRsa(int rsa) {
		mRsa = rsa;
	}

	public int getRsa() {
		return mRsa;
	}

	public void setDataLength(int len) {
		mDataLength = len;
	}

	public int getDataLength() {
		return mDataLength;
	}

	public void setData(byte[] data) {
		mData = data;
	}

	public byte[] getData() {
		return mData;
	}

	public void setBcc(int bcc) {
		mBcc = bcc;
	}

	public int getBcc() {
		return mBcc;
	}

	/**
	 * 配列のデータをDcmDataPacket型のバックに変更
	 * 
	 * @param byteStream
	 *            含むDcmDataPacket情報の配列.
	 * @return 配列操作が正確時DcmDataPacket実例を返し、でなければnullを返し
	 */
	static public DcmDataPacket fromBytesToPacket(byte[] byteStream) {
		DcmDataPacket dcmDataPacket = new DcmDataPacket();
		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] tempB = new byte[2];
			dataInputStream.read(tempB, 0, 2);
			dcmDataPacket.mStartFlag = Common.strFromBytes(tempB);
			dcmDataPacket.mCmdFlag = Common.byteToInt(dataInputStream.readByte());
			dcmDataPacket.mResponseFlag = Common.byteToInt(dataInputStream.readByte());
			tempB = new byte[17];
			dataInputStream.read(tempB, 0, 17);
			dcmDataPacket.mIdentifier = Common.strFromBytes(tempB);
			dcmDataPacket.mRsa = Common.byteToInt(dataInputStream.readByte());
			dcmDataPacket.mDataLength = dataInputStream.readShort();

			int size = 24 + dcmDataPacket.mDataLength + 1;
			if (size != byteStream.length) {
				return null;
			}
			if ((dcmDataPacket.mDataLength > 0)) {
				dcmDataPacket.mData = new byte[dcmDataPacket.mDataLength];
				dataInputStream.read(dcmDataPacket.mData, 0,
						dcmDataPacket.mData.length);
			}
			dcmDataPacket.mBcc = Common.byteToInt(dataInputStream.readByte());

			return dcmDataPacket;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * DcmDataPacket型のバックを配列のデータに変更
	 * 
	 * @param null
	 *           
	 * @return 操作が正確時配列のデータを返し、でなければnullを返し
	 */
	public byte[] fromPacketToBytes() {
		int size = 24 + mDataLength + 1;

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(
				size);
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			dataOutputStream.writeBytes(mStartFlag);
			dataOutputStream.writeByte(mCmdFlag);
			dataOutputStream.writeByte(mResponseFlag);
			dataOutputStream.writeBytes(mIdentifier);
			dataOutputStream.writeByte(mRsa);
			dataOutputStream.writeShort(mDataLength);
			if ((mData != null) && (mData.length > 0)) {
				dataOutputStream.write(mData, 0, mData.length);
			}
			dataOutputStream.writeByte(mBcc);
			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
