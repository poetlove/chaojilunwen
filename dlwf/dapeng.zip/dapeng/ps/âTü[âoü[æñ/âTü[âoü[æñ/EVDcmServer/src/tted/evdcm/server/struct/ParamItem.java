/*************************************************************************
 **
 * File Name		ParamItem.java
 * File Summary		DCMのパラメータの項目
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-12
 **************************************************************************/
package tted.evdcm.server.struct;

public class ParamItem {
	/* パラメータID */
	int mParamId;
	/* 数値型パラメータ値 */
	int mParamInt;
	/* 文字列型パラメータ値 */
	String mParamString;
	
	/**
	 * DCMのパラメータの項目を初期化
	 * 
	 * @param null
	 *            
	 * @return null
	 */
	public ParamItem() {
		mParamId = 0;
		mParamInt = 0;
		mParamString = "";
	}
	
	public void setParamId(int id) {
		mParamId = id;
	}
	public int getParamId() {
		return mParamId;
	}
	public void setParamInt(int it) {
		mParamInt = it;
	}
	public int getParamInt() {
		return mParamInt;
	}
	public void setParamString(String param) {
		mParamString = param;
	}
	public String getParamString() {
		return mParamString;
	}
}
