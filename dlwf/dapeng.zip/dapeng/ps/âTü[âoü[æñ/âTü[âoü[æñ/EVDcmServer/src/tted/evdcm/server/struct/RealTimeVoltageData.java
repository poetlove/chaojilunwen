/*************************************************************************
 **
 * File Name		RealTimeVoltageData.java
 * File Summary		DCMからのリアルタイム電池電圧データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/

package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class RealTimeVoltageData {
	/* 車両ナンバー */
	String mCarNumber;
	/* データ採集時間 */
	String mDateTime;

	/* 情報タイプマーク */
	int mInfoTypeFlag = 0x01;

	/* 単体バッテリー数 */
	int mBatteryCount;
	/* 動力バッテリーパック数N */
	int mBatteryPackCount;
	/* 動力バッテリーパック表 */
	ArrayList<VoltagePacket> mVoltagePackets;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getInfoTypeFlag() {
		return mInfoTypeFlag;
	}

	public void setBatteryCount(int cnt) {
		mBatteryCount = cnt;
	}

	public int getBatteryCount() {
		return mBatteryCount;
	}

	public void setBatteryPackCount(int cnt) {
		mBatteryPackCount = cnt;
	}

	public int getBatteryPackCount() {
		return mBatteryPackCount;
	}

	public void setVoltagePackets(ArrayList<VoltagePacket> pkts) {
		mVoltagePackets = pkts;
	}

	public ArrayList<VoltagePacket> getVoltagePackets() {
		return mVoltagePackets;
	}

	/**
	 * 配列のデータをRealTimeVoltageData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param dateTime
	 *            データの採取時間.
	 * @param byteStream
	 *            含むRealTimeVoltageData情報の配列.
	 * @param offset
	 *            byteStream配列の位置ずれ.
	 * @return 配列操作が正確時RealTimeVoltageData実例を返し、でなければnullを返し
	 */
	static public RealTimeVoltageData fromBytesToPacket(String carNumber,
			String dateTime, byte[] byteStream, int offset) {
		RealTimeVoltageData rtvd = new RealTimeVoltageData();

		rtvd.mCarNumber = carNumber;
		rtvd.mDateTime = dateTime;

		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			dataInputStream.skipBytes(offset);
			rtvd.mInfoTypeFlag = Common.byteToInt(dataInputStream.readByte());

			rtvd.mBatteryCount = dataInputStream.readShort();
			rtvd.mBatteryPackCount = Common.byteToInt(dataInputStream.readByte());

			if (rtvd.mBatteryPackCount > 0) {
				rtvd.mVoltagePackets = new ArrayList<VoltagePacket>();
				for (int i = 0; i < rtvd.mBatteryPackCount; i++) {
					VoltagePacket vp = new VoltagePacket();
					vp.setBatteryPacketSequence(Common.byteToInt(dataInputStream.readByte()));
					vp.setBatteryCount(Common.byteToInt(dataInputStream.readByte()));
					if (vp.getBatteryCount() > 0) {
						ArrayList<Integer> ai = new ArrayList<Integer>();
						for (int j = 0; j < vp.getBatteryCount(); j++) {
							ai.add((int) dataInputStream.readShort());
						}
						vp.setVoltageValues(ai);
					} else {
						vp.setVoltageValues(null);
					}

					rtvd.mVoltagePackets.add(vp);
				}
			} else {
				rtvd.mVoltagePackets = null;
			}

			return rtvd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * RealTimeVoltageData型のバックは使ったバイト数を計算
	 * 
	 * @param null
	 *            
	 * @return RealTimeVoltageData型のバックは使ったバイト数
	 */
	public int getDataInfoStructLength() {
		int len = 1 + 2 + 1;

		if (mBatteryPackCount > 0) {
			for (int i = 0; i < mBatteryPackCount; i++) {
				VoltagePacket vp = mVoltagePackets.get(i);
				len += 2;
				len += 2 * vp.getBatteryCount();
			}
		}

		return len;
	}

}
