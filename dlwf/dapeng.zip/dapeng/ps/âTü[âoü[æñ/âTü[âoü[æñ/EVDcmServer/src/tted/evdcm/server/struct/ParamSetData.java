/*************************************************************************
 **
 * File Name		ParamSetData.java
 * File Summary		DCMのパラメータの設定用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;
import tted.evdcm.server.utils.DcmDataOutputStream;

public class ParamSetData {
	/* 車両ナンバー */
	String mCarNumber;
	/* パラメータの設定時間 */
	String mDateTime;
	/* パラメータ総数 */
	int mCount;
	/* パラメータ項目リスト */
	ArrayList<ParamItem> mParamItems;

	public ParamSetData() {
		// nothing
	}

	/**
	 * ユーザーの設定でParamSetData型実例を初期化
	 * 
	 * @param dp
	 *            ユーザーのDCMの操作用のデータ実例
	 * @return null
	 */
	public ParamSetData(DcmParam dp) {
		mCarNumber = dp.getCarNumber();
		mDateTime = dp.getDateTime();
		mParamItems = new ArrayList<ParamItem>();
		ParamItem pi;
		if (dp.getBoolDcmStoragePeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_STORE_PERI);
			pi.setParamInt(dp.getValueDcmStoragePeriod());
			mParamItems.add(pi);
		}
		if (dp.getBoolDcmInfoReportPeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_INFO_REP_PERI);
			pi.setParamInt(dp.getValueDcmInfoReportPeriod());
			mParamItems.add(pi);
		}
		if (dp.getBoolDcmAlarmInfoReportPeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_ALARM_INFO_REP_PERI);
			pi.setParamInt(dp.getValueDcmAlarmInfoReportPeriod());
			mParamItems.add(pi);
		}
		if (dp.getBoolIntegratedPlatformIP() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_PLATFORM_IP);
			pi.setParamString(Common.ipFromBytes(dp
					.getValueIntegratedPlatformIP()));
			mParamItems.add(pi);
		}
		if (dp.getBoolIntegratedPlatformPort() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_PLATFORM_PORT);
			pi.setParamInt(dp.getValueIntegratedPlatformPort());
			mParamItems.add(pi);
		}
		if (dp.getBoolDcmHardwareVersion() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_HW_VERSION);
			pi.setParamString(dp.getValueDcmHardwareVersion());
			mParamItems.add(pi);
		}
		if (dp.getBoolDcmFirmwareVersion() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_FW_VERSION);
			pi.setParamString(dp.getValueDcmFirmwareVersion());
			mParamItems.add(pi);
		}
		if (dp.getBoolDcmHeartPeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_HEART_PERI);
			pi.setParamInt(dp.getValueDcmHeartPeriod());
			mParamItems.add(pi);
		}
		if (dp.getBoolDcmResponseTime() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_RESPONE_TIME);
			pi.setParamInt(dp.getValueDcmResponseTime());
			mParamItems.add(pi);
		}
		if (dp.getBoolServerResponseTime() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_SERVER_RESPONE_TIME);
			pi.setParamInt(dp.getValueServerResponseTime());
			mParamItems.add(pi);
		}
		mCount = mParamItems.size();
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getCount() {
		return mCount;
	}

	public ArrayList<ParamItem> getParamItems() {
		return mParamItems;
	}

	/**
	 * 配列のデータをParamSetData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param byteStream
	 *            含むParamSetData情報の配列.
	 * @return 配列操作が正確時ParamSetData実例を返し、でなければnullを返し
	 */
	static public ParamSetData fromBytesToPacket(String carNumber,
			byte[] byteStream) {
		ParamSetData psd = new ParamSetData();
		psd.mCarNumber = carNumber;

		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			psd.mDateTime = Common.dateTimeFromBytes(dt);
			psd.mCount = Common.byteToInt(dataInputStream.readByte());

			int bsSize = byteStream.length;
			if ((psd.mCount > 0) && (bsSize > (6 + 1))) {
				psd.mParamItems = new ArrayList<ParamItem>();
				ParamItem pi;
				int paramSize = bsSize - (6 + 1);
				while (paramSize > 0) {
					int cmdId = Common.byteToInt(dataInputStream.readByte());
					if (cmdId == DcmParam.PID_DCM_STORE_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_DCM_INFO_REP_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_ALARM_INFO_REP_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_PLATFORM_IP) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] ip = new byte[6];
						dataInputStream.read(ip);
						pi.setParamString(Common.ipFromBytes(ip));
						psd.mParamItems.add(pi);
						paramSize -= (1 + 6);
					} else if (cmdId == DcmParam.PID_PLATFORM_PORT) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_DCM_HW_VERSION) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] str = new byte[5];
						dataInputStream.read(str);
						pi.setParamString(Common.strFromBytes(str));
						psd.mParamItems.add(pi);
						paramSize -= (1 + 5);
					} else if (cmdId == DcmParam.PID_DCM_FW_VERSION) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] str = new byte[5];
						dataInputStream.read(str);
						pi.setParamString(Common.strFromBytes(str));
						psd.mParamItems.add(pi);
						paramSize -= (1 + 5);
					} else if (cmdId == DcmParam.PID_DCM_HEART_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(Common.byteToInt(dataInputStream.readByte()));
						psd.mParamItems.add(pi);
						paramSize -= (1 + 1);
					} else if (cmdId == DcmParam.PID_DCM_RESPONE_TIME) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_SERVER_RESPONE_TIME) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					}
				}
				if (psd.mCount != psd.mParamItems.size()) {
					return null;
				}
			}

			return psd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * ParamSetData型のバックは使ったバイト数を計算
	 * 
	 * @param null
	 *            
	 * @return ParamSetData型のバックは使ったバイト数
	 */
	public int getDataInfoStructLength() {
		int len = 7;

		for (int i = 0; i < mCount; i++) {
			len += 1;
			ParamItem pi = mParamItems.get(i);
			if (pi.getParamId() == DcmParam.PID_DCM_STORE_PERI) {
				len += 2;
			} else if (pi.getParamId() == DcmParam.PID_DCM_INFO_REP_PERI) {
				len += 2;
			} else if (pi.getParamId() == DcmParam.PID_ALARM_INFO_REP_PERI) {
				len += 2;
			} else if (pi.getParamId() == DcmParam.PID_PLATFORM_IP) {
				len += 6;
			} else if (pi.getParamId() == DcmParam.PID_PLATFORM_PORT) {
				len += 2;
			} else if (pi.getParamId() == DcmParam.PID_DCM_HW_VERSION) {
				len += 5;
			} else if (pi.getParamId() == DcmParam.PID_DCM_FW_VERSION) {
				len += 5;
			} else if (pi.getParamId() == DcmParam.PID_DCM_HEART_PERI) {
				len += 1;
			} else if (pi.getParamId() == DcmParam.PID_DCM_RESPONE_TIME) {
				len += 2;
			} else if (pi.getParamId() == DcmParam.PID_SERVER_RESPONE_TIME) {
				len += 2;
			}
		}

		return len;
	}

	/**
	 * ParamSetData型のバックを配列のデータに変更
	 * 
	 * @param null
	 *           
	 * @return 操作が正確時配列のデータを返し、でなければnullを返し
	 */
	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			byte[] dt = Common.dateTimeToBytes(mDateTime);
			dataOutputStream.write(dt, 0, dt.length);
			dataOutputStream.writeByte(mCount);

			int cnt = mParamItems.size();
			for (int i = 0; i < cnt; i++) {
				ParamItem pi = mParamItems.get(i);
				if (pi.getParamId() == DcmParam.PID_DCM_STORE_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_DCM_INFO_REP_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_ALARM_INFO_REP_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_PLATFORM_IP) {
					dataOutputStream.writeByte(pi.getParamId());
					String str = pi.getParamString();
					byte[] ip = Common.ipToBytes(str);
					dataOutputStream.write(ip, 0, ip.length);
				} else if (pi.getParamId() == DcmParam.PID_PLATFORM_PORT) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_DCM_HW_VERSION) {
					dataOutputStream.writeByte(pi.getParamId());
					String str = pi.getParamString();
					byte[] b = Common.strToBytes(str);
					dataOutputStream.write(b, 0, b.length);
				} else if (pi.getParamId() == DcmParam.PID_DCM_FW_VERSION) {
					dataOutputStream.writeByte(pi.getParamId());
					String str = pi.getParamString();
					byte[] b = Common.strToBytes(str);
					dataOutputStream.write(b, 0, b.length);
				} else if (pi.getParamId() == DcmParam.PID_DCM_HEART_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_DCM_RESPONE_TIME) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_SERVER_RESPONE_TIME) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				}
			}

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
