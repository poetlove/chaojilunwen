/*************************************************************************
 **
 * File Name		DBManager.java
 * File Summary		DataBase processing
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-11
 **************************************************************************/
package tted.evdcm.server;

import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import tted.evdcm.server.struct.BatteryPacket;
import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.RealTimeAlarmData;
import tted.evdcm.server.struct.RealTimeExtremumData;
import tted.evdcm.server.struct.RealTimeGPSData;
import tted.evdcm.server.struct.RealTimeInfoId;
import tted.evdcm.server.struct.RealTimeTemperatureData;
import tted.evdcm.server.struct.RealTimeVehicleData;
import tted.evdcm.server.struct.RealTimeVoltageData;
import tted.evdcm.server.struct.RegistData;
import tted.evdcm.server.struct.StatusData;
import tted.evdcm.server.struct.TemperaturePacket;
import tted.evdcm.server.struct.VoltagePacket;
import tted.evdcm.server.utils.Common;

public class DBManager {
	/**
	 * データのプールに毎データの支持の最大数
	 */
	static final int MAX_SIZE = 1000;

	/**
	 * 基本情報登録表名
	 */
	static final String BASIC_INFO_TABLE = "BasicInfoTbl";
	/**
	 * 動力蓄電池コード表名
	 */
	static final String BATTERY_CODE_TABLE = "BatteryCodeTbl";
	/**
	 * 登録履歴表名
	 */
	static final String LOGIN_TABLE = "LoginTbl";

	/**
	 * 車載端末状態情報表名
	 */
	static final String TERMINAL_STATUS_TABLE = "TerminalStatusTbl";

	/**
	 * 車両のリアルタイムの情報ID表名
	 */
	static final String REAL_TIME_INFO_ID_TABLE = "RealTimeInfoIdTbl";
	/**
	 * 単体バッテリー電圧表名
	 */
	static final String BATTERY_VOLTAGE_PACK_TABLE = "BatteryVoltagePackTbl";
	/**
	 * 動力バッテリー電圧値表名
	 */
	static final String BATTERY_VOLTAGE_VALUE_TABLE = "BatteryVoltageValueTbl";
	/**
	 * 動力バッテリーバッグ温度表名
	 */
	static final String BATTERY_TEMPERATURE_PACK_TABLE = "BatteryTemperaturePackTbl";
	/**
	 * 動力バッテリー温度値表名
	 */
	static final String BATTERY_TEMPERATURE_VALUE_TABLE = "BatteryTemperatureValueTbl";
	/**
	 * 車両データ表名
	 */
	static final String VEHICLE_DATA_TABLE = "VehicleDataTbl";
	/**
	 * 極値データ表名
	 */
	static final String EXTREMUM_DATA_TABLE = "ExtremumDataTbl";
	/**
	 * 位置データ表名
	 */
	static final String GPS_DATA_TABLE = "GPSDataTbl";
	/**
	 * 警報データ表名
	 */
	static final String ALARM_DATA_TABLE = "AlarmDataTbl";
	/**
	 * 動力バッテリー他の故障コード表名
	 */
	static final String BATTERY_OTHER_FAULT_CODES_TABLE = "BatteryOtherFaultCodesTbl";
	/**
	 * 電機故障コード表名
	 */
	static final String MOTOR_FAULT_CODES_TABLE = "MotorFaultCodesTbl";
	/**
	 * 他の故障コード表名
	 */
	static final String OTHER_FAULT_CODES_TABLE = "OtherFaultCodesTbl";
	
	/**
	 * 列名：車両ナンバー
	 */
	static final String CARNUNBER_COLUMN = "CarNumber";
	/**
	 * 列名：メーカーのコード
	 */
	static final String MAKERCODE_COLUMN = "MakerCode";
	/**
	 * 列名：端末ロット
	 */
	static final String TERMINAL_NUMBER_COLUMN = "TerminalNumber";
	/**
	 * 列名：通し番号
	 */
	static final String SERIAL_NUMBER_COLUMN = "SerialNumber";
	/**
	 * 列名：動力バッテリーパック数N
	 */
	static final String BATTERY_PACK_COUNT_COLUMN = "BatteryPackCount";
	/**
	 * 列名：リザーブ
	 */
	static final String RESERVE_COLUMN = "reserve";
	
	/**
	 * 列名：動力バッテリーパック番号
	 */
	static final String BATTERY_PACK_SERIAL_NUMBER_COLUMN = "BatteryPackSerialNumber";
	/**
	 * 列名：メーカーのコード
	 */
	static final String PACK_ENCODE_MAKER_COLUMN = "PackEncodeMaker";
	/**
	 * 列名：バッテリーコード
	 */
	static final String PACK_ENCODE_BTTYTYPE_COLUMN = "PackEncodeBttyType";
	/**
	 * 列名：定格ポワー
	 */
	static final String PACK_ENCODE_RATED_ENERY_COLUMN = "PackEncodeRatedEnery";
	/**
	 * 列名：定格電圧
	 */
	static final String PACK_ENCODE_RATED_VOLTAGE_COLUMN = "PackEncodeRatedVoltage";
	/**
	 * 列名：バッテリー生産日コード
	 */
	static final String PACK_ENCODE_MAKE_DATE_COLUMN = "PackEncodeMakeDate";
	
	/**
	 * 列名：時間
	 */
	static final String DATE_TIME_COLUMN = "DateTime";
	/**
	 * 列名：登録通し番号
	 */
	static final String REGIST_SERIAL_NUMBER_COLUMN = "RegistNumber";
	
	/**
	 * 列名：状態標識
	 */
	static final String STATUS_COLUMN = "Status";
	
	/**
	 * 列名：リアルタイムの情報ID
	 */
	static final String INFOID_COLUMN = "InfoId";
	
	/**
	 * 列名：動力バッテリーパック数N
	 */
	static final String BATTERY_COUNT_COLUMN = "BatteryCount";

	/**
	 * 列名：動力バッテリーパック番号
	 */
	static final String BATTERY_PACKET_SEQUENCE_COLUMN = "BatteryPacketSequence";
	/**
	 * 列名：単体バッテリー電圧値
	 */
	static final String VOLTAGE_VALUES_COLUMN = "VoltageValues";
	
	/**
	 * 列名：動力バッテリーバッグ温度プローブ数
	 */
	static final String TEMPERATURE_PROBE_CNT_COLUMN = "TemperatureProbeCnt";	
	
	/**
	 * 列名：このバッグ動力バッテリー温度プローブ数m
	 */
	static final String TEMPERATURE_PROBE_COUNT_IN_A_PACK_COLUMN = "TemperatureProbeCount";
	/**
	 * 列名：プローブ温度値
	 */
	static final String TEMPERATUR_VALUES_COLUMN = "TemperatureValues";
	
	/**
	 * 列名：スピード
	 */
	static final String SPEED_COLUMN = "Speed";	
	/**
	 * 列名：マイレージ
	 */
	static final String MILEAGE_COLUMN = "Mileage";	
	/**
	 * 列名：ギヤ
	 */
	static final String GEAR_COLUMN = "Gear";	
	/**
	 * 列名：加速ペダルストローク値
	 */
	static final String ACCELERATED_PEDAL_TRIP_COLUMN = "AcceleratedPedalTrip";
	/**
	 * 列名：ブレーキペダルストローク値
	 */
	static final String BRAKE_PEDAL_TRIP_COLUMN = "BrakePedalTrip";
	/**
	 * 列名：充放電状態
	 */
	static final String CHARGESTATUS_COLUMN = "ChargeStatus";
	/**
	 * 列名：モータコントローラ温度
	 */
	static final String MOTOR_CNTL_TEMPERATURE_COLUMN = "MotorCntlTemperature";
	/**
	 * 列名：モータ回転
	 */
	static final String MOTOR_SPEED_COLUMN = "MotorSpeed";
	/**
	 * 列名：モータ温度
	 */
	static final String MOTOR_TEMPERATURE_COLUMN = "MotorTemperature";
	/**
	 * 列名：モータ電圧
	 */
	static final String MOTOR_VOLTAGE_COLUMN = "MotorVoltage";
	/**
	 * 列名：モータ電流
	 */
	static final String MOTOR_CURRENT_COLUMN = "MotorCurrent";
	/**
	 * 列名：エアコンの設定温度
	 */
	static final String AIR_CONDITION_TEMPERATURE_COLUMN = "AirConditionTemperature";
	
	/**
	 * 列名：位置状態
	 */
	static final String POSITIONING_STATE_COLUMN = "PositioningState";
	/**
	 * 列名：経度
	 */
	static final String LONGITUDE_COLUMN = "Longitude";
	/**
	 * 列名：緯度
	 */
	static final String LATITUDE_COLUMN = "Latitude";
	/**
	 * 列名：方向
	 */
	static final String DIRECTION_COLUMN = "Direction";
	
	/**
	 * 列名：最高電圧動力バッテリー単体所在バッテリーパック番号
	 */
	static final String MAX_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN = "MaxVoltageBatteryPackNumber";
	/**
	 * 列名：最高電圧単体バッテリー番号
	 */
	static final String MAX_VOLTAGE_BATTERY_NUMBER_COLUMN = "MaxVoltageBatteryNumber";
	/**
	 * 列名：バッテリー単体電圧最高値
	 */
	static final String BATTERY_MAX_VOLTAGE_COLUMN = "BatteryMaxVoltage";
	/**
	 * 列名：最低電圧動力バッテリーパック番号
	 */
	static final String MIN_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN = "MinVoltageBatteryPackNumber";
	/**
	 * 列名：最低電圧単体バッテリー番号
	 */
	static final String MIN_VOLTAGE_BATTERY_NUMBER_COLUMN = "MinVoltageBatteryNumber";
	/**
	 * 列名：バッテリー単体電圧の最低値
	 */
	static final String BATTERY_MIN_VOLTAGE_COLUMN = "BatteryMinVoltage";
	/**
	 * 列名：最高温度動力バッテリーパック番号
	 */
	static final String MAX_TEMP_BATTERY_PACK_NUMBER_COLUMN = "MaxTempBatteryPackNumber";
	/**
	 * 列名：最高温度プローブ番号
	 */
	static final String MAX_TEMP_PROBE_NUMBER_COLUMN = "MaxTempProbeNumber";
	/**
	 * 列名：最高温度値
	 */
	static final String MAX_TEMPERATURE_COLUMN = "MaxTemperature";
	/**
	 * 列名：最低温度動力バッテリーパック番号
	 */
	static final String MIN_TEMP_BATTERY_PACK_NUMBER_COLUMN = "MinTempBatteryPackNumber";
	/**
	 * 列名：最低温度プローブ番号
	 */
	static final String MIN_TEMP_PROBE_NUMBER_COLUMN = "MinTempProbeNumber";	
	/**
	 * 列名：最低温度値
	 */
	static final String MIN_TEMPERATURE_COLUMN = "MinTemperature";	
	/**
	 * 列名：総電圧
	 */
	static final String TOTAL_VOLTAGE_COLUMN = "TotalVoltage";	
	/**
	 * 列名：総電流
	 */
	static final String TOTAL_CURRENT_COLUMN = "TotalCurrent";
	/**
	 * 列名：SOC
	 */
	static final String SOC_COLUMN = "SOC";	
	/**
	 * 列名：余剰エネルギー
	 */
	static final String REMAIN_ENERGY_COLUMN = "RemainEnergy";	
	/**
	 * 列名：絶縁抵抗
	 */
	static final String INSULATION_RESISTANCE_COLUMN = "InsulationResistance";	
	
	/**
	 * 列名：動力バッテリー警報マーク
	 */
	static final String BATTERY_ALARM_FLAG_COLUMN = "BatteryAlarmFlag";
	/**
	 * 列名：動力バッテリー他の故障数n
	 */
	static final String BATTERY_OTHER_FAULTS_CNT_COLUMN = "BatteryOtherFaultsCnt";
	/**
	 * 列名：電機故障数N
	 */
	static final String MOTOR_FAULTS_CNT_COLUMN = "MotorFaultsCnt";
	/**
	 * 列名：他の故障数M
	 */
	static final String OTHER_FAULTS_CNT_COLUMN = "OtherFaultsCnt";
	
	/**
	 * 列名：動力バッテリー他の故障コード
	 */
	static final String BATTERY_OTHER_FAULT_CODES_COLUMN = "BatteryOtherFaultCodes";
	
	/**
	 * 列名：電機故障コード
	 */
	static final String MOTOR_FAULT_CODES_COLUMN = "MotorFaultCodes";
	
	/**
	 * 列名：他の故障コード
	 */
	static final String OTHER_FAULT_CODES_COLUMN = "OtherFaultCodes";

	/**
	 * 登録履歴のデータプールのデータリスト
	 */
	static ArrayList<RegistData> mRegistDataList = new ArrayList<RegistData>();
	/**
	 * 車載端末状態情報のデータプールのデータリスト
	 */
	static ArrayList<StatusData> mStatusDataList = new ArrayList<StatusData>();
	/**
	 * 動力バッテリー電圧のデータプールのデータリスト
	 */
	static ArrayList<RealTimeVoltageData> mRealTimeVoltageDataList = new ArrayList<RealTimeVoltageData>();
	/**
	 * 動力バッテリー温度のデータプールのデータリスト
	 */
	static ArrayList<RealTimeTemperatureData> mRealTimeTemperatureDataList = new ArrayList<RealTimeTemperatureData>();
	/**
	 * 車両データのデータプールのデータリスト
	 */
	static ArrayList<RealTimeVehicleData> mRealTimeVehicleDataList = new ArrayList<RealTimeVehicleData>();
	/**
	 * 位置データのデータプールのデータリスト
	 */
	static ArrayList<RealTimeGPSData> mRealTimeGPSDataList = new ArrayList<RealTimeGPSData>();
	/**
	 * 極値データのデータプールのデータリスト
	 */
	static ArrayList<RealTimeExtremumData> mRealTimeExtremumDataList = new ArrayList<RealTimeExtremumData>();
	/**
	 * 警報データのデータプールのデータリスト
	 */
	static ArrayList<RealTimeAlarmData> mRealTimeAlarmDataList = new ArrayList<RealTimeAlarmData>();

	/**
	 * データプールに睡眠の登録履歴のデータリストを保存
	 */
	static ArrayList<RegistData> mRegistDataSleepThreads = new ArrayList<RegistData>();
	/**
	 * データプールに車載端末状態情報のデータリストを保存
	 */
	static ArrayList<StatusData> mStatusDataSleepThreads = new ArrayList<StatusData>();
	/**
	 * データプールに動力バッテリー電圧のデータリストを保存
	 */
	static ArrayList<RealTimeVoltageData> mRealTimeVoltageDataSleepThreads = new ArrayList<RealTimeVoltageData>();
	/**
	 * データプールに動力バッテリー温度のデータリストを保存
	 */
	static ArrayList<RealTimeTemperatureData> mRealTimeTemperatureDataSleepThreads = new ArrayList<RealTimeTemperatureData>();
	/**
	 * データプールに車両データのデータリストを保存
	 */
	static ArrayList<RealTimeVehicleData> mRealTimeVehicleDataSleepThreads = new ArrayList<RealTimeVehicleData>();
	/**
	 * データプールに位置データのデータリストを保存
	 */
	static ArrayList<RealTimeGPSData> mRealTimeGPSDataSleepThreads = new ArrayList<RealTimeGPSData>();
	/**
	 * データプールに極値データのデータリストを保存
	 */
	static ArrayList<RealTimeExtremumData> mRealTimeExtremumDataSleepThreads = new ArrayList<RealTimeExtremumData>();
	/**
	 * データプールに警報データのデータリストを保存
	 */
	static ArrayList<RealTimeAlarmData> mRealTimeAlarmDataSleepThreads = new ArrayList<RealTimeAlarmData>();
	
	static boolean isWait = false;
	/**
	 * dbの処理スレッドのインスタンス.
	 */
	static ThreadDB mDbThread = new ThreadDB();
	
	/**
	 * dbの処理スレッドのインスタンスを取得します.
	 * 
	 * @param null
	 *            
	 * @return dbの処理スレッドのインスタンス
	 */
	public static ThreadDB getDbThread() {
		return mDbThread;
	}

	public static class ThreadDB extends Thread {
		/**
		 * DBスレッドを創建と初期化
		 * 
		 * @param null
		 *            
		 * @return null
		 */
		ThreadDB() {
			// regist

			Common.printString("DBManager.ThreadDB",
					"ThreadDB create start ...");
			try {
				String cmd = registDataBasicInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				cmd = registDataBatteryEncodeTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				cmd = registDataLoginTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// status
				cmd = statusDataInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// real time info id
				cmd = realTimeInfoIdTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// RealTimeVoltage
				cmd = realTimeVoltageDataInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				cmd = realTimeVoltageDataValueInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// RealTimeTemperature
				cmd = realTimeTemperatureDataInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				cmd = realTimeTemperatureDataValueInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// vehicle
				cmd = realTimeVehicleDataInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// GPS
				cmd = realTimeGPSDataInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// Extremum
				cmd = realTimeExtremumDataInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				// alarm
				cmd = realTimeAlarmDataInfoTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				cmd = realTimeAlarmBatteryOtherFaultCodesTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				cmd = realTimeAlarmMotorFaultCodesTableCreate();
				DBProcess.getInstance().tableCreate(cmd);

				cmd = realTimeAlarmOtherFaultCodesTableCreate();
				DBProcess.getInstance().tableCreate(cmd);
				
				Common.printString("DBManager.ThreadDB",
					"ThreadDB create success!!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
		}

		/**
		 * DBスレッドを運行
		 * 
		 * @param null
		 *            
		 * @return null
		 */
		public void run() {
			Common.printString("DBManager.ThreadDB", "ThreadDB running ...");
			
			while (true) {
				if (Common.getServerShutDown()) {
					DBProcess.getInstance().close();
					return;
				}
				if (dataPoolIsempty()) {
					threadWait();
				}

				registDataDBProcess();
				statusDataDBProcess();
				realTimeVoltageDBProcess();
				realTimeTemperatureDBProcess();
				realTimeVehicleDBProcess();
				realTimeGPSDBProcess();
				realTimeExtremumDBProcess();
				realTimeAlarmDBProcess();
			}
		}
	}

	/**
	 * dbの処理スレッドのインスタンスを取得します.
	 * 
	 * @param rtii
	 *            RealTimeInfoId類
	 * @return RealTimeInfoId
	 */
	static RealTimeInfoId realTimeInfoIdGet(RealTimeInfoId rtii) {
		String cmd = realTimeInfoIdQuery(rtii);
		rtii = DBProcess.getInstance().realTimeInfoIdLastIdSearch(cmd);

		return rtii;
	}

	/**
	 * 登録データを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean registDataDBProcess() {
		int cnt = mRegistDataSleepThreads.size();
		if (cnt > 0) {
			if (mRegistDataList.size() < MAX_SIZE) {
				RegistData rd = mRegistDataSleepThreads.remove(0);
				synchronized (rd) {
					rd.notify();
				}
			}
		}

		if (!mRegistDataList.isEmpty()) {
			RegistData registData = mRegistDataList.remove(0);
			// 查看数据是否已经插入表中
			String cmd = registDataBasicInfoQuery(registData);
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				cmd = registDataBasicInfoInsert(registData);
				DBProcess.getInstance().dataInsert(cmd); // 表1
				ArrayList<String> cmds = registDataBatteryEncodeInsert(registData);
				for (int i=0; i< cmds.size(); i++) {
					String str = cmds.get(i);
					BatteryPacket bp = registData.getBatteryPackets().get(i);
					
					DBProcess.getInstance().dataInsert(str, bp.getPackEncodeMakeDate()); // 表2
				}
			}
			cmd = registDataLoginInsert(registData);
			DBProcess.getInstance().dataInsert(cmd); // 表3
			return true;
		}
		return false;
	}

	/**
	 * DCMの情報データを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean statusDataDBProcess() {
		int cnt = mStatusDataSleepThreads.size();
		if (cnt > 0) {
			if (mStatusDataList.size() < MAX_SIZE) {
				StatusData sd = mStatusDataSleepThreads.remove(0);
				synchronized (sd) {
					sd.notify();
				}
			}
		}

		if (!mStatusDataList.isEmpty()) {
			StatusData statusData = mStatusDataList.remove(0);
			// 查看数据是否已经插入表中
			String cmd = statusDataInfoQuery(statusData);
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				cmd = statusDataInfoInsert(statusData);
				DBProcess.getInstance().dataInsert(cmd); // 表1
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * DCMの電池電圧データを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean realTimeVoltageDBProcess() {
		int cnt = mRealTimeVoltageDataSleepThreads.size();
		if (cnt > 0) {
			if (mRealTimeVoltageDataList.size() < MAX_SIZE) {
				RealTimeVoltageData rtvd = mRealTimeVoltageDataSleepThreads
						.remove(0);
				synchronized (rtvd) {
					rtvd.notify();
				}
			}
		}

		if (!mRealTimeVoltageDataList.isEmpty()) {
			RealTimeVoltageData realTimeVoltageData = mRealTimeVoltageDataList
					.remove(0);
			// 判断是否需要更新实时ID表
			String carNumber = realTimeVoltageData.getCarNumber();
			String dateTime = realTimeVoltageData.getDateTime();
			
			DcmLocalParam dcmLocalParam = dcmLocalParamUpdateAndInfoIdInsert(carNumber, dateTime);
			if(dcmLocalParam == null) {
				return false;
			}
			
			// 查看数据是否已经插入表中
			String cmd = realTimeVoltageDataInfoQuery(dcmLocalParam.getRealTimeInfoId());
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				// 将数据插入到表中
				cmd = realTimeVoltageDataInfoInsert(realTimeVoltageData,
						dcmLocalParam.getRealTimeInfoId());
				DBProcess.getInstance().dataInsert(cmd); // 表1

				ArrayList<String> cmds = realTimeVoltageDataValueInfoInsert(
						realTimeVoltageData, dcmLocalParam.getRealTimeInfoId());
				for (String str : cmds) {
					DBProcess.getInstance().dataInsert(str); // 表2
				}
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * DCMの電池温度データを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean realTimeTemperatureDBProcess() {
		int cnt = mRealTimeTemperatureDataSleepThreads.size();
		if (cnt > 0) {
			if (mRealTimeTemperatureDataList.size() < MAX_SIZE) {
				RealTimeTemperatureData rttd = mRealTimeTemperatureDataSleepThreads
						.remove(0);
				synchronized (rttd) {
					rttd.notify();
				}
			}
		}

		if (!mRealTimeTemperatureDataList.isEmpty()) {
			RealTimeTemperatureData realTimeTemperatureData = mRealTimeTemperatureDataList
					.remove(0);
			// 判断是否需要更新实时ID表
			String carNumber = realTimeTemperatureData.getCarNumber();
			String dateTime = realTimeTemperatureData.getDateTime();
			
			DcmLocalParam dcmLocalParam = dcmLocalParamUpdateAndInfoIdInsert(carNumber, dateTime);
			if(dcmLocalParam == null) {
				return false;
			}

			// 查看数据是否已经插入表中
			String cmd = realTimeTemperatureDataInfoQuery(dcmLocalParam.getRealTimeInfoId());
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				// 将数据插入到表中
				cmd = realTimeTemperatureDataInfoInsert(
						realTimeTemperatureData,
						dcmLocalParam.getRealTimeInfoId());
				DBProcess.getInstance().dataInsert(cmd); // 表1

				ArrayList<String> cmds = realTimeTemperatureDataValueInfoInsert(
						realTimeTemperatureData,
						dcmLocalParam.getRealTimeInfoId());
				for (String str : cmds) {
					DBProcess.getInstance().dataInsert(str); // 表2
				}
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * DCMの車両データを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean realTimeVehicleDBProcess() {
		int cnt = mRealTimeVehicleDataSleepThreads.size();
		if (cnt > 0) {
			if (mRealTimeVehicleDataList.size() < MAX_SIZE) {
				RealTimeVehicleData rtvd = mRealTimeVehicleDataSleepThreads
						.remove(0);
				synchronized (rtvd) {
					rtvd.notify();
				}
			}
		}

		if (!mRealTimeVehicleDataList.isEmpty()) {
			RealTimeVehicleData realTimeVehicleData = mRealTimeVehicleDataList
					.remove(0);
			// 判断是否需要更新实时ID表
			String carNumber = realTimeVehicleData.getCarNumber();
			String dateTime = realTimeVehicleData.getDateTime();
			
			DcmLocalParam dcmLocalParam = dcmLocalParamUpdateAndInfoIdInsert(carNumber, dateTime);
			if(dcmLocalParam == null) {
				return false;
			}
			
			// 查看数据是否已经插入表中
			String cmd = realTimeVehicleDataInfoQuery(dcmLocalParam.getRealTimeInfoId());
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				// 将数据插入到表中
				cmd = realTimeVehicleDataInfoInsert(realTimeVehicleData,
						dcmLocalParam.getRealTimeInfoId());
				DBProcess.getInstance().dataInsert(cmd); // 表1
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
	
	/**
	 * DCMのGPSデータを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean realTimeGPSDBProcess() {
		int cnt = mRealTimeGPSDataSleepThreads.size();
		if (cnt > 0) {
			if (mRealTimeGPSDataList.size() < MAX_SIZE) {
				RealTimeGPSData rtvd = mRealTimeGPSDataSleepThreads.remove(0);
				synchronized (rtvd) {
					rtvd.notify();
				}
			}
		}

		if (!mRealTimeGPSDataList.isEmpty()) {
			RealTimeGPSData realTimeGPSData = mRealTimeGPSDataList.remove(0);
			// 查看数据是否已经插入表中
			String cmd = realTimeGPSDataInfoQuery(realTimeGPSData);
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				// 将数据插入到表中
				cmd = realTimeGPSDataInfoInsert(realTimeGPSData);
				DBProcess.getInstance().dataInsert(cmd); // 表1
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * DCMの極値データを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean realTimeExtremumDBProcess() {
		int cnt = mRealTimeExtremumDataSleepThreads.size();
		if (cnt > 0) {
			if (mRealTimeExtremumDataList.size() < MAX_SIZE) {
				RealTimeExtremumData rtvd = mRealTimeExtremumDataSleepThreads
						.remove(0);
				synchronized (rtvd) {
					rtvd.notify();
				}
			}
		}

		if (!mRealTimeExtremumDataList.isEmpty()) {
			RealTimeExtremumData realTimeExtremumData = mRealTimeExtremumDataList
					.remove(0);
			// 判断是否需要更新实时ID表
			String carNumber = realTimeExtremumData.getCarNumber();
			String dateTime = realTimeExtremumData.getDateTime();
			
			DcmLocalParam dcmLocalParam = dcmLocalParamUpdateAndInfoIdInsert(carNumber, dateTime);
			if(dcmLocalParam == null) {
				return false;
			}

			// 查看数据是否已经插入表中
			String cmd = realTimeExtremumDataInfoQuery(dcmLocalParam.getRealTimeInfoId());
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				// 将数据插入到表中
				cmd = realTimeExtremumDataInfoInsert(realTimeExtremumData,
						dcmLocalParam.getRealTimeInfoId());
				DBProcess.getInstance().dataInsert(cmd); // 表1
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
	
	/**
	 * DCMのアラームデータを処理
	 * 
	 * @param null
	 *            
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static boolean realTimeAlarmDBProcess() {
		int cnt = mRealTimeAlarmDataSleepThreads.size();
		if (cnt > 0) {
			if (mRealTimeAlarmDataList.size() < MAX_SIZE) {
				RealTimeAlarmData rtvd = mRealTimeAlarmDataSleepThreads
						.remove(0);
				synchronized (rtvd) {
					rtvd.notify();
				}
			}
		}

		if (!mRealTimeAlarmDataList.isEmpty()) {
			RealTimeAlarmData realTimeAlarmData = mRealTimeAlarmDataList.remove(0);
			// 判断是否需要更新实时ID表
			String carNumber = realTimeAlarmData.getCarNumber();
			String dateTime = realTimeAlarmData.getDateTime();
			
			DcmLocalParam dcmLocalParam = dcmLocalParamUpdateAndInfoIdInsert(carNumber, dateTime);
			if(dcmLocalParam == null) {
				return false;
			}
			
			// 查看数据是否已经插入表中
			String cmd = realTimeAlarmDataInfoQuery(dcmLocalParam.getRealTimeInfoId());
			boolean ret = DBProcess.getInstance().dataExistQuery(cmd);
			if (!ret) {
				// 将数据插入到表中
				cmd = realTimeAlarmDataInfoInsert(realTimeAlarmData,
						dcmLocalParam.getRealTimeInfoId());
				DBProcess.getInstance().dataInsert(cmd); // 表1

				ArrayList<String> cmds = realTimeAlarmBatteryOtherFaultCodesInsert(
						realTimeAlarmData, dcmLocalParam.getRealTimeInfoId());
				for (String str : cmds) {
					DBProcess.getInstance().dataInsert(str); // 表2
				}
				cmds = realTimeAlarmMotorFaultCodesInsert(realTimeAlarmData,
						dcmLocalParam.getRealTimeInfoId());
				for (String str : cmds) {
					DBProcess.getInstance().dataInsert(str); // 表3
				}
				cmds = realTimeAlarmOtherFaultCodesInsert(realTimeAlarmData,
						dcmLocalParam.getRealTimeInfoId());
				for (String str : cmds) {
					DBProcess.getInstance().dataInsert(str); // 表4
				}
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * サーバーの本地のパラメータデータを更新し、DBにリアルタイムデータを添加
	 * 
	 * @param carNumber
	 * 			車のナンバー
	 * @param dateTime
	 *          日付時間
	 * @return データを挿入成功場合、trueを返し、でなければfalseを返し
	 */
	static DcmLocalParam dcmLocalParamUpdateAndInfoIdInsert(String carNumber, String dateTime){
		DcmLocalParam dcmLocalParam = DataManager
				.getDcmLocalParamByString(carNumber);
		if (dcmLocalParam == null) {
			return null;
		}
		String dt = dcmLocalParam.getRealTimeUpdateTime();
		if (dt == null || !dt.equals(dateTime)) {

			String cmd = realTimeInfoIdQuery();
			RealTimeInfoId rtiid = DBProcess.getInstance()
					.realTimeInfoIdLastIdSearch(cmd);

			if(rtiid == null) {
				rtiid = new RealTimeInfoId();
				rtiid.setInfoId(0);
			} else {
				rtiid.setInfoId(rtiid.getInfoId() + 1);
			}
			rtiid.setCarNumber(carNumber);
			rtiid.setDateTime(dateTime);

			cmd = realTimeInfoIdInsert(rtiid);
			DBProcess.getInstance().dataInsert(cmd); // 表
			

			dcmLocalParam.setRealTimeUpdateTime(rtiid.getDateTime());
			dcmLocalParam.setRealTimeInfoId(rtiid.getInfoId());
		}
		
		return dcmLocalParam;
	}
	
	/**
	 * 処理する必要のデータが有るかどうかを判断
	 * 
	 * @param null
	 * 			
	 * @return　データはnull場合、trueを返し、でなければfalseを返し
	 */
	static boolean dataPoolIsempty() {
		if (!mRegistDataList.isEmpty() || !mStatusDataList.isEmpty()
				|| !mRealTimeVoltageDataList.isEmpty()
				|| !mRealTimeTemperatureDataList.isEmpty()
				|| !mRealTimeVehicleDataList.isEmpty()
				|| !mRealTimeGPSDataList.isEmpty()
				|| !mRealTimeExtremumDataList.isEmpty()
				|| !mRealTimeAlarmDataList.isEmpty()) {
			
			return false;
		}
		return true;
	}

	/**
	 * 車両の基本情報表を建立の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String registDataBasicInfoTableCreate() {
		String createSql = "create table if not exists " + BASIC_INFO_TABLE
				+ "(" 
				+ CARNUNBER_COLUMN + " varchar(8)," 
				+ MAKERCODE_COLUMN + " varchar(4)," 
				+ TERMINAL_NUMBER_COLUMN + " varchar(6),"
				+ SERIAL_NUMBER_COLUMN + " smallint(2),"
				+ BATTERY_PACK_COUNT_COLUMN + " tinyint(1) unsigned,"
				+ RESERVE_COLUMN + " smallint(11)"
				+ ");";

		return createSql;
	}

	/**
	 * 車両の基本情報表にデータを挿入の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static String registDataBasicInfoInsert(RegistData rd) {
		String sql = "INSERT INTO "+ BASIC_INFO_TABLE
				+"(" 
				+ CARNUNBER_COLUMN + ","
				+ MAKERCODE_COLUMN + ","
				+ TERMINAL_NUMBER_COLUMN + ","
				+ SERIAL_NUMBER_COLUMN + ","
				+ BATTERY_PACK_COUNT_COLUMN  
				+ ") values('"
				+ rd.getCarNumber()
				+ "','"
				+ rd.getMakerCode()
				+ "','"
				+ rd.getTerminalNumber()
				+ "','"
				+ rd.getSerialNumber()
				+ "','"
				+ rd.getBatteryPackCount() 
				+ "');";
		
		return sql;
	}

	/**
	 * 車両の基本情報表のデータを更新の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static String registDataBasicInfoUpdate(RegistData rd) {
		String sql = "update " + BASIC_INFO_TABLE 
				+ " set " 
				+ MAKERCODE_COLUMN + "='" + rd.getMakerCode() + "',"
				+ TERMINAL_NUMBER_COLUMN + "='" + rd.getTerminalNumber() + "',"
				+ SERIAL_NUMBER_COLUMN + "='" + rd.getSerialNumber() + "',"
				+ BATTERY_PACK_COUNT_COLUMN + "='" + rd.getBatteryPackCount() + "'"
				+ " where "
				+ CARNUNBER_COLUMN + " = '" + rd.getCarNumber() + "'";
		
		return sql;
	}
	
	/**
	 * 車両の基本情報表からデータを削除の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static String registDataBasicInfoDelete(RegistData rd) {
		String sql = "delete FROM "+ BASIC_INFO_TABLE 
				+ " WHERE " 
				+ CARNUNBER_COLUMN + " = '" + rd.getCarNumber() + "'";
		
		return sql;
	}
	
	/**
	 * 車両の基本情報表からデータを検索の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static String registDataBasicInfoQuery(RegistData rd) {
		String sql = "select * from " + BASIC_INFO_TABLE 
				+ " where "
				+ CARNUNBER_COLUMN + " = '" + rd.getCarNumber() + "'";

		return sql;
	}

	/**
	 * 動力蓄電池コード表を建立の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String registDataBatteryEncodeTableCreate() {
		String createSql = "create table if not exists " + BATTERY_CODE_TABLE
				+ "(" 
				+ CARNUNBER_COLUMN + " varchar(8),"
				+ BATTERY_PACK_SERIAL_NUMBER_COLUMN + " smallint(1),"
				+ PACK_ENCODE_MAKER_COLUMN + " varchar(4),"
				+ PACK_ENCODE_BTTYTYPE_COLUMN + " smallint(1),"
				+ PACK_ENCODE_RATED_ENERY_COLUMN + " smallint(2),"
				+ PACK_ENCODE_RATED_VOLTAGE_COLUMN + " smallint(2),"
				+ PACK_ENCODE_MAKE_DATE_COLUMN + " BLOB(3),"
				+ SERIAL_NUMBER_COLUMN + " smallint(2)," 
				+ RESERVE_COLUMN + " smallint(5)"
				+ ");";

		return createSql;
	}

	/**
	 * 動力蓄電池コード表にデータを挿入の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static ArrayList<String> registDataBatteryEncodeInsert(RegistData rd) {
		ArrayList<String> b = new ArrayList<String>();
		for (BatteryPacket bp : rd.getBatteryPackets()) {
			String sql = "INSERT INTO "+ BATTERY_CODE_TABLE
					+ "("
					+ CARNUNBER_COLUMN + "," 
					+ BATTERY_PACK_SERIAL_NUMBER_COLUMN + "," 
					+ PACK_ENCODE_MAKER_COLUMN + "," 
					+ PACK_ENCODE_BTTYTYPE_COLUMN + "," 
					+ PACK_ENCODE_RATED_ENERY_COLUMN + "," 
					+ PACK_ENCODE_RATED_VOLTAGE_COLUMN + "," 
					+ PACK_ENCODE_MAKE_DATE_COLUMN + "," 
					+ SERIAL_NUMBER_COLUMN 
					+ ") values('"
					+ rd.getCarNumber()
					+ "','"
					+ bp.getBatteryPackSerialNumber()
					+ "','"
					+ bp.getPackEncodeMaker()
					+ "','"
					+ bp.getPackEncodeBttyType()
					+ "','"
					+ bp.getPackEncodeRatedEnery()
					+ "','"
					+ bp.getPackEncodeRatedVoltage()
					+ "',"
					+ "?"
					+ ",'"
					+ bp.getSerialNumber()
					+ "');";
			
			b.add(sql);
		}
		return b;
	}

	/**
	 * 動力蓄電池コード表のデータを更新の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static ArrayList<String> registDataBatteryEncodeUpdate(RegistData rd) {
		ArrayList<String> b = new ArrayList<String>();
		for (BatteryPacket bp : rd.getBatteryPackets()) {
			String sql = "update " + BATTERY_CODE_TABLE 
					+ " set "
					+ BATTERY_PACK_SERIAL_NUMBER_COLUMN + "='"+ bp.getBatteryPackSerialNumber() + "',"
					+ PACK_ENCODE_MAKER_COLUMN + "='" + bp.getPackEncodeMaker() + "'," 
					+ PACK_ENCODE_BTTYTYPE_COLUMN + "='"	+ bp.getPackEncodeBttyType() + "'," 
					+ PACK_ENCODE_RATED_ENERY_COLUMN + "='" + bp.getPackEncodeRatedEnery() + "'," 
					+ PACK_ENCODE_RATED_VOLTAGE_COLUMN + "='"	+ bp.getPackEncodeRatedVoltage() + "'," 
					+ PACK_ENCODE_MAKE_DATE_COLUMN +"=" +"?"+"," 
					+ SERIAL_NUMBER_COLUMN + "='" + bp.getSerialNumber() + "'"
					+ " where " 
					+ CARNUNBER_COLUMN+" = '" + rd.getCarNumber() + "'";
			
			b.add(sql);
		}
		return b;
	}
	
	/**
	 * 動力蓄電池コード表からデータを削除の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static ArrayList<String> registDataBatteryEncodeDelete(RegistData rd) {
		ArrayList<String> b = new ArrayList<String>();
		String sql = "delete FROM " + BATTERY_CODE_TABLE 
				+ " WHERE "
				+ CARNUNBER_COLUMN + " = '" + rd.getCarNumber() + "'";
		
		b.add(sql);
		
		return b;
	}

	/**
	 * 登録履歴表を建立の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String registDataLoginTableCreate() {
		String sql = "create table if not exists " + LOGIN_TABLE 
				+ "("
				+ CARNUNBER_COLUMN + " varchar(8)," 
				+ DATE_TIME_COLUMN + " DATETIME,"
				+ REGIST_SERIAL_NUMBER_COLUMN + " smallint(2) unsigned"
				+ ");";
		
		return sql;
	}
	
	/**
	 * 登録履歴表にデータを挿入の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static String registDataLoginInsert(RegistData rd) {
		String sql = "INSERT INTO "+ LOGIN_TABLE
				+ "("
				+ CARNUNBER_COLUMN+ "," 
				+ DATE_TIME_COLUMN+ ","
				+ REGIST_SERIAL_NUMBER_COLUMN
				+ ") values('"
				+ rd.getCarNumber()
				+ "','"
				+ rd.getDateTime()
				+ "','"
				+ rd.getRegistSerialNumber() 
				+ "');";
		
		return sql;
	}

	/**
	 * 登録履歴表のデータを更新の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static String registDataLoginUpdate(RegistData rd) {
		String sql = "update "+ LOGIN_TABLE
				+ " set " 
				+ DATE_TIME_COLUMN + "='" + rd.getDateTime() + "'," 
				+ REGIST_SERIAL_NUMBER_COLUMN + "='" + rd.getRegistSerialNumber() + "'"
				+ " where " 
				+ CARNUNBER_COLUMN+" = '" + rd.getCarNumber() + "'";
		
		return sql;
	}
	
	/**
	 * 登録履歴表からデータを削除の命令を作成
	 * 
	 * @param rd
	 * 			mRegistDataListのデータ
	 * @return　データベースの文字列
	 */
	static String registDataLoginDelete(RegistData rd) {
		String sql = "delete FROM " + LOGIN_TABLE
				+" WHERE "
				+ CARNUNBER_COLUMN + " = '" + rd.getCarNumber() + "'";
		
		return sql;
	}

	/**
	 * 車載端末状態情報表を建立の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String statusDataInfoTableCreate() {
		String sql = "create table if not exists " + TERMINAL_STATUS_TABLE 
				+ "(" 
				+ CARNUNBER_COLUMN + " varchar(8),"
				+ DATE_TIME_COLUMN + " DATETIME," 
				+ STATUS_COLUMN + " smallint(1),"
				+ RESERVE_COLUMN + " smallint(4)"
				+ ");";
		
		return sql;
	}
	
	/**
	 * 車載端末状態情報表にデータを挿入の命令を作成
	 * 
	 * @param sd
	 * 			StatusDataのデータ
	 * @return　データベースの文字列
	 */
	static String statusDataInfoInsert(StatusData sd) {
		String sql = "INSERT INTO " + TERMINAL_STATUS_TABLE
				+"("
				+ CARNUNBER_COLUMN + "," 
				+ DATE_TIME_COLUMN + "," 
				+ STATUS_COLUMN 
				+ ") values('"
				+ sd.getCarNumber()
				+ "','"
				+ sd.getDateTime()
				+ "','"
				+ sd.getStatus() 
				+ "');";
		
		return sql;
	}

	/**
	 * 車載端末状態情報表のデータを更新の命令を作成
	 * 
	 * @param sd
	 * 			StatusDataのデータ
	 * @return　データベースの文字列
	 */
	static String statusDataInfoUpdate(StatusData sd) {
		String sql = "update " + TERMINAL_STATUS_TABLE
				+" set "
				+ STATUS_COLUMN + "='" + sd.getStatus() + "'"
				+ " where "
				+ CARNUNBER_COLUMN + " = '" + sd.getCarNumber() + "'"
				+ " and "
				+ DATE_TIME_COLUMN + " = '" + sd.getDateTime() + "'";
		
		return sql;
	}
	
	/**
	 * 車載端末状態情報表からデータを削除の命令を作成
	 * 
	 * @param sd
	 * 			StatusDataのデータ
	 * @return　データベースの文字列
	 */
	static String statusDataInfoDelete(StatusData sd) {
		String sql = "delete FROM " + TERMINAL_STATUS_TABLE
				+ " WHERE "
				+ CARNUNBER_COLUMN + " = '" + sd.getCarNumber() + "'"
				+ " and "
				+ DATE_TIME_COLUMN + " = '" + sd.getDateTime() + "'";
		
		return sql;
	}

	/**
	 * 車載端末状態情報表からデータを検索の命令を作成
	 * 
	 * @param sd
	 * 			StatusDataのデータ
	 * @return　データベースの文字列
	 */
	static String statusDataInfoQuery(StatusData sd) {
		String sql = "select * FROM " + TERMINAL_STATUS_TABLE
				+ " WHERE "
				+ CARNUNBER_COLUMN + " = '" + sd.getCarNumber() + "'"
				+ " and "
				+ DATE_TIME_COLUMN + " = '" + sd.getDateTime() + "'";
		
		return sql;
	}

	/**
	 * 車両のリアルタイムの情報ID表を建立の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeInfoIdTableCreate() {
		String sql = "create table if not exists " + REAL_TIME_INFO_ID_TABLE 
				+ "(" 
				+ CARNUNBER_COLUMN + " varchar(8),"
				+ DATE_TIME_COLUMN + " DATETIME," 
				+ INFOID_COLUMN + " bigint(8) unsigned);";

		return sql;
	}

	/**
	 * 車両のリアルタイムの情報ID表にデータを挿入の命令を作成
	 * 
	 * @param infoId
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeInfoIdInsert(RealTimeInfoId infoId) {
		String sql = "INSERT INTO " + REAL_TIME_INFO_ID_TABLE
				+ "("
				+ CARNUNBER_COLUMN + "," 
				+ DATE_TIME_COLUMN + "," 
				+ INFOID_COLUMN
				+ ") values('"
				+ infoId.getCarNumber()
				+ "','"
				+ infoId.getDateTime()
				+ "','"
				+ infoId.getInfoId() 
				+ "');";
		
		return sql;
	}

	/**
	 * 車両のリアルタイムの情報ID表からデータを検索の命令を作成
	 * 
	 * @param infoId
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeInfoIdQuery(RealTimeInfoId infoId) {
		String sql = "";
		// 通过车牌时间查找，实时信息Id号，或者是通过实时信息Id号来查找车牌号和时间
		if (infoId.getInfoId() != RealTimeInfoId.DEFAULT_INFO_ID) {
			sql = "select * from " + REAL_TIME_INFO_ID_TABLE 
					+ " where "
					+ INFOID_COLUMN + "=" + infoId.getInfoId();
		} else if (infoId.getCarNumber() != null && infoId.getCarNumber() != "") {
			sql = "select * from " + REAL_TIME_INFO_ID_TABLE 
					+ " where "
					+ CARNUNBER_COLUMN + "='" + infoId.getCarNumber() + "'";
			
			if (!Common.isStringNull(infoId.getDateTime())) {
				sql += " and " + DATE_TIME_COLUMN + "='" + infoId.getDateTime() + "'";
			} 
		}
		return sql;
	}

	/**
	 * 車両のリアルタイムの情報ID表からデータを検索の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeInfoIdQuery() {
		String sql = "select * from " + REAL_TIME_INFO_ID_TABLE;
		
		return sql;
	}

	/**
	 * 単体バッテリー電圧表を建立の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeVoltageDataInfoTableCreate() {
		String sql = "create table if not exists " + BATTERY_VOLTAGE_PACK_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ BATTERY_COUNT_COLUMN + " smallint(2) unsigned,"
				+ BATTERY_PACK_COUNT_COLUMN + " tinyint(1) unsigned" 
				+ ");";

		return sql;
	}
	
	/**
	 * 単体バッテリー電圧表にデータを挿入の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVoltageData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVoltageDataInfoInsert(RealTimeVoltageData rtvd,
			long infoid) {
		String sql = "INSERT INTO "+ BATTERY_VOLTAGE_PACK_TABLE
				+ "("
				+ INFOID_COLUMN + "," 
				+ BATTERY_COUNT_COLUMN + "," 
				+ BATTERY_PACK_COUNT_COLUMN
				+ ") values("
				+ infoid
				+ ",'"
				+ rtvd.getBatteryCount()
				+ "','"
				+ rtvd.getBatteryPackCount() 
				+ "');";
		
		return sql;
	}
	
	/**
	 * 単体バッテリー電圧表のデータを更新の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVoltageData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVoltageDataInfoUpdate(RealTimeVoltageData rtvd,
			long infoid) {
		String sql = "update " + BATTERY_VOLTAGE_PACK_TABLE
				+ " set "
				+ BATTERY_COUNT_COLUMN + "='" + rtvd.getBatteryCount() + "',"
				+ BATTERY_PACK_COUNT_COLUMN + "='" + rtvd.getBatteryPackCount() + "'"
				+ " where "
				+ INFOID_COLUMN + " = " + infoid;
		
		return sql;
	}

	/**
	 * 単体バッテリー電圧表からデータを削除の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVoltageData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVoltageDataInfoDelete(RealTimeVoltageData rtvd,
			long infoid) {
		String sql = "delete FROM " + BATTERY_VOLTAGE_PACK_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoid;
		
		return sql;
	}
	
	/**
	 * 単体バッテリー電圧表からデータを検索の命令を作成
	 * 
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVoltageDataInfoQuery(long infoId) {
		String sql = "select * FROM " + BATTERY_VOLTAGE_PACK_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoId;
		
		return sql;
	}
	
	/**
	 * 動力バッテリー電圧値表を建立の命令を作成
	 * 
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeVoltageDataValueInfoTableCreate() {
		String sql = "create table if not exists " + BATTERY_VOLTAGE_VALUE_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ BATTERY_PACKET_SEQUENCE_COLUMN + " tinyint(1) unsigned,"
				+ BATTERY_COUNT_COLUMN + " tinyint(1) unsigned," 
				+ VOLTAGE_VALUES_COLUMN + " smallint(2)"
				+ ");";

		return sql;
	}
	
	/**
	 * 動力バッテリー電圧値表にデータを挿入の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVoltageData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeVoltageDataValueInfoInsert(
			RealTimeVoltageData rtvd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (VoltagePacket vp : rtvd.getVoltagePackets()) {
			String sql = "INSERT INTO " + BATTERY_VOLTAGE_VALUE_TABLE
					+ "("
					+ INFOID_COLUMN + ","
					+ BATTERY_PACKET_SEQUENCE_COLUMN + ","
					+ BATTERY_COUNT_COLUMN + ","
					+ VOLTAGE_VALUES_COLUMN 
					+ ") values("
					+ infoid
					+ ",'"
					+ vp.getBatteryPacketSequence()
					+ "','"
					+ vp.getBatteryCount() 
					+ "," 
					+ vp.getVoltageValues() 
					+ "');";
			
			b.add(sql);
		}
		return b;
	}

	/**
	 * 動力バッテリー電圧値表のデータを更新の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVoltageData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeVoltageDataValueInfoUpdate(
			RealTimeVoltageData rtvd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (VoltagePacket vp : rtvd.getVoltagePackets()) {
			String sql = "update " + BATTERY_VOLTAGE_VALUE_TABLE
					+ " set "
					+ BATTERY_PACKET_SEQUENCE_COLUMN +"='" + vp.getBatteryPacketSequence() + "',"
					+ BATTERY_COUNT_COLUMN + "='" + vp.getBatteryCount() + "'," 
					+ VOLTAGE_VALUES_COLUMN + "='" + vp.getVoltageValues() + "'"
					+ " where "
					+ INFOID_COLUMN + "= " + infoid;
			
			b.add(sql);
		}
		return b;
	}


	/**
	 * 動力バッテリー電圧値表からデータを削除の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVoltageData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeVoltageDataValueInfoDelete(
			RealTimeVoltageData rtvd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		String sql = "delete FROM " + BATTERY_VOLTAGE_VALUE_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoid;
		
		b.add(sql);
		return b;
	}

	// RealTimeTemperature
	/**
	 * 動力バッテリーバッグ温度表を建立の命令を作成
	 * 		
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeTemperatureDataInfoTableCreate() {
		String sql = "create table if not exists " + BATTERY_TEMPERATURE_PACK_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ TEMPERATURE_PROBE_CNT_COLUMN + " smallint(2),"
				+ BATTERY_PACK_COUNT_COLUMN + " tinyint(1) unsigned"
				+ ");";
		
		return sql;
	}
	

	/**
	 * 動力バッテリーバッグ温度表にデータを挿入の命令を作成
	 * 
	 * @param rttd
	 * 			RealTimeTemperatureData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeTemperatureDataInfoInsert(
			RealTimeTemperatureData rttd, long infoid) {
		String sql = "INSERT INTO " + BATTERY_TEMPERATURE_PACK_TABLE 
				+ "("
				+ INFOID_COLUMN + "," 
				+ TEMPERATURE_PROBE_CNT_COLUMN + "," 
				+ BATTERY_PACK_COUNT_COLUMN 
				+ ") values("
				+ infoid
				+ ",'"
				+ rttd.getTemperatureProbeCnt()
				+ "','"
				+ rttd.getBatteryPackCount() 
				+ "');";
		
		return sql;
	}
	
	/**
	 * 動力バッテリーバッグ温度表のデータを更新の命令を作成
	 * 
	 * @param rttd
	 * 			RealTimeTemperatureData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */	
	static String realTimeTemperatureDataInfoUpdate(
			RealTimeTemperatureData rttd, long infoid) {
		String sql = "update " + BATTERY_TEMPERATURE_PACK_TABLE
				+ " set " 
				+ TEMPERATURE_PROBE_CNT_COLUMN + "='" + rttd.getTemperatureProbeCnt() + "',"
				+ BATTERY_PACK_COUNT_COLUMN + "='" + rttd.getBatteryPackCount() + "'"
				+ " where "
				+ INFOID_COLUMN + " = " + infoid;
		
		return sql;
	}
	
	/**
	 * 動力バッテリーバッグ温度表からデータを削除の命令を作成
	 * 
	 * @param rttd
	 * 			RealTimeTemperatureData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeTemperatureDataInfoDelete(
			RealTimeTemperatureData rttd, long infoid) {
		String sql = "delete FROM " + BATTERY_TEMPERATURE_PACK_TABLE
				+ " where "
				+ INFOID_COLUMN + " = " + infoid;
		
		return sql;
	}
	
	/**
	 * 動力バッテリーバッグ温度表からデータを検索の命令を作成
	 * 			
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeTemperatureDataInfoQuery(long infoId) {
		String sql = "select * FROM " + BATTERY_TEMPERATURE_PACK_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoId;
		
		return sql;
	}
	
	/**
	 * 動力バッテリー温度値表を建立の命令を作成
	 * 			
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeTemperatureDataValueInfoTableCreate() {
		String sql = "create table if not exists " + BATTERY_TEMPERATURE_VALUE_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ BATTERY_PACKET_SEQUENCE_COLUMN + " tinyint(1) unsigned,"
				+ TEMPERATURE_PROBE_COUNT_IN_A_PACK_COLUMN + " tinyint(1) unsigned," 
				+ TEMPERATUR_VALUES_COLUMN + " tinyint(1) unsigned"
				+ ");";

		return sql;
	}

	/**
	 * 動力バッテリー温度値表にデータを挿入の命令を作成
	 * 
	 * @param rttd
	 * 			RealTimeTemperatureData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeTemperatureDataValueInfoInsert(
			RealTimeTemperatureData rttd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (TemperaturePacket tp : rttd.getTemperaturePackets()) {
			String sql = "INSERT INTO " + BATTERY_TEMPERATURE_VALUE_TABLE
					+ "(" 
					+ INFOID_COLUMN + "," 
					+ BATTERY_PACKET_SEQUENCE_COLUMN + "," 
					+ TEMPERATURE_PROBE_COUNT_IN_A_PACK_COLUMN + "," 
					+ TEMPERATUR_VALUES_COLUMN
					+ ") values("
					+ infoid
					+ ",'"
					+ tp.getBatteryPacketSequence()
					+ "','"
					+ tp.getTemperatureProbeCount()
					+ "','"
					+ tp.getTemperatureValues() 
					+ "');";
			
			b.add(sql);
		}
		return b;
	}

	/**
	 * 動力バッテリー温度値表のデータを更新の命令を作成
	 * 
	 * @param rttd
	 * 			RealTimeTemperatureData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeTemperatureDataValueInfoUpdate(
			RealTimeTemperatureData rttd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (TemperaturePacket tp : rttd.getTemperaturePackets()) {
			String sql = "update " + BATTERY_TEMPERATURE_VALUE_TABLE
					+ " set "
					+ BATTERY_PACKET_SEQUENCE_COLUMN + "='" + tp.getBatteryPacketSequence() + "'," 
					+ TEMPERATURE_PROBE_COUNT_IN_A_PACK_COLUMN + "='" + tp.getTemperatureProbeCount() + "'," 
					+ TEMPERATUR_VALUES_COLUMN + "='" + tp.getTemperatureValues() + "'"
					+ " where "
					+ INFOID_COLUMN + "= " + infoid;
			
			b.add(sql);
		}
		return b;
	}

	/**
	 * 動力バッテリー温度値表からデータを削除の命令を作成
	 * 
	 * @param rttd
	 * 			RealTimeTemperatureData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeTemperatureDataValueInfoDelete(
			RealTimeTemperatureData rttd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		String sql = "delete FROM " + BATTERY_TEMPERATURE_VALUE_TABLE
				+ " WHERE " 
				+ INFOID_COLUMN + "= " + infoid;
		
		b.add(sql);
		
		return b;
	}

	// vehicle
	/**
	 * 車両データ表を建立の命令を作成
	 * 	
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeVehicleDataInfoTableCreate() {
		String sql = "create table if not exists " + VEHICLE_DATA_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ SPEED_COLUMN + " smallint(2),"
				+ MILEAGE_COLUMN + " int(4),"
				+ GEAR_COLUMN + " tinyint(1) unsigned,"
				+ ACCELERATED_PEDAL_TRIP_COLUMN + " tinyint(1) unsigned,"
				+ BRAKE_PEDAL_TRIP_COLUMN + " tinyint(1) unsigned,"
				+ CHARGESTATUS_COLUMN + " tinyint(1) unsigned,"
				+ MOTOR_CNTL_TEMPERATURE_COLUMN + " tinyint(1) unsigned,"
				+ MOTOR_SPEED_COLUMN + " smallint(2),"
				+ MOTOR_TEMPERATURE_COLUMN + " tinyint(1) unsigned,"
				+ MOTOR_VOLTAGE_COLUMN + " smallint(2),"
				+ MOTOR_CURRENT_COLUMN + " smallint(2)," 
				+ AIR_CONDITION_TEMPERATURE_COLUMN + " tinyint(1) unsigned,"
				+ RESERVE_COLUMN + " smallint(7));";

		return sql;
	}

	/**
	 * 車両データ表にデータを挿入の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVehicleData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVehicleDataInfoInsert(RealTimeVehicleData rtvd,long infoid) {
		String sql = "INSERT INTO " + VEHICLE_DATA_TABLE 
				+ "(" 
				+ INFOID_COLUMN +"," 
				+ SPEED_COLUMN +"," 
				+ MILEAGE_COLUMN +"," 
				+ GEAR_COLUMN +"," 
				+ ACCELERATED_PEDAL_TRIP_COLUMN +"," 
				+ BRAKE_PEDAL_TRIP_COLUMN +"," 
				+ CHARGESTATUS_COLUMN +"," 
				+ MOTOR_CNTL_TEMPERATURE_COLUMN +"," 
				+ MOTOR_SPEED_COLUMN +"," 
				+ MOTOR_TEMPERATURE_COLUMN +"," 
				+ MOTOR_VOLTAGE_COLUMN +"," 
				+ MOTOR_CURRENT_COLUMN +"," 
				+ AIR_CONDITION_TEMPERATURE_COLUMN
				+ ") values("
				+ infoid
				+ ",'"
				+ rtvd.getSpeed()
				+ "','"
				+ rtvd.getMileage()
				+ "','"
				+ rtvd.getGear()
				+ "','"
				+ rtvd.getAcceleratedPedalTrip()
				+ "','"
				+ rtvd.getBrakePedalTrip()
				+ "','"
				+ rtvd.getChargeStatus()
				+ "','"
				+ rtvd.getMotorCntlTemperature()
				+ "','"
				+ rtvd.getMotorSpeed()
				+ "','"
				+ rtvd.getMotorTemperature()
				+ "','"
				+ rtvd.getMotorVoltage()
				+ "','"
				+ rtvd.getMotorCurrent()
				+ "','"
				+ rtvd.getAirConditionTemperature() 
				+ "');";
		
		return sql;
	}

	/**
	 * 車両データ表のデータを更新の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVehicleData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVehicleDataInfoUpdate(RealTimeVehicleData rtvd,
			long infoid) {
		String sql = "update " + VEHICLE_DATA_TABLE 
				+ " set "
				+ SPEED_COLUMN + "='" + rtvd.getSpeed() + "',"
				+ MILEAGE_COLUMN + "='" + rtvd.getMileage() + "',"
				+ GEAR_COLUMN + "='" + rtvd.getGear() + "',"
				+ ACCELERATED_PEDAL_TRIP_COLUMN + "='" + rtvd.getAcceleratedPedalTrip() + "',"
				+ BRAKE_PEDAL_TRIP_COLUMN + "='" + rtvd.getBrakePedalTrip() + "',"
				+ CHARGESTATUS_COLUMN + "='" + rtvd.getChargeStatus() + "',"
				+ MOTOR_CNTL_TEMPERATURE_COLUMN + "='" + rtvd.getMotorCntlTemperature() + "',"
				+ MOTOR_SPEED_COLUMN + "='" + rtvd.getMotorSpeed() + "',"
				+ MOTOR_TEMPERATURE_COLUMN + "='" + rtvd.getMotorTemperature() + "',"
				+ MOTOR_VOLTAGE_COLUMN + "='" + rtvd.getMotorVoltage() + "',"
				+ MOTOR_CURRENT_COLUMN + "='" + rtvd.getMotorCurrent() + "',"
				+ AIR_CONDITION_TEMPERATURE_COLUMN + "='" + rtvd.getAirConditionTemperature() + "'"
				+ " where "
				+ INFOID_COLUMN + "= " + infoid;
		
		return sql;
	}

	/**
	 * 車両データ表からデータを削除の命令を作成
	 * 
	 * @param rtvd
	 * 			RealTimeVehicleData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVehicleDataInfoDelete(RealTimeVehicleData rtvd,long infoid) {
		String sql = "delete FROM " + VEHICLE_DATA_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + "= " + infoid;
		
		return sql;
	}

	/**
	 * 車両データ表からデータを検索の命令を作成
	 * 			
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeVehicleDataInfoQuery(long infoId) {
		String sql = "select * FROM " + VEHICLE_DATA_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoId;
		
		return sql;
	}

	// GPS
	/**
	 * 位置データ表を建立の命令を作成
	 * 			
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeGPSDataInfoTableCreate() {
		String sql = "create table if not exists " + GPS_DATA_TABLE 
				+ "(" 
				+ CARNUNBER_COLUMN + " varchar(8),"
				+ DATE_TIME_COLUMN + " DATETIME,"
				+ POSITIONING_STATE_COLUMN + " smallint(1),"
				+ LONGITUDE_COLUMN + " int(4),"
				+ LATITUDE_COLUMN + " int(4),"
				+ SPEED_COLUMN + " smallint(2),"
				+ DIRECTION_COLUMN + " smallint(2),"
				+ RESERVE_COLUMN + " smallint(4));";

		return sql;
	}
	
	/**
	 * 位置データ表にデータを挿入の命令を作成
	 * 		
	 * @param rtgpsd
	 * 			RealTimeGPSData情報
	 * @return　データベースの文字列
	 */
	static String realTimeGPSDataInfoInsert(RealTimeGPSData rtgpsd) {
		String sql = "INSERT INTO " + GPS_DATA_TABLE
				+ "("
				+ CARNUNBER_COLUMN + "," 
				+ DATE_TIME_COLUMN + ","
				+ POSITIONING_STATE_COLUMN + ","
				+ LONGITUDE_COLUMN + ","
				+ LATITUDE_COLUMN + ","
				+ SPEED_COLUMN + ","
				+ DIRECTION_COLUMN 
				+ ") values('"
				+ rtgpsd.getCarNumber()
				+ "','"
				+ rtgpsd.getDateTime()
				+ "','"
				+ rtgpsd.getPositioningState()
				+ "','"
				+ rtgpsd.getLongitude()
				+ "','"
				+ rtgpsd.getLatitude()
				+ "','"
				+ rtgpsd.getSpeed()
				+ "','"
				+ rtgpsd.getDirection() 
				+ "');";
		
		return sql;
	}

	/**
	 * 位置データ表のデータを更新の命令を作成
	 * 		
	 * @param rtgpsd
	 * 			RealTimeGPSData情報
	 * @return　データベースの文字列
	 */
	static String realTimeGPSDataInfoUpdate(RealTimeGPSData rtgpsd) {
		String sql = "update "+ GPS_DATA_TABLE
				+ " set "
				+ POSITIONING_STATE_COLUMN +"='" + rtgpsd.getPositioningState() + "',"
				+ LONGITUDE_COLUMN +"='" + rtgpsd.getLongitude() + "',"
				+ LATITUDE_COLUMN + "='" + rtgpsd.getLatitude() + "',"
				+ SPEED_COLUMN +"='" + rtgpsd.getSpeed() + "',"
				+ DIRECTION_COLUMN + "='" + rtgpsd.getDirection() + "'"
				+ " where " 
				+ CARNUNBER_COLUMN +" = '" + rtgpsd.getCarNumber() + "'"
				+ " and "
				+ DATE_TIME_COLUMN +"='" + rtgpsd.getDateTime()	+ "'";
		
		return sql;
	}
	
	/**
	 * 位置データ表からデータを削除の命令を作成
	 * 			
	 * @param rtgpsd
	 * 			RealTimeGPSData情報
	 * @return　データベースの文字列
	 */
	static String realTimeGPSDataInfoDelete(RealTimeGPSData rtgpsd) {
		String sql = "delete FROM " + GPS_DATA_TABLE 
				+ " WHERE " 
				+ CARNUNBER_COLUMN +" = '" + rtgpsd.getCarNumber() + "'"
				+ " and "
				+ DATE_TIME_COLUMN +"='" + rtgpsd.getDateTime()	+ "'";
		
		return sql;
	}

	/**
	 * 位置データ表からデータを検索の命令を作成
	 * 			
	 * @param rtgpsd
	 * 			RealTimeGPSData情報
	 * @return　データベースの文字列
	 */
	static String realTimeGPSDataInfoQuery(RealTimeGPSData rtgpsd) {
		String sql = "select * FROM " + GPS_DATA_TABLE 
				+ " WHERE " 
				+ CARNUNBER_COLUMN +" = '" + rtgpsd.getCarNumber() + "'"
				+ " and "
				+ DATE_TIME_COLUMN +"='" + rtgpsd.getDateTime()	+ "'";
		
		return sql;
	}

	// Extremum
	/**
	 * 極値データ表を建立の命令を作成
	 *  			
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeExtremumDataInfoTableCreate() {
		String sql = "create table if not exists " + EXTREMUM_DATA_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ MAX_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ MAX_VOLTAGE_BATTERY_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ BATTERY_MAX_VOLTAGE_COLUMN + " smallint(2),"
				+ MIN_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ MIN_VOLTAGE_BATTERY_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ BATTERY_MIN_VOLTAGE_COLUMN + " smallint(2),"
				+ MAX_TEMP_BATTERY_PACK_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ MAX_TEMP_PROBE_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ MAX_TEMPERATURE_COLUMN + " tinyint(1) unsigned,"
				+ MIN_TEMP_BATTERY_PACK_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ MIN_TEMP_PROBE_NUMBER_COLUMN + " tinyint(1) unsigned,"
				+ MIN_TEMPERATURE_COLUMN + " tinyint(1) unsigned,"
				+ TOTAL_VOLTAGE_COLUMN + " smallint(2),"
				+ TOTAL_CURRENT_COLUMN + " smallint(2),"
				+ SOC_COLUMN + " tinyint(1) unsigned,"
				+ REMAIN_ENERGY_COLUMN + " smallint(2),"
				+ INSULATION_RESISTANCE_COLUMN + " smallint(2),"
				+ RESERVE_COLUMN + " smallint(5)"
				+ ");";

		return sql;
	}

	/**
	 * 極値データ表にデータを挿入の命令を作成
	 * 			
	 * @param rtvd
	 * 			RealTimeExtremumData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeExtremumDataInfoInsert(RealTimeExtremumData rtvd,
			long infoid) {
		String sql = "INSERT INTO " + EXTREMUM_DATA_TABLE 
				+ "(" 
				+ INFOID_COLUMN + "," 
				+ MAX_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN + "," 
				+ MAX_VOLTAGE_BATTERY_NUMBER_COLUMN + "," 
				+ BATTERY_MAX_VOLTAGE_COLUMN + "," 
				+ MIN_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN + "," 
				+ MIN_VOLTAGE_BATTERY_NUMBER_COLUMN + "," 
				+ BATTERY_MIN_VOLTAGE_COLUMN + "," 
				+ MAX_TEMP_BATTERY_PACK_NUMBER_COLUMN + "," 
				+ MAX_TEMP_PROBE_NUMBER_COLUMN + "," 
				+ MAX_TEMPERATURE_COLUMN + "," 
				+ MIN_TEMP_BATTERY_PACK_NUMBER_COLUMN + "," 
				+ MIN_TEMP_PROBE_NUMBER_COLUMN + "," 
				+ MIN_TEMPERATURE_COLUMN + "," 
				+ TOTAL_VOLTAGE_COLUMN + "," 
				+ TOTAL_CURRENT_COLUMN + "," 
				+ SOC_COLUMN + "," 
				+ REMAIN_ENERGY_COLUMN + "," 
				+ INSULATION_RESISTANCE_COLUMN
				+ ") values("
				+ infoid
				+ ",'"
				+ rtvd.getMaxVoltageBatteryPackNumber()
				+ "','"
				+ rtvd.getMaxVoltageBatteryNumber()
				+ "','"
				+ rtvd.getBatteryMaxVoltage()
				+ "','"
				+ rtvd.getMinVoltageBatteryPackNumber()
				+ "','"
				+ rtvd.getMinVoltageBatteryNumber()
				+ "','"
				+ rtvd.getBatteryMinVoltage()
				+ "','"
				+ rtvd.getMaxTempBatteryPackNumber()
				+ "','"
				+ rtvd.getMaxTempProbeNumber()
				+ "','"
				+ rtvd.getMaxTemperature()
				+ "','"
				+ rtvd.getMinTempBatteryPackNumber()
				+ "','"
				+ rtvd.getMinTempProbeNumber()
				+ "','"
				+ rtvd.getMinTemperature()
				+ "','"
				+ rtvd.getTotalVoltage()
				+ "','"
				+ rtvd.getTotalCurrent()
				+ "','"
				+ rtvd.getSOC()
				+ "','"
				+ rtvd.getRemainEnergy()
				+ "','"
				+ rtvd.getInsulationResistance() 
				+ "');";
		
		return sql;
	}

	/**
	 * 極値データ表のデータを更新の命令を作成
	 * 			
	 * @param rtvd
	 * 			RealTimeExtremumData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeExtremumDataInfoUpdate(RealTimeExtremumData rtvd,
			long infoid) {
		String sql = "update " + EXTREMUM_DATA_TABLE
				+" set "
				+ MAX_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN + "='" + rtvd.getMaxVoltageBatteryPackNumber() + "'," 
				+ MAX_VOLTAGE_BATTERY_NUMBER_COLUMN + "='" + rtvd.getMaxVoltageBatteryNumber() + "'," 
				+ BATTERY_MAX_VOLTAGE_COLUMN + "='" + rtvd.getBatteryMaxVoltage() + "'," 
				+ MIN_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN + "='" + rtvd.getMinVoltageBatteryPackNumber() + "'," 
				+ MIN_VOLTAGE_BATTERY_NUMBER_COLUMN + "='" + rtvd.getMinVoltageBatteryNumber() + "'," 
				+ BATTERY_MIN_VOLTAGE_COLUMN + "='" + rtvd.getBatteryMinVoltage() + "'," 
				+ MAX_TEMP_BATTERY_PACK_NUMBER_COLUMN + "='" + rtvd.getMaxTempBatteryPackNumber() + "'," 
				+ MAX_TEMP_PROBE_NUMBER_COLUMN + "='" + rtvd.getMaxTempProbeNumber() + "'," 
				+ MAX_TEMPERATURE_COLUMN + "='" + rtvd.getMaxTemperature() + "'," 
				+ MIN_TEMP_BATTERY_PACK_NUMBER_COLUMN + "='" + rtvd.getMinTempBatteryPackNumber() + "'," 
				+ MIN_TEMP_PROBE_NUMBER_COLUMN + "='" + rtvd.getMinTempProbeNumber() + "'," 
				+ MIN_TEMPERATURE_COLUMN + "='" + rtvd.getMinTemperature() + "'," 
				+ TOTAL_VOLTAGE_COLUMN + "='" + rtvd.getTotalVoltage() + "'," 
				+ TOTAL_CURRENT_COLUMN + "='" + rtvd.getTotalCurrent() + "'," 
				+ SOC_COLUMN + "='" + rtvd.getSOC() + "'," 
				+ REMAIN_ENERGY_COLUMN + "='" + rtvd.getRemainEnergy() + "'" 
				+ INSULATION_RESISTANCE_COLUMN + "='" + rtvd.getInsulationResistance() + "'" 
				+ " where "
				+ INFOID_COLUMN + "= " + infoid;
		
		return sql;
	}

	/**
	 * 極値データ表からデータを削除の命令を作成
	 * 			
	 * @param rtvd
	 * 			RealTimeExtremumData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeExtremumDataInfoDelete(RealTimeExtremumData rtvd,
			long infoid) {
		String sql = "delete FROM " + EXTREMUM_DATA_TABLE 
				+ " WHERE "
				+ INFOID_COLUMN + "= " + infoid;
		
		return sql;
	}

	/**
	 * 極値データ表からデータを検索の命令を作成
	 * 
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeExtremumDataInfoQuery(long infoId) {
		String sql = "select * FROM " + VEHICLE_DATA_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoId;
		
		return sql;
	}
	
	// Alarm
	/**
	 * 警報データ表を建立の命令を作成
	 * 		
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmDataInfoTableCreate() {
		String sql = "create table if not exists " + ALARM_DATA_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ BATTERY_ALARM_FLAG_COLUMN + " smallint(2),"
				+ BATTERY_OTHER_FAULTS_CNT_COLUMN + " tinyint(1) unsigned,"
				+ MOTOR_FAULTS_CNT_COLUMN + " tinyint(1) unsigned,"
				+ OTHER_FAULTS_CNT_COLUMN + " tinyint(1) unsigned" 
				+ ");";

		return sql;
	}

	/**
	 * 警報データ表にデータを挿入の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmDataInfoInsert(RealTimeAlarmData rtvd,long infoid) {
		String sql = "INSERT INTO "+ ALARM_DATA_TABLE 
				+ "(" 
				+ INFOID_COLUMN + "," 
				+ BATTERY_ALARM_FLAG_COLUMN + "," 
				+ BATTERY_OTHER_FAULTS_CNT_COLUMN + "," 
				+ MOTOR_FAULTS_CNT_COLUMN + "," 
				+ OTHER_FAULTS_CNT_COLUMN
				+ ") values("
				+ infoid
				+ ",'"
				+ rtvd.getBatteryAlarmFlag()
				+ "','"
				+ rtvd.getBatteryOtherFaultsCnt()
				+ "','"
				+ rtvd.getMotorFaultsCnt()
				+ "','"
				+ rtvd.getOtherFaultsCnt() 
				+ "');";
		
		return sql;
	}

	/**
	 * 警報データ表のデータを更新の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmDataInfoUpdate(RealTimeAlarmData rtvd,
			long infoid) {
		String sql = "update " + ALARM_DATA_TABLE
				+ " set " 
				+ BATTERY_ALARM_FLAG_COLUMN + "='" + rtvd.getBatteryAlarmFlag() + "'," 
				+ BATTERY_OTHER_FAULTS_CNT_COLUMN + "='" + rtvd.getBatteryOtherFaultsCnt() + "'," 
				+ MOTOR_FAULTS_CNT_COLUMN + "='" + rtvd.getMotorFaultsCnt() + "'," 
				+ OTHER_FAULTS_CNT_COLUMN + "='" + rtvd.getOtherFaultsCnt() + "'" 
				+ " where "
				+ INFOID_COLUMN + " = " + infoid;
		
		return sql;
	}
	
	/**
	 * 警報データ表からデータを削除の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmDataInfoDelete(RealTimeAlarmData rtvd,
			long infoid) {
		String sql = "delete FROM " + ALARM_DATA_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoid;
		
		return sql;
	}
	
	/**
	 * 警報データ表からデータを検索の命令を作成
	 * 			
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmDataInfoQuery(long infoId) {
		String sql = "select * FROM " + VEHICLE_DATA_TABLE
				+ " WHERE "
				+ INFOID_COLUMN + " = " + infoId;
		
		return sql;
	}
	
	/**
	 * 動力バッテリー他の故障コード表を建立の命令を作成
	 * 		
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmBatteryOtherFaultCodesTableCreate() {
		String sql = "create table if not exists " + BATTERY_OTHER_FAULT_CODES_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ BATTERY_OTHER_FAULT_CODES_COLUMN + " smallint(1)"
				+ ");";

		return sql;
	}
	
	/**
	 * 動力バッテリー他の故障コード表にデータを挿入の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmBatteryOtherFaultCodesInsert(
			RealTimeAlarmData rtvd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (Integer integer: rtvd.getBatteryOtherFaultCodes()) {
			String sql = "INSERT INTO " + BATTERY_OTHER_FAULT_CODES_TABLE 
					+ "("
					+ INFOID_COLUMN + "," 
					+ BATTERY_OTHER_FAULT_CODES_COLUMN
					+ ") values("
					+ infoid
					+ ",'"
					+ integer 
					+ "');";
			
			b.add(sql);
		}
		return b;
	}

	/**
	 * 動力バッテリー他の故障コード表のデータを更新の命令を作成
	 * 			
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmBatteryOtherFaultCodesUpdate(
			RealTimeAlarmData rtvd, long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (Integer integer : rtvd.getBatteryOtherFaultCodes()) {
			String sql = "update " + BATTERY_OTHER_FAULT_CODES_TABLE 
					+ " set " 
					+ BATTERY_OTHER_FAULT_CODES_COLUMN + "='" + integer + "'" 
					+ " where "
					+ INFOID_COLUMN + "= " + infoid;
			
			b.add(sql);
		}
		return b;
	}
	
	/**
	 * 動力バッテリー他の故障コード表からデータを削除の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmBatteryOtherFaultCodesDelete(
			RealTimeAlarmData rtvd,long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		String sql = "delete FROM " + BATTERY_OTHER_FAULT_CODES_TABLE
				+ " WHERE " 
				+ INFOID_COLUMN + "= " + infoid;
		
		b.add(sql);
		
		return b;
	}
	
	/**
	 * 電機故障コード表を建立の命令を作成
	 * 			
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmMotorFaultCodesTableCreate() {
		String sql = "create table if not exists " + MOTOR_FAULT_CODES_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ MOTOR_FAULT_CODES_COLUMN + " smallint(1)" 
				+ ");";

		return sql;
	}
	
	/**
	 * 電機故障コード表にデータを挿入の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmMotorFaultCodesInsert(
			RealTimeAlarmData rtvd,long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (Integer integer: rtvd.getMotorFaultCodes()) {
			String sql = "INSERT INTO " + MOTOR_FAULT_CODES_TABLE 
					+ "("
					+ INFOID_COLUMN + "," 
					+ MOTOR_FAULT_CODES_COLUMN 
					+ ") values("
					+ infoid
					+ ",'"
					+ integer 
					+ "');";
			b.add(sql);
		}
		return b;
	}
	
	/**
	 * 電機故障コード表のデータを更新の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmMotorFaultCodesUpdate(
			RealTimeAlarmData rtvd,long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (Integer integer : rtvd.getMotorFaultCodes()) {
			String sql = "update " + MOTOR_FAULT_CODES_TABLE
					+" set " 
					+ MOTOR_FAULT_CODES_COLUMN + "='" + integer + "'" 
					+ " where " 
					+ INFOID_COLUMN + "= " + infoid;
			
			b.add(sql);
		}
		return b;
	}

	/**
	 * 電機故障コード表からデータを削除の命令を作成
	 * 			
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmMotorFaultCodesDelete(
			RealTimeAlarmData rtvd,long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		String sql = "delete FROM " + MOTOR_FAULT_CODES_TABLE 
				+ " WHERE "
				+ INFOID_COLUMN + "= " + infoid;
		
		b.add(sql);
		
		return b;
	}

	/**
	 * 他の故障コード表を建立の命令を作成
	 * 		
	 * @param null
	 * 			
	 * @return　データベースの文字列
	 */
	static String realTimeAlarmOtherFaultCodesTableCreate() {
		String sql = "create table if not exists " + OTHER_FAULT_CODES_TABLE 
				+ "(" 
				+ INFOID_COLUMN + " bigint(8),"
				+ OTHER_FAULT_CODES_COLUMN + " smallint(1)"
				+ ");";

		return sql;
	}
	
	/**
	 * 他の故障コード表にデータを挿入の命令を作成
	 * 			
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmOtherFaultCodesInsert(
			RealTimeAlarmData rtvd,long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (Integer integer: rtvd.getOtherFaultCodes()) {
			String sql = "INSERT INTO " + OTHER_FAULT_CODES_TABLE 
					+ "(" 
					+ INFOID_COLUMN + ","
					+ OTHER_FAULT_CODES_COLUMN
					+ ") values("
					+ infoid
					+ ",'"
					+ integer 
					+ "');";
			
			b.add(sql);
		}
		return b;
	}

	/**
	 * 他の故障コード表のデータを更新の命令を作成
	 * 			
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmOtherFaultCodesUpdate(
			RealTimeAlarmData rtvd,long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		for (Integer integer : rtvd.getOtherFaultCodes()) {
			String sql = "update " + OTHER_FAULT_CODES_TABLE
					+" set "
					+ OTHER_FAULT_CODES_COLUMN + "='" + integer + "'"
					+ " where " 
					+ INFOID_COLUMN + "= " + infoid;
			b.add(sql);
		}
		return b;
	}

	/**
	 * 他の故障コード表からデータを削除の命令を作成
	 * 		
	 * @param rtvd
	 * 			RealTimeAlarmData情報
	 * @param infoid
	 * 			リアルタイム情報id
	 * @return　データベースの文字列
	 */
	static ArrayList<String> realTimeAlarmOtherFaultCodesDelete(
			RealTimeAlarmData rtvd,long infoid) {
		ArrayList<String> b = new ArrayList<String>();
		String sql = "delete FROM " + OTHER_FAULT_CODES_TABLE 
				+ " WHERE "
				+ INFOID_COLUMN + "= " + infoid;
		
		b.add(sql);
		
		return b;
	}


	// new class for db process
	static class DBProcess {
		/**
		 * データベースの処理実例
		 */
		static DBProcess mDbProcess = new DBProcess();

		private Connection mConn = null;
		private Statement mStmt = null;
		private String mUrl = "jdbc:mysql://localhost/dcmseverdb";
		private String mUser = "root";
		private String mPwd = "123456";

		/**
		 * データベースの処理実例を獲得
		 * 			
		 * @param null
		 * 			
		 * @return　mDbProcessを返し
		 */
		static DBProcess getInstance() {
			return mDbProcess;
		}

		/**
		 * DBProcess実例を創建と初期化
		 * 			
		 * @param null
		 * 			
		 * @return null
		 */
		DBProcess() {
			Common.printString("DBManager.DBProcess","DBProcess create start ...");
			try {
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				mConn = DriverManager.getConnection(mUrl, mUser, mPwd);
				mStmt = mConn.createStatement();
				Common.printString("DBManager.DBProcess","DBProcess create success!!");
			} catch (Exception e) {
				// your installation of JDBC Driver Failed
				e.printStackTrace();
			}
		}

		/**
		 * DBに表を創建
		 * 			
		 * @param sql
		 * 			DB創建の文字列
		 * @return null
		 * @throws SQLException 
		 */
		public void tableCreate(String sql) throws SQLException {
			int i = mStmt.executeUpdate(sql);
			if (i == 0) {
				Common.printString("DBManager.DBProcess", sql + " success!!");
			}
		}


		/**
		 * DBの表にデータを挿入
		 * 			
		 * @param cmd
		 * 			DB挿入の文字列
		 * @return　data挿入成功場合、trueを返し
		 */
		boolean dataInsert(String cmd) {
			try {
				String sqlStr = cmd;
				mStmt.execute(sqlStr);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}

		/**
		 * DBの表にデータを挿入
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @param is
		 * 			byte[]
		 * @return　data挿入成功場合、trueを返し
		 */
		boolean dataInsert(String cmd, byte[] is) {
			try {
				String sqlStr = cmd;
				PreparedStatement pstmt = mConn.prepareStatement(sqlStr);  
				pstmt.setBytes(1,is);  
				pstmt.executeUpdate(); 
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}

		/**
		 * DBの表にデータを更新
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　data更新成功場合、trueを返し
		 */
		boolean dataUpdate(String cmd) {
			try {
				mStmt.executeUpdate(cmd);
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}

		/**
		 * DBの表からデータを削除
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　data削除成功場合、trueを返し
		 */
		boolean dataDelete(String cmd) {
			try {
				mStmt.executeUpdate(cmd);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		}

		/**
		 * 車両の基本情報表からデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　ArrayListを返し
		 */
		ArrayList<RegistData> basicDataSearch(String cmd) {
			ArrayList<RegistData> ard = new ArrayList<RegistData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RegistData rd = new RegistData();
					rd.setCarNumber(rs.getString(CARNUNBER_COLUMN));
					rd.setMakerCode(rs.getString(MAKERCODE_COLUMN));
					rd.setTerminalNumber(rs.getString(TERMINAL_NUMBER_COLUMN));
					rd.setSerialNumber(rs.getShort(SERIAL_NUMBER_COLUMN));
					rd.setBatteryPackCount(rs.getInt(BATTERY_PACK_COUNT_COLUMN));
					
					ard.add(rd);
				}
				return ard;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 動力蓄電池コード表からデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<String, ArrayList<BatteryPacket>>を返し
		 */
		Map<String, ArrayList<BatteryPacket>> batteryCodeDataSearch(String cmd) {
			Map<String, ArrayList<BatteryPacket>> mbp = new HashMap<String, ArrayList<BatteryPacket>>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					String carNumber = rs.getString(CARNUNBER_COLUMN);
					
					BatteryPacket bp = new BatteryPacket();
					bp.setBatteryPackSerialNumber(rs.getInt(BATTERY_PACK_SERIAL_NUMBER_COLUMN));
					bp.setPackEncodeMaker(rs.getString(PACK_ENCODE_MAKER_COLUMN));
					bp.setPackEncodeBttyType(rs.getInt(PACK_ENCODE_BTTYTYPE_COLUMN));
					bp.setPackEncodeRatedEnery(rs.getShort(PACK_ENCODE_RATED_ENERY_COLUMN));
					bp.setPackEncodeRatedVoltage(rs.getShort(PACK_ENCODE_RATED_VOLTAGE_COLUMN));
					
					Blob blob = rs.getBlob(PACK_ENCODE_MAKE_DATE_COLUMN);
					long len = blob.length();

					bp.setPackEncodeMakeDate(blob.getBytes(1, (int)len));
					
					bp.setSerialNumber(rs.getShort(SERIAL_NUMBER_COLUMN));
					
					if (mbp.get(carNumber) == null) {
						ArrayList<BatteryPacket> abp = new ArrayList<BatteryPacket>();
						abp.add(bp);
						mbp.put(carNumber, abp);
					} else {
						ArrayList<BatteryPacket> abp = mbp.get(carNumber);
						abp.add(bp);
//						mbp.put(carNumber, abp);
					}
				}
				return mbp;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 登録履歴表からデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<String, RegistData>を返し
		 */
		Map<String, RegistData> loginDataLastDataSearch(String cmd) {
			Map<String, RegistData> mrd = new HashMap<String, RegistData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RegistData rd = new RegistData();
					rd.setCarNumber(rs.getString(CARNUNBER_COLUMN));
					rd.setDateTime(rs.getString(DATE_TIME_COLUMN));
					rd.setRegistSerialNumber(rs.getShort(REGIST_SERIAL_NUMBER_COLUMN));
					if (mrd.get(rd.getCarNumber()) == null) {
						mrd.put(rd.getCarNumber(), rd);
					} else {
						RegistData rd2 = mrd.get(rd.getCarNumber());
						if (Common.compareWithDateTime(rd.getDateTime(),
								rd2.getDateTime()) == 1) {
							mrd.put(rd.getCarNumber(), rd);
						}
					}
				}
				return mrd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 車載端末状態情報表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　ArrayListを返し
		 */
		ArrayList<StatusData> statusDataSearch(String cmd) {
			ArrayList<StatusData> asd = new ArrayList<StatusData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					StatusData sd = new StatusData();
					sd.setCarNumber(rs.getString(CARNUNBER_COLUMN));
					sd.setDateTime(rs.getString(DATE_TIME_COLUMN));
					sd.setStatus(rs.getInt(STATUS_COLUMN));
					
					asd.add(sd);
				}
				return asd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		
		/**
		 * 単体バッテリー電圧表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<Long, RealTimeVoltageData>を返し
		 */
		Map<Long, RealTimeVoltageData> realTimeVoltageDataSearch(String cmd) {
			Map<Long, RealTimeVoltageData> arvd = new HashMap<Long, RealTimeVoltageData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RealTimeVoltageData rvd = new RealTimeVoltageData();
					long infoId = rs.getLong(INFOID_COLUMN);
					rvd.setBatteryCount(rs.getShort(BATTERY_COUNT_COLUMN));
					rvd.setBatteryPackCount(rs.getInt(BATTERY_PACK_COUNT_COLUMN));
					
					arvd.put(infoId, rvd);
				}
				return arvd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 動力バッテリー電圧値表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<Integer, VoltagePacket>を返し
		 */
		Map<Integer, VoltagePacket> voltageDataSearch(String cmd) {
			try {
				Map<Integer, VoltagePacket> avp = new HashMap<Integer, VoltagePacket>();

				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					int batteryPacketSequence = rs.getInt(BATTERY_PACKET_SEQUENCE_COLUMN);

					if (avp.get(batteryPacketSequence) == null) {
						VoltagePacket vp = new VoltagePacket();
						ArrayList<Integer> voltageValues = new ArrayList<Integer>();
						
						vp.setBatteryPacketSequence(batteryPacketSequence);
						vp.setBatteryCount(rs.getInt(BATTERY_COUNT_COLUMN));
						voltageValues.add((int) rs.getShort(VOLTAGE_VALUES_COLUMN));
						
						vp.setVoltageValues(voltageValues);
					} else {
						VoltagePacket vp = avp.get(batteryPacketSequence);
						ArrayList<Integer> voltageValues = vp.getVoltageValues();
						voltageValues.add((int) rs.getShort(VOLTAGE_VALUES_COLUMN));
					}
				}
				return avp;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		
		/**
		 * 動力バッテリーバッグ温度表からデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<Long, RealTimeTemperatureData>を返し
		 */
		Map<Long, RealTimeTemperatureData> realTimeTemperatureDataSearch(
				String cmd) {
			Map<Long, RealTimeTemperatureData> artd = new HashMap<Long, RealTimeTemperatureData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RealTimeTemperatureData rtd = new RealTimeTemperatureData();
					
					long infoId = rs.getLong(INFOID_COLUMN);
					rtd.setTemperatureProbeCnt(rs.getShort(TEMPERATURE_PROBE_CNT_COLUMN));
					rtd.setBatteryPackCount(rs.getInt(BATTERY_PACK_COUNT_COLUMN));
					
					artd.put(infoId, rtd);
				}
				return artd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 動力バッテリー温度値表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<Integer, TemperaturePacket>を返し
		 */		
		Map<Integer, TemperaturePacket> temperatureDataSearch(String cmd) {
			try {
				Map<Integer, TemperaturePacket> atp = new HashMap<Integer, TemperaturePacket>();

				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					int batteryPacketSequence = rs.getInt(BATTERY_PACKET_SEQUENCE_COLUMN);

					if (atp.get(batteryPacketSequence) == null) {
						TemperaturePacket tp = new TemperaturePacket();
						ArrayList<Integer> temperatureValues = new ArrayList<Integer>();
						
						tp.setBatteryPacketSequence(batteryPacketSequence);
						tp.setTemperatureProbeCount(rs.getInt(TEMPERATURE_PROBE_COUNT_IN_A_PACK_COLUMN));
						temperatureValues
								.add((int) rs.getShort(TEMPERATUR_VALUES_COLUMN));
						
						tp.setTemperatureValues(temperatureValues);
					} else {
						TemperaturePacket tp = atp.get(batteryPacketSequence);
						ArrayList<Integer> temperatureValues = tp.getTemperatureValues();
						temperatureValues
								.add((int) rs.getShort(TEMPERATUR_VALUES_COLUMN));
					}
				}
				return atp;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 車両データ表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<Long, RealTimeVehicleData>を返し
		 */		
		Map<Long, RealTimeVehicleData> realTimeVehicleDataSearch(String cmd) {
			Map<Long, RealTimeVehicleData> mrtd = new HashMap<Long, RealTimeVehicleData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RealTimeVehicleData rtd = new RealTimeVehicleData();
					long infoId = rs.getLong(INFOID_COLUMN);
					rtd.setSpeed(rs.getShort(SPEED_COLUMN));
					rtd.setMileage(rs.getInt(MILEAGE_COLUMN));
					rtd.setGear(rs.getInt(GEAR_COLUMN));
					rtd.setAcceleratedPedalTrip(rs.getInt(ACCELERATED_PEDAL_TRIP_COLUMN));
					rtd.setBrakePedalTrip(rs.getInt(BRAKE_PEDAL_TRIP_COLUMN));
					rtd.setChargeStatus(rs.getInt(CHARGESTATUS_COLUMN));
					rtd.setMotorCntlTemperature(rs.getInt(MOTOR_CNTL_TEMPERATURE_COLUMN));
					rtd.setMotorSpeed(rs.getShort(MOTOR_SPEED_COLUMN));
					rtd.setMotorTemperature(rs.getInt(MOTOR_TEMPERATURE_COLUMN));
					rtd.setMotorVoltage(rs.getShort(MOTOR_VOLTAGE_COLUMN));
					rtd.setMotorCurrent(rs.getShort(MOTOR_CURRENT_COLUMN));
					rtd.setAirConditionTemperature(rs.getInt(AIR_CONDITION_TEMPERATURE_COLUMN));
					
					mrtd.put(infoId, rtd);
				}
				return mrtd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 位置データ表からデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　ArrayList<RealTimeGPSData>を返し
		 */		
		ArrayList<RealTimeGPSData> realTimeGPSDataSearch(String cmd) {
			ArrayList<RealTimeGPSData> agpsd = new ArrayList<RealTimeGPSData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RealTimeGPSData gpsd = new RealTimeGPSData();
					gpsd.setCarNumber(rs.getString(CARNUNBER_COLUMN));
					gpsd.setDateTime(rs.getString(DATE_TIME_COLUMN));
					gpsd.setPositioningState(rs.getInt(POSITIONING_STATE_COLUMN));
					gpsd.setLongitude(rs.getInt(LONGITUDE_COLUMN));
					gpsd.setLatitude(rs.getInt(LATITUDE_COLUMN));
					gpsd.setSpeed(rs.getShort(SPEED_COLUMN));
					gpsd.setDirection(rs.getShort(DIRECTION_COLUMN));
					
					agpsd.add(gpsd);
				}
				return agpsd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 極値データ表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<Long, RealTimeExtremumData>を返し
		 */		
		Map<Long, RealTimeExtremumData> realTimeExtremumDataSearch(String cmd) {
			Map<Long, RealTimeExtremumData> mrtd = new HashMap<Long, RealTimeExtremumData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RealTimeExtremumData rtd = new RealTimeExtremumData();
					long infoId = rs.getLong(INFOID_COLUMN);
					rtd.setMaxVoltageBatteryPackNumber(rs.getInt(MAX_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN));
					rtd.setMaxVoltageBatteryNumber(rs.getInt(MAX_VOLTAGE_BATTERY_NUMBER_COLUMN));
					rtd.setBatteryMaxVoltage(rs.getShort(BATTERY_MAX_VOLTAGE_COLUMN));
					rtd.setMinVoltageBatteryPackNumber(rs.getInt(MIN_VOLTAGE_BATTERY_PACK_NUMBER_COLUMN));
					rtd.setMinVoltageBatteryNumber(rs.getInt(MIN_VOLTAGE_BATTERY_NUMBER_COLUMN));
					rtd.setBatteryMinVoltage(rs.getShort(BATTERY_MIN_VOLTAGE_COLUMN));
					rtd.setMaxTempBatteryPackNumber(rs.getInt(MAX_TEMP_BATTERY_PACK_NUMBER_COLUMN));
					rtd.setMaxTempProbeNumber(rs.getInt(MAX_TEMP_PROBE_NUMBER_COLUMN));
					rtd.setMaxTemperature(rs.getInt(MAX_TEMPERATURE_COLUMN));
					rtd.setMinTempBatteryPackNumber(rs.getInt(MIN_TEMP_BATTERY_PACK_NUMBER_COLUMN));
					rtd.setMinTempProbeNumber(rs.getInt(MIN_TEMP_PROBE_NUMBER_COLUMN));
					rtd.setMinTemperature(rs.getInt(MIN_TEMPERATURE_COLUMN));
					rtd.setTotalVoltage(rs.getShort(TOTAL_VOLTAGE_COLUMN));
					rtd.setTotalCurrent(rs.getShort(TOTAL_CURRENT_COLUMN));
					rtd.setSOC(rs.getInt(SOC_COLUMN));
					rtd.setRemainEnergy(rs.getShort(REMAIN_ENERGY_COLUMN));
					rtd.setInsulationResistance(rs.getShort(INSULATION_RESISTANCE_COLUMN));
					
					mrtd.put(infoId, rtd);
				}
				return mrtd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 警報データ表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　Map<Long, RealTimeAlarmData>を返し
		 */		
		Map<Long, RealTimeAlarmData> realTimeAlarmDataSearch(String cmd) {
			Map<Long, RealTimeAlarmData> mrtd = new HashMap<Long, RealTimeAlarmData>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RealTimeAlarmData rtd = new RealTimeAlarmData();
					long infoId = rs.getLong(INFOID_COLUMN);
					rtd.setBatteryAlarmFlag(rs.getShort(BATTERY_ALARM_FLAG_COLUMN));
					rtd.setBatteryOtherFaultsCnt(rs.getInt(BATTERY_OTHER_FAULTS_CNT_COLUMN));
					rtd.setMotorFaultsCnt(rs.getInt(MOTOR_FAULTS_CNT_COLUMN));
					rtd.setOtherFaultsCnt(rs.getInt(OTHER_FAULTS_CNT_COLUMN));
					
					mrtd.put(infoId, rtd);
				}
				return mrtd;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 動力バッテリー他の故障コード表からデータを検索
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　ArrayList<Integer>を返し
		 */	
		ArrayList<Integer> batteryOtherFaultCodesDataSearch(String cmd) {
			ArrayList<Integer> ai = new ArrayList<Integer>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					ai.add((int) rs.getInt(BATTERY_OTHER_FAULT_CODES_COLUMN));
				}
				return ai;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 電機故障コード表からデータを検索	
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　ArrayList<Integer>を返し
		 */	
		ArrayList<Integer> motorFaultCodesDataSearch(String cmd) {
			ArrayList<Integer> ai = new ArrayList<Integer>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					ai.add((int) rs.getInt(MOTOR_FAULT_CODES_COLUMN));
				}
				return ai;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 他の故障コード表からデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　ArrayList<Integer>を返し
		 */	
		ArrayList<Integer> otherFaultCodesDataSearch(String cmd) {
			ArrayList<Integer> ai = new ArrayList<Integer>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					ai.add((int) rs.getInt(OTHER_FAULT_CODES_COLUMN));
				}
				return ai;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 車両のリアルタイムの情報ID表から最新のデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　リアルタイム情報idを返し
		 */	
		RealTimeInfoId realTimeInfoIdLastIdSearch(String cmd) {
			RealTimeInfoId rtii = new RealTimeInfoId();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				if (rs.last()) {
					rtii.setCarNumber(rs.getString(CARNUNBER_COLUMN));
					rtii.setDateTime(rs.getString(DATE_TIME_COLUMN));
					rtii.setInfoId(rs.getLong(INFOID_COLUMN));
					return rtii;
				} else {
					return null;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * 車両のリアルタイムの情報ID表からデータを検索
		 * 
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　ArrayList<RealTimeInfoId>を返し
		 */	
		ArrayList<RealTimeInfoId> realTimeInfoIdsSearch(String cmd) {
			ArrayList<RealTimeInfoId> artid = new ArrayList<RealTimeInfoId>();
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				while (rs.next()) {
					RealTimeInfoId rtii = new RealTimeInfoId();
					rtii.setCarNumber(rs.getString(CARNUNBER_COLUMN));
					rtii.setDateTime(rs.getString(DATE_TIME_COLUMN));
					rtii.setInfoId(rs.getLong(INFOID_COLUMN));
					artid.add(rtii);
				}
				return artid;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		/**
		 * DBの表にデータが存在を判断
		 * 	
		 * @param cmd
		 * 		    データベースの文字列	
		 * @return　dataクエリ場合、trueを返し
		 */	
		boolean dataExistQuery(String cmd) {
			try {
				ResultSet rs = mStmt.executeQuery(cmd);
				if (rs.next()) {
					return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}

		/**
		 * DBの操作をクロッス	
		 * 	
		 * @param null
		 * 		    
		 * @return null
		 */	
		public void close() {
			try {
				if (mConn != null) {
					mConn.close();
				}
				if (mStmt != null) {
					mStmt.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


	/**
	 * スレッドを睡眠
	 * 
	 * @param null
	 * 		    
	 * @return null
	 */	
	static void threadWait() {
		synchronized (mDbThread) {
			try {
				isWait = true;
				mDbThread.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	/**
	 * スレッドを呼び覚まし
	 * 	
	 * @param null
	 * 		    
	 * @return null
	 */	
	static void threadNotify() {
		synchronized (mDbThread) {
			isWait = false;
			mDbThread.notify();
		}
	}

	/**
	 * databaseにregisterデータを保存
	 * 
	 * @param rd
	 *            EVDCMのデータ.
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean registDataSave(RegistData rd) {
		if (rd == null) {
			return false;
		}

		if (mRegistDataList.size() >= MAX_SIZE) {
			mRegistDataSleepThreads.add(rd);
			synchronized (rd) {
				try {
					rd.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mRegistDataList.add(rd);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * databaseにstatusデータを保存する
	 * 
	 * @param sd
	 *            EVDCMの状態データ
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean statusDataSave(StatusData sd) {
		if (sd == null) {
			return false;
		}

		if (mStatusDataList.size() >= MAX_SIZE) {
			mStatusDataSleepThreads.add(sd);
			synchronized (sd) {
				try {
					sd.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mStatusDataList.add(sd);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * databaseにvoltageデータを保存する
	 * 
	 * @param rtvd
	 *            EVDCMの電圧データ
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean realTimeVoltageDataSave(RealTimeVoltageData rtvd) {
		if (rtvd == null) {
			return false;
		}

		if (mRealTimeVoltageDataList.size() >= MAX_SIZE) {
			mRealTimeVoltageDataSleepThreads.add(rtvd);
			synchronized (rtvd) {
				try {
					rtvd.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mRealTimeVoltageDataList.add(rtvd);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * databaseにtemperatureデータを保存する
	 * 
	 * @param rttd
	 *            EVDCMの温度データ
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean realTimeTemperatureDataSave(
			RealTimeTemperatureData rttd) {
		if (rttd == null) {
			return false;
		}

		if (mRealTimeTemperatureDataList.size() >= MAX_SIZE) {
			mRealTimeTemperatureDataSleepThreads.add(rttd);
			synchronized (rttd) {
				try {
					rttd.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mRealTimeTemperatureDataList.add(rttd);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * databaseにvehicleデータを保存する
	 * 
	 * @param rtvd
	 *            EVDCMの車両データ
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean realTimeVehicleDataSave(RealTimeVehicleData rtvd) {
		if (rtvd == null) {
			return false;
		}

		if (mRealTimeVehicleDataList.size() >= MAX_SIZE) {
			mRealTimeVehicleDataSleepThreads.add(rtvd);
			synchronized (rtvd) {
				try {
					rtvd.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mRealTimeVehicleDataList.add(rtvd);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * databaseにGPSデータを保存する
	 * 
	 * @param rtgpsd
	 *            EVDCMのGPSデータ
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean realTimeGPSDataSave(RealTimeGPSData rtgpsd) {
		if (rtgpsd == null) {
			return false;
		}

		if (mRealTimeGPSDataList.size() >= MAX_SIZE) {
			mRealTimeGPSDataSleepThreads.add(rtgpsd);
			synchronized (rtgpsd) {
				try {
					rtgpsd.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mRealTimeGPSDataList.add(rtgpsd);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * databaseにextremumデータを保存する
	 * 
	 * @param rted
	 *           EVDCMの極値データ
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean realTimeExtremumDataSave(RealTimeExtremumData rted) {
		if (rted == null) {
			return false;
		}

		if (mRealTimeExtremumDataList.size() >= MAX_SIZE) {
			mRealTimeExtremumDataSleepThreads.add(rted);
			synchronized (rted) {
				try {
					rted.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mRealTimeExtremumDataList.add(rted);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * databaseにalarmデータを保存する
	 * 
	 * @param rtad
	 *            EVDCMのアラームデータ
	 * @return データを保存成功場合、trueを返し
	 */
	static public boolean realTimeAlarmDataSave(RealTimeAlarmData rtad) {
		if (rtad == null) {
			return false;
		}

		if (mRealTimeAlarmDataList.size() >= MAX_SIZE) {
			mRealTimeAlarmDataSleepThreads.add(rtad);
			synchronized (rtad) {
				try {
					rtad.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}
			}
		}
		mRealTimeAlarmDataList.add(rtad);

		if (isWait) {
			threadNotify();
		}

		return true;
	}

	/**
	 * データ表にすべてのデータを検索の命令を作成
	 * 
	 * @param rtad
	 *            文字列
	 * @return 文字列を返し
	 */
	static String searchAllCmd(String table) {
		String sql = "select * from " + table;
		return sql;
	}

	/**
	 * データ表に指定のデータを検索の命令を作成
	 * 
	 * @param table
	 *            DB文字列
	 * @param carNumber
	 *            車のナンバー
	 * @param dateTimeStart
	 *            開始時間の文字列        
	 * @param dateTimeEnd
	 *            文字列               
	 * @return 終了の文字列
	 */
	static String searchCmd(String table, String carNumber,
			String dateTimeStart, String dateTimeEnd) {
		String sql = "select * from " + table;
		if (carNumber != null || dateTimeStart != null || dateTimeEnd != null) {
			sql += " where ";
		}
		if (carNumber != null) {
			sql += " CarNumber='" + carNumber + "'";
		}
		if (dateTimeStart != null && dateTimeEnd != null) {
			sql += "DateTime > '" + dateTimeStart + "' and " + "DateTime < '"
					+ dateTimeEnd + "'";
		} else if (dateTimeEnd != null) {
			// do nothing
		} else if (dateTimeStart != null) {
			sql += "DateTime='" + dateTimeStart + "'";
		}
		return sql;
	}

	/**
	 * データ表に指定のデータを検索の命令を作成
	 * 
	 * @param table
	 *            文字列
	 * @param infoId
	 *           リアルタイム情報id
	 * @return 文字列を返し
	 */
	static String searchCmd(String table, long infoId) {
		String sql = "select * from " + table + " where ";
		sql += " InfoId='" + infoId + "'";

		return sql;
	}

	/**
	 * 登録データを合成
	 * 
	 * @param ard
	 *            ArrayListのデータ
	 * @param mbp
	 *           Map<String, ArrayList<BatteryPacket>>のデータ
	 * @param mrd
	 *            Map<String, RegistData>のデータ
	 * @return 文字列を返し
	 */
	static ArrayList<RegistData> registDataComposite(ArrayList<RegistData> ard,
			Map<String, ArrayList<BatteryPacket>>mbp, Map<String, RegistData> mrd) {
		for (RegistData rd : ard) {
			RegistData rdt = mrd.get(rd.getCarNumber());
			rd.setDateTime(rdt.getDateTime());
			rd.setRegistSerialNumber(rdt.getRegistSerialNumber());
			rd.setBatteryPackets(mbp.get(rd.getCarNumber()));
		}
		return ard;
	}

	/**
	 * databaseからEVDCMのregistedデータを取得する
	 * 
	 * @param srd
	 *           スデータを見つけるための初期条件
	 * @param erd
	 *            スデータを見つけるための終了条件
	 * @return スデータを取得成功場合、trueを返し
	 */
	static public ArrayList<RegistData> registDataGet(RegistData srd,
			RegistData erd) {
		if (srd == null && erd == null) {
			// 如果srd和erd都为空，表示搜索全部
			String sql = searchAllCmd(BASIC_INFO_TABLE);
			ArrayList<RegistData> ard = DBProcess.getInstance()
					.basicDataSearch(sql); // 表1
			sql = searchAllCmd(BATTERY_CODE_TABLE);
			Map<String, ArrayList<BatteryPacket>> mbp = DBProcess.getInstance()
					.batteryCodeDataSearch(sql); // 表2
			sql = searchAllCmd(LOGIN_TABLE);
			Map<String, RegistData> mrd = DBProcess.getInstance()
					.loginDataLastDataSearch(sql); // 表3

			return registDataComposite(ard, mbp, mrd);
		} else if (srd != null && erd == null) {
			// 如果只有srd不为空，搜索与给定值相同的车辆信息
			String sql = searchCmd(BASIC_INFO_TABLE, srd.getCarNumber(), null,
					null);
			ArrayList<RegistData> ard = DBProcess.getInstance()
					.basicDataSearch(sql); // 表1
			sql = searchCmd(BATTERY_CODE_TABLE, srd.getCarNumber(), null,
					null);
			Map<String, ArrayList<BatteryPacket>> mbp = DBProcess.getInstance()
					.batteryCodeDataSearch(sql); // 表2
			sql = searchCmd(LOGIN_TABLE, srd.getCarNumber(), null, null);
			Map<String, RegistData> mrd = DBProcess.getInstance()
					.loginDataLastDataSearch(sql); // 表3

			return registDataComposite(ard, mbp, mrd);
		} else if (srd == null && erd != null) {
			// 如果erd不为空，而srd为空则查找最新一次的数据
			return null;
		} else {
			// 如果srd和erd都不为空，则搜索最后登陆时间是srd到erd时间段的所有车辆信息
			String sql = searchCmd(LOGIN_TABLE, null, srd.getDateTime(),
					erd.getDateTime());
			Map<String, RegistData> mrd = DBProcess.getInstance()
					.loginDataLastDataSearch(sql); // 表3

			ArrayList<RegistData> rard = new ArrayList<RegistData>();

			Iterator<String> carNumbers = mrd.keySet().iterator();
			while (carNumbers.hasNext()) {
				String carNumber = carNumbers.next();
				sql = searchCmd(BASIC_INFO_TABLE, carNumber, null, null);
				ArrayList<RegistData> ard = DBProcess.getInstance()
						.basicDataSearch(sql); // 表1
				
				RegistData rd = ard.get(0);
				rd.setDateTime(mrd.get(carNumber).getDateTime());
				rd.setRegistSerialNumber(mrd.get(carNumber).getRegistSerialNumber());
				
				sql = searchCmd(BATTERY_CODE_TABLE, carNumber, null, null);
				Map<String, ArrayList<BatteryPacket>> mbp = DBProcess.getInstance()
						.batteryCodeDataSearch(sql); // 表2
				
				rd.setBatteryPackets(mbp.get(rd.getCarNumber()));
				
				rard.add(rd);
			}

			return rard;
		}
	}

	/**
	 * databaseからEVDCMのstatusデータを取得する
	 * 
	 * @param ssd
	 *            ステータスデータを見つけるための初期条件
	 * @param esd
	 *            ステータスデータを見つけるための終了条件
	 * @return ステータスデータを取得成功場合、trueを返し
	 */
	static public ArrayList<StatusData> statusDataGet(StatusData ssd,
			StatusData esd) {
		if (ssd == null && esd == null) {
			// 如果ssd和esd都为空，表示搜索全部
			String sql = searchAllCmd(TERMINAL_STATUS_TABLE);
			ArrayList<StatusData> asd = DBProcess.getInstance()
					.statusDataSearch(sql); // 表1
			return asd;
		} else if (ssd != null && esd == null) {
			// 如果只有ssd不为空，搜索与给定值相同的车辆信息
			String sql = searchCmd(TERMINAL_STATUS_TABLE, ssd.getCarNumber(),
					ssd.getDateTime(), null);
			ArrayList<StatusData> asd = DBProcess.getInstance()
					.statusDataSearch(sql); // 表1
			return asd;
		} else if (ssd == null && esd != null) {
			// 如果esd不为空，而ssd为空则查找最新一次的数据
			ArrayList<StatusData> asd = statusDataGet(esd, ssd);
			int cnt = asd.size();
			for(int i=0; i<cnt-1; i++) {
				asd.remove(0);
			}
			return asd;
		} else {
			// 如果ssd和esd都不为空，则搜索ssd到esd时间段的所有信息，还有ssd和esd的车牌号必须相同
			if (!ssd.getCarNumber().equals(esd.getCarNumber())) {
				return null;
			} else {
				String sql = searchCmd(TERMINAL_STATUS_TABLE,
						ssd.getCarNumber(), ssd.getDateTime(),
						esd.getDateTime());
				ArrayList<StatusData> asd = DBProcess.getInstance()
						.statusDataSearch(sql); // 表1
				return asd;
			}
		}

	}

	/**
	 * databaseからEVDCMのvoltageデータを取得する
	 * 
	 * @param srtvd
	 *            電圧スデータを見つけるための初期条件.
	 * @param ertvd
	 *            電圧スデータを見つけるための終了条件.
	 * @return 電圧スデータを取得成功場合、trueを返し
	 */
	static public ArrayList<RealTimeVoltageData> realTimeVoltageDataGet(
			RealTimeVoltageData srtvd, RealTimeVoltageData ertvd) {
		if (srtvd == null && ertvd == null) {
			// 如果srtvd和ertvd都为空，表示搜索全部
			String sql = searchAllCmd(BATTERY_VOLTAGE_PACK_TABLE);
			Map<Long, RealTimeVoltageData> mrvd = DBProcess.getInstance()
					.realTimeVoltageDataSearch(sql); // 表1

			ArrayList<RealTimeVoltageData> rard = new ArrayList<RealTimeVoltageData>();

			Iterator<Long> infoIds = mrvd.keySet().iterator();
			while (infoIds.hasNext()) {
				RealTimeInfoId rtii = new RealTimeInfoId();
				long infoid = infoIds.next();

				rtii.setInfoId(infoid);
				sql = realTimeInfoIdQuery(rtii);
				RealTimeInfoId infoId = DBProcess.getInstance()
						.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

				RealTimeVoltageData rtvd = mrvd.get(infoId);
				rtvd.setCarNumber(rtii.getCarNumber());
				rtvd.setDateTime(rtii.getDateTime());

				sql = searchCmd(BATTERY_VOLTAGE_VALUE_TABLE, infoid);
				Map<Integer, VoltagePacket> mvp = DBProcess.getInstance()
						.voltageDataSearch(sql); // 表2

				ArrayList<VoltagePacket> avp = new ArrayList<VoltagePacket>();
				Iterator<Integer> vps = mvp.keySet().iterator();
				while (vps.hasNext()) {
					avp.add(mvp.get(vps.next()));
				}
				rtvd.setVoltagePackets(avp);

				rard.add(rtvd);
			}

			return rard;
		} else if (srtvd != null && ertvd == null) {
			// 如果只有srtvd不为空，搜索与给定值相同的车辆信息
			if (Common.isStringNull(srtvd.getCarNumber())) {
				return null;
			}
			if (Common.isStringNull(srtvd.getDateTime())) {
				return null;
			}

			ArrayList<RealTimeVoltageData> rard = new ArrayList<RealTimeVoltageData>();

			RealTimeInfoId rtii = new RealTimeInfoId();

			rtii.setCarNumber(srtvd.getCarNumber());
			rtii.setDateTime(srtvd.getDateTime());
			String sql = realTimeInfoIdQuery(rtii);
			RealTimeInfoId infoId = DBProcess.getInstance()
					.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

			long infoid = infoId.getInfoId();

			sql = searchCmd(BATTERY_VOLTAGE_PACK_TABLE, infoid);
			Map<Long, RealTimeVoltageData> mrvd = DBProcess.getInstance()
					.realTimeVoltageDataSearch(sql); // 表1

			RealTimeVoltageData rtvd = mrvd.get(infoid);

			rtvd.setCarNumber(rtii.getCarNumber());
			rtvd.setDateTime(rtii.getDateTime());

			sql = searchCmd(BATTERY_VOLTAGE_VALUE_TABLE, infoid);
			Map<Integer, VoltagePacket> mvp = DBProcess.getInstance()
					.voltageDataSearch(sql); // 表2

			ArrayList<VoltagePacket> avp = new ArrayList<VoltagePacket>();
			Iterator<Integer> vps = mvp.keySet().iterator();
			while (vps.hasNext()) {
				avp.add(mvp.get(vps.next()));
			}
			rtvd.setVoltagePackets(avp);

			rard.add(rtvd);

			return rard;
		} else if (srtvd == null && ertvd != null) {
			// 如果ertvd不为空，而srtvd为空则查找最新一次的数据
			if (Common.isStringNull(ertvd.getCarNumber())) {
				return null;
			}
			RealTimeInfoId rtii = new RealTimeInfoId();
			rtii.setCarNumber(ertvd.getCarNumber());
			rtii = realTimeInfoIdGet(rtii);

			ArrayList<RealTimeVoltageData> rard = null;
			
			if (rtii != null) {
				ertvd.setDateTime(rtii.getDateTime());
				rard = realTimeVoltageDataGet(ertvd, null);
			}
			
			return rard;
		} else {
			// 如果srtvd和ertvd都不为空，则搜索srtvd到ertvd时间段的所有信息，还有srtvd和ertvd的车牌号必须相同
			if (!srtvd.getCarNumber().equals(ertvd.getCarNumber())) {
				return null;
			} else {
				String sql = searchCmd(REAL_TIME_INFO_ID_TABLE,
						srtvd.getCarNumber(), srtvd.getDateTime(),
						ertvd.getDateTime());
				ArrayList<RealTimeInfoId> infoIds = DBProcess.getInstance()
						.realTimeInfoIdsSearch(sql); // 表realTimeInfoId

				ArrayList<RealTimeVoltageData> rard = new ArrayList<RealTimeVoltageData>();

				for (RealTimeInfoId infoId : infoIds) {
					long infoid = infoId.getInfoId();

					sql = searchCmd(BATTERY_VOLTAGE_PACK_TABLE, infoid);
					Map<Long, RealTimeVoltageData> mrvd = DBProcess
							.getInstance().realTimeVoltageDataSearch(sql); // 表1

					RealTimeVoltageData rtvd = mrvd.get(infoid);

					rtvd.setCarNumber(infoId.getCarNumber());
					rtvd.setDateTime(infoId.getDateTime());

					sql = searchCmd(BATTERY_VOLTAGE_VALUE_TABLE, infoid);
					Map<Integer, VoltagePacket> mvp = DBProcess.getInstance()
							.voltageDataSearch(sql); // 表2

					ArrayList<VoltagePacket> avp = new ArrayList<VoltagePacket>();
					Iterator<Integer> vps = mvp.keySet().iterator();
					while (vps.hasNext()) {
						avp.add(mvp.get(vps.next()));
					}
					rtvd.setVoltagePackets(avp);

					rard.add(rtvd);
				}

				return rard;
			}

		}
	}

	/**
	 * databaseからEVDCMのtemperatureデータを取得する
	 * 
	 * @param srttd
	 *            気温スデータを見つけるための初期条件.
	 * @param erttd
	 *            気温スデータを見つけるための終了条件.
	 * @return 気温スデータを取得成功場合、trueを返し
	 */
	static public ArrayList<RealTimeTemperatureData> realTimeTemperatureDataGet(
			RealTimeTemperatureData srttd, RealTimeTemperatureData erttd) {
		if (srttd == null && erttd == null) {
			// 如果srttd和erttd都为空，表示搜索全部
			String sql = searchAllCmd(BATTERY_TEMPERATURE_PACK_TABLE);
			Map<Long, RealTimeTemperatureData> mrtd = DBProcess.getInstance()
					.realTimeTemperatureDataSearch(sql); // 表1

			ArrayList<RealTimeTemperatureData> arttd = new ArrayList<RealTimeTemperatureData>();

			Iterator<Long> infoIds = mrtd.keySet().iterator();
			while (infoIds.hasNext()) {
				RealTimeInfoId rtii = new RealTimeInfoId();
				long infoid = infoIds.next();

				rtii.setInfoId(infoid);
				sql = realTimeInfoIdQuery(rtii);
				RealTimeInfoId infoId = DBProcess.getInstance()
						.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

				RealTimeTemperatureData rttd = mrtd.get(infoId);
				rttd.setCarNumber(rtii.getCarNumber());
				rttd.setDateTime(rtii.getDateTime());

				sql = searchCmd(BATTERY_TEMPERATURE_VALUE_TABLE, infoid);
				Map<Integer, TemperaturePacket> mtp = DBProcess.getInstance()
						.temperatureDataSearch(sql); // 表2

				ArrayList<TemperaturePacket> atp = new ArrayList<TemperaturePacket>();
				Iterator<Integer> tps = mtp.keySet().iterator();
				while (tps.hasNext()) {
					atp.add(mtp.get(tps.next()));
				}
				rttd.setTemperaturePackets(atp);

				arttd.add(rttd);
			}

			return arttd;
		} else if (srttd != null && erttd == null) {
			// 如果只有srttd不为空，搜索与给定值相同的车辆信息
			if (Common.isStringNull(srttd.getCarNumber())) {
				return null;
			}
			if (Common.isStringNull(srttd.getDateTime())) {
				return null;
			}

			ArrayList<RealTimeTemperatureData> rard = new ArrayList<RealTimeTemperatureData>();

			RealTimeInfoId rtii = new RealTimeInfoId();

			rtii.setCarNumber(srttd.getCarNumber());
			rtii.setDateTime(srttd.getDateTime());
			String sql = realTimeInfoIdQuery(rtii);
			RealTimeInfoId infoId = DBProcess.getInstance()
					.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

			long infoid = infoId.getInfoId();

			sql = searchCmd(BATTERY_TEMPERATURE_PACK_TABLE, infoid);
			Map<Long, RealTimeTemperatureData> mrtd = DBProcess.getInstance()
					.realTimeTemperatureDataSearch(sql); // 表1

			RealTimeTemperatureData rttd = mrtd.get(infoid);

			rttd.setCarNumber(rtii.getCarNumber());
			rttd.setDateTime(rtii.getDateTime());

			sql = searchCmd(BATTERY_TEMPERATURE_VALUE_TABLE, infoid);
			Map<Integer, TemperaturePacket> mtp = DBProcess.getInstance()
					.temperatureDataSearch(sql); // 表2

			ArrayList<TemperaturePacket> atp = new ArrayList<TemperaturePacket>();
			Iterator<Integer> tps = mtp.keySet().iterator();
			while (tps.hasNext()) {
				atp.add(mtp.get(tps.next()));
			}
			rttd.setTemperaturePackets(atp);

			rard.add(rttd);

			return rard;

		} else if (srttd == null && erttd != null) {
			// 如果erttd不为空，而srttd为空则查找最新一次的数据
			if (Common.isStringNull(erttd.getCarNumber())) {
				return null;
			}
			RealTimeInfoId rtii = new RealTimeInfoId();
			rtii.setCarNumber(erttd.getCarNumber());
			rtii = realTimeInfoIdGet(rtii);

			ArrayList<RealTimeTemperatureData> rard = null;
			if (rtii != null) {
				erttd.setDateTime(rtii.getDateTime());
				rard = realTimeTemperatureDataGet(erttd, null);
			}

			return rard;
		} else {
			// 如果srttd和erttd都不为空，则搜索srttd到erttd时间段的所有信息，还有srttd和erttd的车牌号必须相同
			if (!srttd.getCarNumber().equals(erttd.getCarNumber())) {
				return null;
			} else {
				String sql = searchCmd(REAL_TIME_INFO_ID_TABLE,
						srttd.getCarNumber(), srttd.getDateTime(),
						erttd.getDateTime());
				ArrayList<RealTimeInfoId> infoIds = DBProcess.getInstance()
						.realTimeInfoIdsSearch(sql); // 表realTimeInfoId

				ArrayList<RealTimeTemperatureData> rard = new ArrayList<RealTimeTemperatureData>();

				for (RealTimeInfoId infoId : infoIds) {
					long infoid = infoId.getInfoId();

					sql = searchCmd(BATTERY_TEMPERATURE_PACK_TABLE, infoid);
					Map<Long, RealTimeTemperatureData> mrtd = DBProcess
							.getInstance().realTimeTemperatureDataSearch(sql); // 表1

					RealTimeTemperatureData rttd = mrtd.get(infoid);

					rttd.setCarNumber(infoId.getCarNumber());
					rttd.setDateTime(infoId.getDateTime());

					sql = searchCmd(BATTERY_TEMPERATURE_VALUE_TABLE, infoid);
					Map<Integer, TemperaturePacket> mtp = DBProcess
							.getInstance().temperatureDataSearch(sql); // 表2

					ArrayList<TemperaturePacket> atp = new ArrayList<TemperaturePacket>();
					Iterator<Integer> tps = mtp.keySet().iterator();
					while (tps.hasNext()) {
						atp.add(mtp.get(tps.next()));
					}
					rttd.setTemperaturePackets(atp);

					rard.add(rttd);
				}

				return rard;
			}
		}
	}

	/**
	 * databaseからEVDCMのvehicleデータを取得する
	 * 
	 * @param srtvd
	 *            車両スデータを見つけるための初期条件.
	 * @param ertvd
	 *            車両スデータを見つけるための終了条件.
	 * @return 車両スデータを取得成功場合、trueを返し
	 */
	static public ArrayList<RealTimeVehicleData> realTimeVehicleDataGet(
			RealTimeVehicleData srtvd, RealTimeVehicleData ertvd) {
		if (srtvd == null && ertvd == null) {
			// 如果srtvd和ertvd都为空，表示搜索全部
			String sql = searchAllCmd(VEHICLE_DATA_TABLE);
			Map<Long, RealTimeVehicleData> mrtd = DBProcess.getInstance()
					.realTimeVehicleDataSearch(sql); // 表1

			ArrayList<RealTimeVehicleData> artd = new ArrayList<RealTimeVehicleData>();

			Iterator<Long> infoIds = mrtd.keySet().iterator();
			while (infoIds.hasNext()) {
				RealTimeInfoId rtii = new RealTimeInfoId();
				long infoid = infoIds.next();

				rtii.setInfoId(infoid);
				sql = realTimeInfoIdQuery(rtii);
				RealTimeInfoId infoId = DBProcess.getInstance()
						.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

				RealTimeVehicleData rtd = mrtd.get(infoId);
				rtd.setCarNumber(rtii.getCarNumber());
				rtd.setDateTime(rtii.getDateTime());

				artd.add(rtd);
			}
			return artd;
		} else if (srtvd != null && ertvd == null) {
			// 如果只有srtvd不为空，搜索与给定值相同的车辆信息
			if (Common.isStringNull(srtvd.getCarNumber())) {
				return null;
			}
			if (Common.isStringNull(srtvd.getDateTime())) {
				return null;
			}

			ArrayList<RealTimeVehicleData> rard = new ArrayList<RealTimeVehicleData>();

			RealTimeInfoId rtii = new RealTimeInfoId();

			rtii.setCarNumber(srtvd.getCarNumber());
			rtii.setDateTime(srtvd.getDateTime());
			String sql = realTimeInfoIdQuery(rtii);
			RealTimeInfoId infoId = DBProcess.getInstance()
					.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

			long infoid = infoId.getInfoId();

			sql = searchCmd(VEHICLE_DATA_TABLE, infoid);
			Map<Long, RealTimeVehicleData> mrtd = DBProcess.getInstance()
					.realTimeVehicleDataSearch(sql); // 表1

			RealTimeVehicleData rtd = mrtd.get(infoid);

			rtd.setCarNumber(rtii.getCarNumber());
			rtd.setDateTime(rtii.getDateTime());

			rard.add(rtd);

			return rard;
		} else if (srtvd == null && ertvd != null) {
			// 如果ertvd不为空，而srtvd为空则查找最新一次的数据
			if (Common.isStringNull(ertvd.getCarNumber())) {
				return null;
			}
			RealTimeInfoId rtii = new RealTimeInfoId();
			rtii.setCarNumber(ertvd.getCarNumber());
			rtii = realTimeInfoIdGet(rtii);

			ArrayList<RealTimeVehicleData> rard = null;
			
			if (rtii != null) {
				ertvd.setDateTime(rtii.getDateTime());
				rard = realTimeVehicleDataGet(ertvd, null);
			}
			
			return rard;
		} else {
			// 如果srtvd和ertvd都不为空，则搜索srtvd到ertvd时间段的所有信息，还有srtvd和ertvd的车牌号必须相同
			if (!srtvd.getCarNumber().equals(ertvd.getCarNumber())) {
				return null;
			} else {
				String sql = searchCmd(REAL_TIME_INFO_ID_TABLE,
						srtvd.getCarNumber(), srtvd.getDateTime(),
						ertvd.getDateTime());
				ArrayList<RealTimeInfoId> infoIds = DBProcess.getInstance()
						.realTimeInfoIdsSearch(sql); // 表realTimeInfoId

				ArrayList<RealTimeVehicleData> rard = new ArrayList<RealTimeVehicleData>();

				for (RealTimeInfoId infoId : infoIds) {
					long infoid = infoId.getInfoId();

					sql = searchCmd(VEHICLE_DATA_TABLE, infoid);
					Map<Long, RealTimeVehicleData> mrtd = DBProcess
							.getInstance().realTimeVehicleDataSearch(sql); // 表1

					RealTimeVehicleData rttd = mrtd.get(infoid);

					rttd.setCarNumber(infoId.getCarNumber());
					rttd.setDateTime(infoId.getDateTime());

					rard.add(rttd);
				}

				return rard;
			}
		}
	}

	/**
	 * databaseからEVDCMのGPSデータを取得する
	 * 
	 * @param srtgpsd
	 *            GPSスデータを見つけるための初期条件
	 * @param ertgpsd
	 *            GPSスデータを見つけるための終了条件.
	 * @return GPSスデータを取得成功場合、trueを返し
	 */
	static public ArrayList<RealTimeGPSData> realTimeGPSDataGet(
			RealTimeGPSData srtgpsd, RealTimeGPSData ertgpsd) {
		if (srtgpsd == null && ertgpsd == null) {
			// 如果srtgpsd和ertgpsd都为空，表示搜索全部
			String sql = searchAllCmd(GPS_DATA_TABLE);
			ArrayList<RealTimeGPSData> agpsd = DBProcess.getInstance()
					.realTimeGPSDataSearch(sql); // 表1
			return agpsd;
		} else if (srtgpsd != null && ertgpsd == null) {
			// 如果只有srtgpsd不为空，搜索与给定值相同的车辆信息
			String sql = searchCmd(GPS_DATA_TABLE, srtgpsd.getCarNumber(),
					srtgpsd.getDateTime(), null);
			ArrayList<RealTimeGPSData> agpsd = DBProcess.getInstance()
					.realTimeGPSDataSearch(sql); // 表1
			return agpsd;
		} else if (srtgpsd == null && ertgpsd != null) {
			// 如果ertgpsd不为空，而srtgpsd为空则查找最新一次的数据
			return null;
		} else {
			// 如果srtgpsd和ertgpsd都不为空，则搜索srtgpsd到ertgpsd时间段的所有信息，还有srtgpsd和ertgpsd的车牌号必须相同
			if (!srtgpsd.getCarNumber().equals(ertgpsd.getCarNumber())) {
				return null;
			} else {
				String sql = searchCmd(GPS_DATA_TABLE, srtgpsd.getCarNumber(),
						srtgpsd.getDateTime(), ertgpsd.getDateTime());
				ArrayList<RealTimeGPSData> agpsd = DBProcess.getInstance()
						.realTimeGPSDataSearch(sql); // 表1
				return agpsd;
			}
		}
	}

	/**
	 * databaseからEVDCMのExtremumデータを取得する.
	 * 
	 * @param srted
	 *            極値スデータを見つけるための初期条件.
	 * @param erted
	 *            極値スデータを見つけるための終了条件.
	 * @return 極値スデータを取得成功場合、trueを返し
	 */
	static public ArrayList<RealTimeExtremumData> realTimeExtremumDataGet(
			RealTimeExtremumData srted, RealTimeExtremumData erted) {
		if (srted == null && erted == null) {
			// 如果srted和erted都为空，表示搜索全部
			String sql = searchAllCmd(EXTREMUM_DATA_TABLE);
			Map<Long, RealTimeExtremumData> mrtd = DBProcess.getInstance()
					.realTimeExtremumDataSearch(sql); // 表1

			ArrayList<RealTimeExtremumData> artd = new ArrayList<RealTimeExtremumData>();

			Iterator<Long> infoIds = mrtd.keySet().iterator();
			while (infoIds.hasNext()) {
				RealTimeInfoId rtii = new RealTimeInfoId();
				long infoid = infoIds.next();

				rtii.setInfoId(infoid);
				sql = realTimeInfoIdQuery(rtii);
				RealTimeInfoId infoId = DBProcess.getInstance()
						.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

				RealTimeExtremumData rtd = mrtd.get(infoId);
				rtd.setCarNumber(rtii.getCarNumber());
				rtd.setDateTime(rtii.getDateTime());

				artd.add(rtd);
			}
			return artd;
		} else if (srted != null && erted == null) {
			// 如果只有srted不为空，搜索与给定值相同的车辆信息
			if (Common.isStringNull(srted.getCarNumber())) {
				return null;
			}
			if (Common.isStringNull(srted.getDateTime())) {
				return null;
			}

			ArrayList<RealTimeExtremumData> rard = new ArrayList<RealTimeExtremumData>();

			RealTimeInfoId rtii = new RealTimeInfoId();

			rtii.setCarNumber(srted.getCarNumber());
			rtii.setDateTime(srted.getDateTime());
			String sql = realTimeInfoIdQuery(rtii);
			RealTimeInfoId infoId = DBProcess.getInstance()
					.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

			long infoid = infoId.getInfoId();

			sql = searchCmd(EXTREMUM_DATA_TABLE, infoid);
			Map<Long, RealTimeExtremumData> mrtd = DBProcess.getInstance()
					.realTimeExtremumDataSearch(sql); // 表1

			RealTimeExtremumData rtd = mrtd.get(infoid);

			rtd.setCarNumber(rtii.getCarNumber());
			rtd.setDateTime(rtii.getDateTime());

			rard.add(rtd);

			return rard;
		} else if (srted == null && erted != null) {
			// 如果erted不为空，而srted为空则查找最新一次的数据
			if (Common.isStringNull(erted.getCarNumber())) {
				return null;
			}
			RealTimeInfoId rtii = new RealTimeInfoId();
			rtii.setCarNumber(erted.getCarNumber());
			rtii = realTimeInfoIdGet(rtii);

			ArrayList<RealTimeExtremumData> ared = null;
			if(rtii != null) {
				erted.setDateTime(rtii.getDateTime());
				ared = realTimeExtremumDataGet(erted, null);
			}

			return ared;
		} else {
			// 如果srted和erted都不为空，则搜索srted到erted时间段的所有信息，还有srted和erted的车牌号必须相同
			if (!srted.getCarNumber().equals(erted.getCarNumber())) {
				return null;
			} else {
				String sql = searchCmd(REAL_TIME_INFO_ID_TABLE,
						srted.getCarNumber(), srted.getDateTime(),
						erted.getDateTime());
				ArrayList<RealTimeInfoId> infoIds = DBProcess.getInstance()
						.realTimeInfoIdsSearch(sql); // 表realTimeInfoId

				ArrayList<RealTimeExtremumData> rard = new ArrayList<RealTimeExtremumData>();

				for (RealTimeInfoId infoId : infoIds) {
					long infoid = infoId.getInfoId();

					sql = searchCmd(EXTREMUM_DATA_TABLE, infoid);
					Map<Long, RealTimeExtremumData> mrtd = DBProcess
							.getInstance().realTimeExtremumDataSearch(sql); // 表1

					RealTimeExtremumData rttd = mrtd.get(infoid);

					rttd.setCarNumber(infoId.getCarNumber());
					rttd.setDateTime(infoId.getDateTime());

					rard.add(rttd);
				}

				return rard;
			}
		}
	}

	/**
	 * databaseからEVDCMのalarmデータを取得する.
	 * 
	 * @param srtad
	 *            アラームスデータを見つけるための初期条件.
	 * @param ertad
	 *            アラームスデータを見つけるための終了条件.
	 * @return アラームスデータを取得成功場合、trueを返し
	 */
	static public ArrayList<RealTimeAlarmData> realTimeAlarmDataGet(
			RealTimeAlarmData srtad, RealTimeAlarmData ertad) {
		if (srtad == null && ertad == null) {
			// 如果srtad和ertad都为空，表示搜索全部
			String sql = searchAllCmd(ALARM_DATA_TABLE);
			Map<Long, RealTimeAlarmData> mrtd = DBProcess.getInstance()
					.realTimeAlarmDataSearch(sql); // 表1

			ArrayList<RealTimeAlarmData> artd = new ArrayList<RealTimeAlarmData>();

			Iterator<Long> infoIds = mrtd.keySet().iterator();
			while (infoIds.hasNext()) {
				RealTimeInfoId rtii = new RealTimeInfoId();
				long infoid = infoIds.next();

				rtii.setInfoId(infoid);
				sql = realTimeInfoIdQuery(rtii);
				RealTimeInfoId infoId = DBProcess.getInstance()
						.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

				RealTimeAlarmData rtd = mrtd.get(infoId);
				rtd.setCarNumber(rtii.getCarNumber());
				rtd.setDateTime(rtii.getDateTime());

				sql = searchCmd(BATTERY_OTHER_FAULT_CODES_TABLE, infoid);
				ArrayList<Integer> ai = DBProcess.getInstance()
						.batteryOtherFaultCodesDataSearch(sql); // 表2
				rtd.setBatteryOtherFaultCodes(ai);

				sql = searchCmd(MOTOR_FAULT_CODES_TABLE, infoid);
				ai = DBProcess.getInstance().motorFaultCodesDataSearch(sql); // 表3
				rtd.setMotorFaultCodes(ai);

				sql = searchCmd(MOTOR_FAULT_CODES_TABLE, infoid);
				ai = DBProcess.getInstance().otherFaultCodesDataSearch(sql); // 表4
				rtd.setOtherFaultCodes(ai);

				artd.add(rtd);
			}
			return artd;
		} else if (srtad != null && ertad == null) {
			// 如果只有srtad不为空，搜索与给定值相同的车辆信息
			if (Common.isStringNull(srtad.getCarNumber())) {
				return null;
			}
			if (Common.isStringNull(srtad.getDateTime())) {
				return null;
			}

			ArrayList<RealTimeAlarmData> rard = new ArrayList<RealTimeAlarmData>();

			RealTimeInfoId rtii = new RealTimeInfoId();

			rtii.setCarNumber(srtad.getCarNumber());
			rtii.setDateTime(srtad.getDateTime());
			String sql = realTimeInfoIdQuery(rtii);
			RealTimeInfoId infoId = DBProcess.getInstance()
					.realTimeInfoIdLastIdSearch(sql); // 表realTimeInfoId

			long infoid = infoId.getInfoId();

			sql = searchCmd(ALARM_DATA_TABLE, infoid);
			Map<Long, RealTimeAlarmData> mrtd = DBProcess.getInstance()
					.realTimeAlarmDataSearch(sql); // 表1

			RealTimeAlarmData rtd = mrtd.get(infoid);

			rtd.setCarNumber(rtii.getCarNumber());
			rtd.setDateTime(rtii.getDateTime());

			sql = searchCmd(BATTERY_OTHER_FAULT_CODES_TABLE, infoid);
			ArrayList<Integer> ai = DBProcess.getInstance()
					.batteryOtherFaultCodesDataSearch(sql); // 表2
			rtd.setBatteryOtherFaultCodes(ai);

			sql = searchCmd(MOTOR_FAULT_CODES_TABLE, infoid);
			ai = DBProcess.getInstance().motorFaultCodesDataSearch(sql); // 表3
			rtd.setMotorFaultCodes(ai);

			sql = searchCmd(MOTOR_FAULT_CODES_TABLE, infoid);
			ai = DBProcess.getInstance().otherFaultCodesDataSearch(sql); // 表4
			rtd.setOtherFaultCodes(ai);

			rard.add(rtd);

			return rard;
		} else if (srtad == null && ertad != null) {
			// 如果ertad不为空，而srtad为空则查找最新一次的数据
			if (Common.isStringNull(ertad.getCarNumber())) {
				return null;
			}
			RealTimeInfoId rtii = new RealTimeInfoId();
			rtii.setCarNumber(ertad.getCarNumber());
			rtii = realTimeInfoIdGet(rtii);

			ArrayList<RealTimeAlarmData> rard = null;
			if (rtii != null) {
				ertad.setDateTime(rtii.getDateTime());
				rard = realTimeAlarmDataGet(ertad, null);
			}
			return rard;
		} else {
			// 如果srtad和ertad都不为空，则搜索srtad到ertad时间段的所有信息，还有srtad和ertad的车牌号必须相同
			if (!srtad.getCarNumber().equals(ertad.getCarNumber())) {
				return null;
			} else {
				String sql = searchCmd(REAL_TIME_INFO_ID_TABLE,
						srtad.getCarNumber(), srtad.getDateTime(),
						ertad.getDateTime());
				ArrayList<RealTimeInfoId> infoIds = DBProcess.getInstance()
						.realTimeInfoIdsSearch(sql); // 表realTimeInfoId

				ArrayList<RealTimeAlarmData> rard = new ArrayList<RealTimeAlarmData>();

				for (RealTimeInfoId infoId : infoIds) {
					long infoid = infoId.getInfoId();

					sql = searchCmd(ALARM_DATA_TABLE, infoid);
					Map<Long, RealTimeAlarmData> mrtd = DBProcess.getInstance()
							.realTimeAlarmDataSearch(sql); // 表1

					RealTimeAlarmData rtd = mrtd.get(infoid);

					rtd.setCarNumber(infoId.getCarNumber());
					rtd.setDateTime(infoId.getDateTime());

					sql = searchCmd(BATTERY_OTHER_FAULT_CODES_TABLE, infoid);
					ArrayList<Integer> ai = DBProcess.getInstance()
							.batteryOtherFaultCodesDataSearch(sql); // 表2
					rtd.setBatteryOtherFaultCodes(ai);

					sql = searchCmd(MOTOR_FAULT_CODES_TABLE, infoid);
					ai = DBProcess.getInstance().motorFaultCodesDataSearch(
							sql); // 表3
					rtd.setMotorFaultCodes(ai);

					sql = searchCmd(MOTOR_FAULT_CODES_TABLE, infoid);
					ai = DBProcess.getInstance().otherFaultCodesDataSearch(
							sql); // 表4
					rtd.setOtherFaultCodes(ai);

					rard.add(rtd);
				}

				return rard;
			}
		}
	}

}
