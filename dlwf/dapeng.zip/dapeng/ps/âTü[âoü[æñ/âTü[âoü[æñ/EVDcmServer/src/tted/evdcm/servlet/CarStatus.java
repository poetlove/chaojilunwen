package tted.evdcm.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tted.evdcm.javabean.*;
import tted.evdcm.server.DBManager;
import tted.evdcm.server.struct.RealTimeExtremumData;


public class CarStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
 	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String flag = request.getParameter("flag");
		String carnum= request.getParameter("carnum");
		
		if(flag == null || flag == ""){
			carnum = new String(carnum.getBytes("ISO-8859-1"), "UTF-8");
		}
		StringBuffer presentPageResult = new StringBuffer();
		CarStatusShowRecord carstatusbean = null;
		HttpSession session = request.getSession(true);
		
		/**
		 * 创建javabean对象
		 */
		try{
			carstatusbean = (CarStatusShowRecord)session.getAttribute("carstatus");
			if(carstatusbean == null)
			{
				carstatusbean = new CarStatusShowRecord();                    
				session.setAttribute("carstatus", carstatusbean);
			}
		}
		catch(Exception exp)
		{
			carstatusbean = new CarStatusShowRecord();
			session.setAttribute("carstatus",carstatusbean);
		}
		
		RealTimeExtremumData ed = new RealTimeExtremumData();
		ed.setCarNumber(carnum);
		ArrayList<RealTimeExtremumData> eds = DBManager.realTimeExtremumDataGet(null,ed);
		
		if(eds != null && eds.size() > 0) {
			ed = eds.get(0);
		} else {
			ed = null;
		}
		presentPageResult = show(ed);
		
        carstatusbean.setPresentPageResult(presentPageResult);
        request.setAttribute("carnum",carnum);
		RequestDispatcher dispatcher = request.getRequestDispatcher("CarStatus.jsp");
		dispatcher.forward(request, response);  
	}
	
	public StringBuffer show(RealTimeExtremumData ed)
	{
		StringBuffer str = new StringBuffer();
			
//				str.append("<tr>");				  
//				str.append("<td background-color:#F5F5F5>单体蓄电池电压</td>");
//				str.append("<td background-color:#F5F5F5 colspan=2 style=color:#4682B4 >" +rs.getString("voltage") + "</td>");
//				str.append("</tr>");
//				str.append("<tr>");				  
//				str.append("<td background-color:#F5F5F5>动力蓄电池温度</td>");
//				str.append("<td background-color:#F5F5F5 style=color:#4682B4 colspan=2>" +rs.getString("temperature") + "</td>");
//				str.append("</tr>");
//				str.append("<tr>");				  
//				str.append("<td background-color:#F5F5F5 rowspan=3>整车数据</td>");
//				str.append("<td background-color:#F5F5F5 class=left>车速:</td>");
//				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("drive") + "</td>");
//				str.append("</tr>");
//				str.append("<tr>");				  
//				str.append("<td background-color:#F5F5F5 class=left>里程:</td>");
//				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("mileage") + "</td>");
//				str.append("</tr>");
//				str.append("<tr>");				  
//				str.append("<td background-color:#F5F5F5 class=left>档位:</td>");
//				str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +rs.getString("gear") + "</td>");
//				str.append("</tr>");

				if(ed != null) {
					str.append("<tr>");	
					str.append("<td background-color:#F5F5F5 rowspan=17>极值数据</td>");
					str.append("<td background-color:#F5F5F5 class=left>最高电压动力蓄电池单体所在电池包序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMaxVoltageBatteryPackNumber() + "</td>");
					str.append("</tr>");
					str.append("<tr>");	
					str.append("<td background-color:#F5F5F5 class=left>最高电压单体蓄电池序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMaxVoltageBatteryNumber() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>电池单体电压最高值</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getBatteryMaxVoltage() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最低电压动力蓄电池包序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getBatteryMaxVoltage() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最低电压单体蓄电池序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMinVoltageBatteryNumber() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>电池单体电压最低值</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getBatteryMinVoltage() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最高温度动力蓄电池包序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMaxTempBatteryPackNumber() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最高温度探针序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMaxTempProbeNumber() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最高温度值</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMaxTemperature() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最低温度动力蓄电池包序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMinTempBatteryPackNumber() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最低温度探针序号</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMinTempProbeNumber() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>最低温度值</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getMinTemperature() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>总电压</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getTotalVoltage() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>总电流</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getTotalCurrent() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>SOC</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4 class=center1>" +ed.getSOC() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>剩余能量</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4>" +ed.getRemainEnergy() + "</td>");
					str.append("</tr>");
					str.append("<tr>");				  
					str.append("<td background-color:#F5F5F5 class=left>绝缘电阻</td>");
					str.append("<td background-color:#F5F5F5 style=color:#4682B4>" +ed.getInsulationResistance() + "</td>");
					str.append("</tr>");
				}
				
				


		return str;
	}

}
