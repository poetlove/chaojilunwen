/*************************************************************************
 **
 * File Name		TerminalControlData.java
 * File Summary		DCMのコントロールの設定用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;
import tted.evdcm.server.utils.DcmDataOutputStream;

public class TerminalControlData {
	/* 車両ナンバー */
	String mCarNumber;
	/* コントロール時間 */
	String mDateTime;
	/* 命令ID */
	int mCmdId;
	/* 命令パラメータ */
	byte[] mParams;

	/**
	 * ユーザーの設定でTerminalControlData型実例を初期化
	 * 
	 * @param dp
	 *            ユーザーのDCMの操作用のデータ実例
	 * @return null
	 */
	public TerminalControlData(DcmParam dp) {
		mCarNumber = dp.getCarNumber();
		mDateTime = dp.getDateTime();
		mCmdId = dp.getCtrlId();

		mParams = null;
		if (dp.getCtrlId() == DcmParam.CTRLID_REMOTE_UPDATE) {
			RemoteUpdate ru = dp.getValueRemoteUpdate();
			mParams = ru.fromPacketToBytes();
		} else if (dp.getCtrlId() == DcmParam.CTRLID_DCM_ALARM) {
			DcmAlarm da = dp.getValueDcmAlarm();
			mParams = da.fromPacketToBytes();
		}

	}
	public TerminalControlData() {
		// nothing to do
	}

	/**
	 * 配列のデータをTerminalControlData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param byteStream
	 *            含むTerminalControlData情報の配列.
	 * @return 配列操作が正確時TerminalControlData実例を返し、でなければnullを返し
	 */
	static public TerminalControlData fromBytesToPacket(String carNumber, byte[] byteStream) {
		TerminalControlData terminalControlData = new TerminalControlData();
		terminalControlData.mCarNumber = carNumber;
		
		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			terminalControlData.mDateTime = Common.dateTimeFromBytes(dt);
			terminalControlData.mCmdId = Common.byteToInt(dataInputStream.readByte());
			if(byteStream.length > 7) {
				byte[] params = new byte[byteStream.length -7];
				dataInputStream.read(params, 0, params.length);
				terminalControlData.mParams = params;
			} else {
				terminalControlData.mParams = null;
			}

			return terminalControlData;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * TerminalControlData型のバックを配列のデータに変更
	 * 
	 * @param null
	 *           
	 * @return 操作が正確時配列のデータを返し、でなければnullを返し
	 */
	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			byte[] dt = Common.dateTimeToBytes(mDateTime);
			dataOutputStream.write(dt, 0, dt.length);
			dataOutputStream.writeByte(mCmdId);
			if(mParams != null) {
				dataOutputStream.write(mParams, 0, mParams.length);
			}

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public void setCarNumber(String value) {
		mCarNumber = value;
	}

	public void setDateTime(String value) {
		mDateTime = value;
	}

	public void setCmdId(int value) {
		mCmdId = value;
	}

	public void setParams(byte[] value) {
		mParams = value;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getCmdId() {
		return mCmdId;
	}

	public byte[] getParams() {
		return mParams;
	}

}
