package tted.evdcm.servlet;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * 验证用户
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// 获取jsp页面的输入内容
		String name = request.getParameter("name"); // 获取页面提交的用户名
		String psw = request.getParameter("password"); // 获取页面提交的密码

		// 连接数据库
		try {
			Connection con = null;
			ResultSet rs = null;
			Statement sql = null;
			try {
				Class.forName(Common.DBDriver);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			con = DriverManager.getConnection(Common.DBUrl, Common.DBUser, Common.DBPassword);
			sql = con.createStatement();

			// 查询数据库中是否存在获取的用户
			String condition = "select * from " + Common.USERS_TABLE
					+ " where " + Common.USER_NAME_COLUMN + "= " + "'" + name
					+ "'" + " and " + Common.PASSWORD_COLUMN + "= " + "'" + psw
					+ "'";
			rs = sql.executeQuery(condition);
			if (rs.next() == false) {
				request.setAttribute("message", "用户名或密码错误");
				request.getRequestDispatcher("Login.jsp").forward(request,
						response);
			} else {
				response.sendRedirect("carinfolist");
			}
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
}
