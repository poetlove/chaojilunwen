/*************************************************************************
 **
 * File Name		DcmManager.java
 * File Summary		受信データの制御、応答とDCMのコントロール
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import tted.evdcm.server.struct.DcmDataPacket;
import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.DcmParam;
import tted.evdcm.server.struct.DcmParamData;
import tted.evdcm.server.struct.ParamItem;
import tted.evdcm.server.struct.ParamQueryData;
import tted.evdcm.server.struct.ParamSetData;
import tted.evdcm.server.struct.RealTimeInfoId;
import tted.evdcm.server.struct.RegistData;
import tted.evdcm.server.struct.ServerIpPort;
import tted.evdcm.server.struct.TerminalControlData;
import tted.evdcm.server.struct.TimerEventPacket;
import tted.evdcm.server.utils.Common;

public class DcmManager {
	/**
	 * Dcmからデータを処理.
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param byteBuffer
	 *            DCMからのデータ.
	 * @return データ送信が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean fromDcmDataPacketProcess(Socket sk, byte[] byteBuffer) {

		DcmDataPacket ddp = DataManager.dcmDataPacketCheck(byteBuffer);
		if(ddp == null) {
			return false;
		}
		switch (ddp.getCmdFlag()) {
		case DataManager.CMD_REGIST: {
			return registDataPacketProcess(sk, ddp);
		}
		case DataManager.CMD_QUERY: {
			return paramQueryDataPacketProcess(sk, ddp);
		}
		case DataManager.CMD_SET: {
			return paramSetDataPacketProcess(sk, ddp);
		}
		case DataManager.CMD_DCM_CONTROL: {
			return terminalControlDataPacketProcess(sk, ddp);
		}
		case DataManager.CMD_REISSUED: {
			return reissuedDataPacketProcess(sk, ddp);
		}
		case DataManager.CMD_REAL_TIME: {
			return realTimeUpdateDataPacketProcess(sk, ddp);
		}
		case DataManager.CMD_STATUS: {
			return statusDataPacketProcess(sk, ddp);
		}
		case DataManager.CMD_HEART: {
			return heartDataPacketProcess(sk, ddp);
		}
		default:
			return false;

		}
	}

	/**
	 * Dcmのパラメータを取り.
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @param si
	 *            サーバーからユーザーに情報を送信することのインタフィース.
	 * @return データ設定が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean dcmParamDataGet(final DcmParam dp, DcmMessageGetInterface si) {
		if (dp == null) {
			return false;
		}
		if (dp.isSetParamQuery()) {
			TimerEventPacket timerEventPacket = new TimerEventPacket();
			timerEventPacket.setCarNumber(dp.getCarNumber());
			timerEventPacket.setDcmMessageProcInterface(si);
			timerEventPacket.setTimeCount(0);
			final DcmLocalParam dcmLocalParam = DataManager
					.getDcmLocalParamByString(dp.getCarNumber());
			if (dcmLocalParam == null) {
				return false;
			}
			timerEventPacket
					.setMaxPeriod(dcmLocalParam.getDcmResponseTime() * DcmLocalParam.HEART_HZ);
			timerEventPacket.setLoopCount(DcmParam.LOOP_CNT);
			timerEventPacket.setThread(new Thread() {
				public void run() {
					ParamQueryData pqd = new ParamQueryData(dp);
					Socket sk = DataManager.getSocketByString(dp.getCarNumber());
					if (sk != null) {
						byte[] bf = DataManager.dcmParamPacketSet(
								DataManager.CMD_QUERY, dcmLocalParam.getVin(),
								pqd.fromPacketToBytes());
						ConnectManager.toDcmDataPacketSend(sk, bf);
					} else {
						TimerManager.timerQueueRemove(dp.getCarNumber());
					}
				}
			});
			TimerManager.timerQueueAdd(timerEventPacket);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmのパラメータを設定.
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return データ設定が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean dcmParamDataSet(final DcmParam dp) {
		if (dp == null) {
			return false;
		}
		if (dp.isSetParamSet()) {
			TimerEventPacket timerEventPacket = new TimerEventPacket();
			timerEventPacket.setCarNumber(dp.getCarNumber());
			timerEventPacket.setDcmMessageProcInterface(null);
			timerEventPacket.setTimeCount(0);
			final DcmLocalParam dcmLocalParam = DataManager
					.getDcmLocalParamByString(dp.getCarNumber());
			if (dcmLocalParam == null) {
				return false;
			}
			timerEventPacket
					.setMaxPeriod(dcmLocalParam.getDcmResponseTime() * DcmLocalParam.HEART_HZ);
			timerEventPacket.setLoopCount(DcmParam.LOOP_CNT);
			timerEventPacket.setThread(new Thread() {
				public void run() {
					ParamSetData psd = new ParamSetData(dp);
					Socket sk = DataManager.getSocketByString(dp.getCarNumber());
					if (sk != null) {
						byte[] bf = DataManager.dcmParamPacketSet(
								DataManager.CMD_SET, dcmLocalParam.getVin(),
								psd.fromPacketToBytes());
						ConnectManager.toDcmDataPacketSend(sk, bf);
					} else {
						TimerManager.timerQueueRemove(dp.getCarNumber());
					}
				}
			});
			TimerManager.timerQueueAdd(timerEventPacket);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmをコントロール.
	 * 
	 * @param dp
	 *            DCMからのデータパック.
	 * @return データ設定が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean dcmTerminalCtrl(final DcmParam dp) {
		if (dp == null) {
			return false;
		}
		if (dp.isSetCtrl()) {
			TimerEventPacket timerEventPacket = new TimerEventPacket();
			timerEventPacket.setCarNumber(dp.getCarNumber());
			timerEventPacket.setDcmMessageProcInterface(null);
			timerEventPacket.setTimeCount(0);
			final DcmLocalParam dcmLocalParam = DataManager
					.getDcmLocalParamByString(dp.getCarNumber());
			if (dcmLocalParam == null) {
				return false;
			}
			timerEventPacket
					.setMaxPeriod(dcmLocalParam.getDcmResponseTime() * DcmLocalParam.HEART_HZ);
			timerEventPacket.setLoopCount(DcmParam.LOOP_CNT);
			timerEventPacket.setThread(new Thread() {
				public void run() {
					TerminalControlData tcd = new TerminalControlData(dp);
					Socket sk = DataManager.getSocketByString(dp.getCarNumber());
					if (sk != null) {
						byte[] bf = DataManager.dcmParamPacketSet(
								DataManager.CMD_DCM_CONTROL,
								dcmLocalParam.getVin(), tcd.fromPacketToBytes());
						ConnectManager.toDcmDataPacketSend(sk, bf);
					} else {
						TimerManager.timerQueueRemove(dp.getCarNumber());
					}
				}
			});
			TimerManager.timerQueueAdd(timerEventPacket);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmの登録データを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean registDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		boolean ret = DataManager.dataStoreDbProcess(null, ddp);
		if (ret) {
			RegistData registData = RegistData.fromBytesToPacket(ddp.getData());
			DataManager.saveSocketInList(registData.getCarNumber(), sk);
			DcmLocalParam dlp = new DcmLocalParam();
			dlp.init();

			RealTimeInfoId rtii = new RealTimeInfoId();
			rtii.setCarNumber(registData.getCarNumber());
			rtii = DBManager.realTimeInfoIdGet(rtii);
			if(rtii != null) {
				dlp.setRealTimeUpdateTime(rtii.getDateTime());
				dlp.setRealTimeInfoId(rtii.getInfoId());
			}

			dlp.setVin(ddp.getIdentifier());
			
			DcmStatusChangeInterface dsci = new DcmStatusChangeInterface() {
				@Override
				public void callOutLine() {
					// TODO Auto-generated method stub
					
				}
				
			};
			dlp.setDcmStatusChange(dsci);

			DataManager.saveDcmLocalParamInList(registData.getCarNumber(), dlp);
			byte[] buffer = DataManager.responsePacketSet(ddp.getCmdFlag(),
					ddp.getIdentifier());
			ConnectManager.toDcmDataPacketSend(sk, buffer);
			
			switchOtherServers(registData.getCarNumber());
			
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmの検査されたパラメータのデータを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean paramQueryDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		String carNumber = DataManager.getStringBySocket(sk);
		if (carNumber == null) {
			return false;
		}
		DcmLocalParam dcmLocalParam = DataManager
				.getDcmLocalParamByString(carNumber);
		if (dcmLocalParam == null) {
			return false;
		}
		if(ddp.getResponseFlag() == DataManager.RESPONSE_SUCCESS) {
		
			DcmParamData dcmParamData = DcmParamData.fromBytesToPacket(ddp
					.getData());
			if (dcmParamData == null) {
				return false;
			}
			int cnt = dcmParamData.getCount();
			ArrayList<ParamItem> pis = dcmParamData.getParamItems();
			for (int i = 0; i < cnt; i++) {
				ParamItem pi = pis.get(i);
				if (pi.getParamId() == DcmParam.PID_DCM_RESPONE_TIME) {
					dcmLocalParam.setDcmResponseTime(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_DCM_HEART_PERI) {
					dcmLocalParam.setHeartPeriod(pi.getParamInt());
				}
			}
			TimerEventPacket timerEventPacket = TimerManager
					.timerQueueRemove(carNumber);
			if (timerEventPacket != null) {
				if (timerEventPacket.getDcmMessageProcInterface() != null) {
					timerEventPacket.getDcmMessageProcInterface().callSuccessFunc(dcmParamData);
				}
			}
			return true;
		} else if(ddp.getResponseFlag() == DataManager.RESPONSE_MODIFY_ERR) {
			TimerManager.timerQueueRemove(carNumber);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmの設定されたパラメータのデータを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean paramSetDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		String carNumber = DataManager.getStringBySocket(sk);
		if (carNumber == null) {
			return false;
		}
		DcmLocalParam dcmLocalParam = DataManager
				.getDcmLocalParamByString(carNumber);
		if (dcmLocalParam == null) {
			return false;
		}
		if(ddp.getResponseFlag() != DataManager.RESPONSE_SUCCESS) {
			
			ParamSetData paramSetData = ParamSetData.fromBytesToPacket(carNumber,
					ddp.getData());
			if (paramSetData == null) {
				return false;
			}
			int cnt = paramSetData.getCount();
			ArrayList<ParamItem> pis = paramSetData.getParamItems();
			for (int i = 0; i < cnt; i++) {
				ParamItem pi = pis.get(i);
				if (pi.getParamId() == DcmParam.PID_DCM_RESPONE_TIME) {
					dcmLocalParam.setDcmResponseTime(pi.getParamInt());
				} else if (pi.getParamId() == DcmParam.PID_DCM_HEART_PERI) {
					dcmLocalParam.setHeartPeriod(pi.getParamInt());
				}
			}
			TimerEventPacket timerEventPacket = TimerManager
					.timerQueueRemove(carNumber);
			if (timerEventPacket != null) {
				// none
			}
			return true;
		} else if(ddp.getResponseFlag() != DataManager.RESPONSE_MODIFY_ERR) {
			TimerManager.timerQueueRemove(carNumber);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmのコントロールされたデータを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean terminalControlDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		String carNumber = DataManager.getStringBySocket(sk);
		if (carNumber == null) {
			return false;
		}
		if(ddp.getResponseFlag() != DataManager.RESPONSE_SUCCESS) {
				
			TerminalControlData terminalControlData = TerminalControlData
					.fromBytesToPacket(carNumber, ddp.getData());
			if (terminalControlData == null) {
				return false;
			}
	
			TimerEventPacket timerEventPacket = TimerManager
					.timerQueueRemove(carNumber);
			if (timerEventPacket != null) {
				// none
			}
			return true;
		} else  if(ddp.getResponseFlag() != DataManager.RESPONSE_MODIFY_ERR) {
			TimerManager.timerQueueRemove(carNumber);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmの追給データを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return true if data process success, else false
	 */
	static boolean reissuedDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		return realTimeUpdateDataPacketProcess(sk, ddp);
	}

	/**
	 * Dcmのリアルタイムデータを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean realTimeUpdateDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		String carNumber = DataManager.getStringBySocket(sk);
		if (carNumber == null) {
			return false;
		}
		DataManager.dataStoreDbProcess(carNumber, ddp);
		return true;
	}

	/**
	 * Dcmの情報データを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean statusDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		String carNumber = DataManager.getStringBySocket(sk);
		if (carNumber == null) {
			return false;
		}
		boolean ret = DataManager.dataStoreDbProcess(carNumber, ddp);
		if (ret) {
			byte[] buffer = DataManager.responsePacketSet(ddp.getCmdFlag(),
					ddp.getIdentifier());
			ConnectManager.toDcmDataPacketSend(sk, buffer);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Dcmのハートビットデータを処理
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param ddp
	 *            DCMからのデータパック.
	 * @return データ処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean heartDataPacketProcess(Socket sk, DcmDataPacket ddp) {
		String carNumber = DataManager.getStringBySocket(sk);
		if (carNumber != null) {
			DcmLocalParam dcmLocalParam = DataManager
					.getDcmLocalParamByString(carNumber);
			if (dcmLocalParam == null) {
				return false;
			}
			dcmLocalParam.setServerHeartCount(0);
			byte[] buffer = DataManager.responsePacketSet(ddp.getCmdFlag(),
					ddp.getIdentifier());
			ConnectManager.toDcmDataPacketSend(sk, buffer);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * サーバーの切り替えを処理
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @return サーバーの切り替えが必要の場合、trueを返し、でなければfalseを返し
	 */
	static boolean switchOtherServers(String carNumber) {
		if(DataManager.getDcmLocalParamList().size() > ConnectManager.MAX_CONNECTION_COUNT) {
			DcmParam dp = new DcmParam();
			
			dp.setCarNumber(carNumber);
			
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			dp.setDateTime(df.format(new Date()));
			
			ServerIpPort sip = ConnectManager.serverIpPortGet();
			
			dp.setBoolIntegratedPlatformIP(DcmParam.CMD_SET);
			dp.setValueIntegratedPlatformIP(Common.ipToBytes(sip.getServerIp()));
			dp.setBoolIntegratedPlatformPort(DcmParam.CMD_SET);
			dp.setValueIntegratedPlatformPort(sip.getServerPort());
			dcmParamDataSet(dp);
			return true;
		} else {
			return false;
		}
	}
}
