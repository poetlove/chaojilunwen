/*************************************************************************
 **
 * File Name		RealTimeInfoId.java
 * File Summary		リアルタイムデータ用のID結構体
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

public class RealTimeInfoId {
	public static final long DEFAULT_INFO_ID = 0;
	
	/* 車両ナンバー */
	String mCarNumber;
	/* データ採集時間 */
	String mDateTime;
	/* リアルタイムの情報ID */
	long mInfoId;
	
	public RealTimeInfoId() {
		mCarNumber = null;
		mDateTime = null;
		mInfoId = DEFAULT_INFO_ID;
	}
	public void setCarNumber(String num) {
		mCarNumber = num;
	}
	public String getCarNumber() {
		return mCarNumber;
	}
	public void setDateTime(String dt) {
		mDateTime = dt;
	}
	public String getDateTime() {
		return mDateTime;
	}
	public void setInfoId(long id) {
		mInfoId = id;
	}
	public long getInfoId() {
		return mInfoId;
	}
}
