/*************************************************************************
 **
 * File Name		TimerManager.java
 * File Summary		DCMのタイムアウト処理と週期的に関数のコール
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TimerTask;

import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.TimerEventPacket;
import tted.evdcm.server.utils.Common;

public class TimerManager {
	/**
	 * {TimerEventPacket}のストレージ管理表
	 */
	static ArrayList<TimerEventPacket> mTimerEventPackets = new ArrayList<TimerEventPacket>();

	/**
	 * サーバータをイミングで提供する任務
	 */
	static TimerTask mTimerTask = new TimerTask() {
		public void run() {
			if (Common.getServerShutDown()) {
				cancel();
				return;
			}
			timeEventProcess();
		}
	};

	/**
	 * タイムタスクを取り.
	 * 
	 * @return イミングで任務の実例
	 */
	static public TimerTask getTimeTask() {
		return mTimerTask;
	}

	/**
	 * タイムタスクにタイム情報を添加
	 * 
	 * @param tep
	 *            サーバー側定時タスクのデータバック
	 * @return データ添加が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean timerQueueAdd(TimerEventPacket tep) {
		mTimerEventPackets.add(tep);
		return true;
	}

	/**
	 * タイムタスクからタイム情報を削除
	 * 
	 * @param carNumber
	 *            車両ナンバー
	 * @return データ削除が正確時削除したデータを返し、でなければnullを返し
	 */
	static public TimerEventPacket timerQueueRemove(String carNumber) {
		if (mTimerEventPackets.isEmpty()) {
			return null;
		}
		int cnt = mTimerEventPackets.size();
		for (int i = 0; i < cnt; i++) {
			TimerEventPacket timerEventPacket = mTimerEventPackets.get(i);
			if (carNumber.equals(timerEventPacket.getCarNumber())) {
				mTimerEventPackets.remove(timerEventPacket);
				return timerEventPacket;
			}
		}
		return null;
	}

	/**
	 * タイムタスクのイベント処理
	 * 
	 * @return 定時タスクの処理が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean timeEventProcess() {
		if (heartProcess() == true) {
			return otherTimerEventsProcess();
		} else {
			return false;
		}
	}

	/**
	 * 各DCMの心拍週期を維持
	 * 
	 * @return 定時タスクの処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean heartProcess() {
		HashMap<String, DcmLocalParam> dlps = DataManager
				.getDcmLocalParamList();
		if (!dlps.isEmpty()) {
			ArrayList<String> carNums = new ArrayList<String>();
			Iterator<String> iter = dlps.keySet().iterator();
			while (iter.hasNext()) {
				String carNumber = (String) iter.next();
				DcmLocalParam dlp = dlps.get(carNumber);
				int temp = dlp.getServerHeartCount();
				temp++;
				dlp.setServerHeartCount(temp);
				/* local heart count > dcm heart count  */
				if (dlp.getServerHeartCount() >= (dlp.getHeartPeriod() + 1)
						* DcmLocalParam.HEART_HZ) {
					carNums.add(carNumber);

				}
			}
			if (carNums.size() > 0) {
				int cnt = carNums.size();
				for (int i = 0; i < cnt; i++) {
					String carNumber = carNums.get(i);
					DataManager.deleteSocketInList(carNumber);
					dlps.remove(carNumber);
					TimerEventPacket tep = timerQueueRemove(carNumber);
					if(tep != null && tep.getDcmMessageProcInterface() != null) {
						tep.getDcmMessageProcInterface().callErrorFunc("DCM Connect Error!!!");
					}
				}
			}
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 他のタイムイベトを処理
	 * 
	 * @return 定時タスクの処理が正確時trueを返し、でなければfalseを返し
	 */
	static boolean otherTimerEventsProcess() {
		// 下面内容是处理参数设置，查询，控制的代码
		if (!mTimerEventPackets.isEmpty()) {
			int cnt = mTimerEventPackets.size();
			for (int i = cnt - 1; i >= 0; i--) {
				TimerEventPacket timerEventPacket = mTimerEventPackets.get(i);
				if (timerEventPacket.getLoopCount() <= 0) {
					if(timerEventPacket.getDcmMessageProcInterface() != null) {
						timerEventPacket.getDcmMessageProcInterface().callErrorFunc("Time out!!!");
					}
					mTimerEventPackets.remove(timerEventPacket);
				}
			}

			cnt = mTimerEventPackets.size();
			for (int i = 0; i < cnt; i++) {
				TimerEventPacket timerEventPacket = mTimerEventPackets.get(i);
				if (timerEventPacket.getTimeCount() < timerEventPacket
						.getMaxPeriod()) {
					int temp = timerEventPacket.getTimeCount();
					temp++;
					timerEventPacket.setTimeCount(temp);
				} else {
					if (timerEventPacket.getLoopCount() > 0) {
						Common.printString("TimerManager.otherTimerEventsProcess", 
								"loop count = "+timerEventPacket.getLoopCount());
						timerEventPacket.schedule();
						timerEventPacket.setTimeCount(0);
						int temp = timerEventPacket.getLoopCount();
						temp--;
						timerEventPacket.setLoopCount(temp);
					} 
				}
			}
			return true;
		} else {
			return false;
		}
	}
}
