/*************************************************************************
 **
 * File Name		ServerMain.java
 * File Summary		main of EVDCM servlet
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.utils.Common;

public class ServerMain extends HttpServlet {
	private static final int severPort = 12345;

	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		DBManager.getDbThread().start();
		new Timer().scheduleAtFixedRate(TimerManager.getTimeTask(), 0, DcmLocalParam.HEART_PERIOD);
		ThreadServer ss = new ThreadServer(severPort);
		if (ss != null && ss.getServerSocket() != null) {
			ConnectManager.serverIpPortsInit();
			ss.start();
		}

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * 验证用户
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<h1>" + "Server is running" + "</h1>");
	}
	
	public class ThreadServer extends Thread {
		ServerSocket mServerSocket = null;

		public ThreadServer(int port) {
			Common.printString("ServerMain.ThreadServer", "ThreadServer create ...");
			try {
				mServerSocket = new ServerSocket(port);
				Common.printString("ServerMain.ThreadServer", "ThreadServer create success!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public ServerSocket getServerSocket() {
			return mServerSocket;
		}

		public void run() {
			Socket sk;
			
			Common.printString("ServerMain.ThreadServer", "ThreadServer run ...");
			
			while (true) {
				if(Common.getServerShutDown()) {
					return;
				}
				try {
					sk = mServerSocket.accept();
					ConnectManager.ThreadRead thrd = new ConnectManager.ThreadRead(
							sk);
					if (thrd != null && thrd.getSocket() != null) {
						thrd.start();
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
