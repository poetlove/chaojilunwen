package tted.evdcm.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tted.evdcm.server.DBManager;
import tted.evdcm.server.struct.StatusData;



public class MoreInfor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
	}
       
    public MoreInfor() {
        super();
    
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String carnum= request.getParameter("carnum");
		
        //连接数据库，查询该车牌号对应的车载终端号和状态
		StatusData sd = new StatusData();
		sd.setCarNumber(carnum);
		ArrayList<StatusData> sds = DBManager.statusDataGet(null, sd);
		if(sds.size() > 0) {
			sd = sds.get(0);
			//发送查询结果到MoreInfor页面
			String status = null;
			int st = sd.getStatus();
			if((st | StatusData.MASK_ENERGIZED) == 0) {
				status = "断开";
			} else if((st | StatusData.MASK_POWER) == 0) {
				status = "电源异常";
			} else if((st | StatusData.MASK_COMMUNICATION) == 0) {
				status = "通信传输异常";
			} else if((st | StatusData.MASK_OTHERS) == 0) {
				status = "其他异常";
			} else {
				status = "一切正常";
			}
			request.setAttribute("status", status);		
			request.setAttribute("carnum", carnum);		
	    	request.getRequestDispatcher("MoreInfor.jsp").forward(request, response);
		} else {
			request.setAttribute("status", "---");		
			request.setAttribute("carnum", carnum);		
	    	request.getRequestDispatcher("MoreInfor.jsp").forward(request, response);
		}
		
	}
}
