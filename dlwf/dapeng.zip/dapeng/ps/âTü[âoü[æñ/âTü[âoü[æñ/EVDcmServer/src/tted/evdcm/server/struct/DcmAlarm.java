/*************************************************************************
 **
 * File Name		DcmAlarm.java
 * File Summary		DCMのアラ―ム情報
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayOutputStream;

import tted.evdcm.server.utils.DcmDataOutputStream;

public class DcmAlarm {
	/* DCMのアラ―ム情報:1級アラーム（最高） */
	static public final int DCM_ALARM_LEVEL_1 = 0x01;
	/* DCMのアラ―ム情報:2級アラーム */
	static public final int DCM_ALARM_LEVEL_2 = 0x02;
	/* DCMのアラ―ム情報:3級アラーム */
	static public final int DCM_ALARM_LEVEL_3 = 0x03;
	/* DCMのアラ―ム情報:4級アラーム */
	static public final int DCM_ALARM_LEVEL_4 = 0x04;
	/* DCMのアラ―ム情報:5級アラーム */
	static public final int DCM_ALARM_LEVEL_5 = 0x05;
	/* DCMのアラ―ム情報:無効データ */
	static public final int DCM_ALARM_INVALID = 0xFF;

	/* DCMコントロールのアラームレベル */
	int mAlarmLevel;

	public void setAlarmLevel(int lvl) {
		mAlarmLevel = lvl;
	}

	public int getAlarmLevel() {
		return mAlarmLevel;
	}

	/**
	 * DcmAlarm型のバックを配列のデータに変更
	 * 
	 * @param null
	 *           
	 * @return 操作が正確時配列のデータを返し、でなければnullを返し
	 */
	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			dataOutputStream.writeByte(mAlarmLevel);

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
