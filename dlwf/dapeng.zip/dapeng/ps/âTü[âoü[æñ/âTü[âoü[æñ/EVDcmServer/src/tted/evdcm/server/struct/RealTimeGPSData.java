/*************************************************************************
 **
 * File Name		RealTimeGPSData.java
 * File Summary		DCMからのリアルタイムGPSデータの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class RealTimeGPSData {
	/* GPSの状態ビットマスク：定位有効・無効 */
	public static final int MASK_POSITIONING = 0x01;
	/* GPSの状態ビットマスク：北緯・南緯 */
	public static final int MASK_LATITUDE = 0x02;
	/* GPSの状態ビットマスク：東経・西経 */
	public static final int MASK_LONGITUDE = 0x04;

	/* 車両ナンバー */
	String mCarNumber;
	/* データ採集時間 */
	String mDateTime;

	/* 情報タイプマーク */
	int mInfoTypeFlag = 0x04;

	/* 位置状態 */
	int mPositioningState;
	/* 経度 */
	int mLongitude;
	/* 緯度 */
	int mLatitude;
	/* スピード */
	int mSpeed;
	/* 方向 */
	int mDirection;
	/* リザーブ */
	byte[] mReserve;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getInfoTypeFlag() {
		return mInfoTypeFlag;
	}

	public void setPositioningState(int value) {
		mPositioningState = value;
	}

	public void setLongitude(int value) {
		mLongitude = value;
	}

	public void setLatitude(int value) {
		mLatitude = value;
	}

	public void setSpeed(int value) {
		mSpeed = value;
	}

	public void setDirection(int value) {
		mDirection = value;
	}

	public int getPositioningState() {
		return mPositioningState;
	}

	public int getLongitude() {
		return mLongitude;
	}

	public int getLatitude() {
		return mLatitude;
	}

	public int getSpeed() {
		return mSpeed;
	}

	public int getDirection() {
		return mDirection;
	}

	/**
	 * 配列のデータをRealTimeGPSData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param dateTime
	 *            データの採取時間.
	 * @param byteStream
	 *            含むRealTimeGPSData情報の配列.
	 * @param offset
	 *            byteStream配列の位置ずれ.
	 * @return 配列操作が正確時RealTimeGPSData実例を返し、でなければnullを返し
	 */
	static public RealTimeGPSData fromBytesToPacket(String carNumber,
			String dateTime, byte[] byteStream, int offset) {
		RealTimeGPSData rtgpsd = new RealTimeGPSData();

		rtgpsd.mCarNumber = carNumber;
		rtgpsd.mDateTime = dateTime;

		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			rtgpsd.mDateTime = Common.strFromBytes(dt);

			dataInputStream.skipBytes(offset);
			rtgpsd.mInfoTypeFlag = Common.byteToInt(dataInputStream.readByte());

			rtgpsd.mPositioningState = Common.byteToInt(dataInputStream.readByte());
			rtgpsd.mLongitude = dataInputStream.readInt();
			rtgpsd.mLatitude = dataInputStream.readInt();
			rtgpsd.mSpeed = dataInputStream.readShort();
			rtgpsd.mDirection = dataInputStream.readShort();

			return rtgpsd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * RealTimeGPSData型のバックは使ったバイト数を計算
	 * 
	 * @param null
	 *            
	 * @return RealTimeGPSData型のバックは使ったバイト数
	 */
	public static int getDataInfoStructLength() {
		int len = 1 + 1 + 4 + 4 + 2 + 2 + 4;
		return len;
	}

}
