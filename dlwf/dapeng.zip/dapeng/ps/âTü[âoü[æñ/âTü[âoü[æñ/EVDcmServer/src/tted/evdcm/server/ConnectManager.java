/*************************************************************************
 **
 * File Name		ConnectManager.java
 * File Summary		DCMからデータの受信とDCMにサーバーのデータの送信
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;

import tted.evdcm.server.struct.ServerIpPort;
import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class ConnectManager {
	/**
	 * サーバーと接続のDCMの最大数
	 */
	static public final int MAX_CONNECTION_COUNT = 500;

	/**
	 * 他のサーバーのipとportのリスト
	 */
	static ArrayList<ServerIpPort> mServerIpPorts = new ArrayList<ServerIpPort>();
	/**
	 * ipとportのリストの位置
	 */
	static int mIndex = 0;

	/**
	 * 他のサーバーのipとportのリストを初期化.
	 * 
	 * @param null
	 * 
	 * @return null
	 */
	static public void serverIpPortsInit() {
		ServerIpPort sip = new ServerIpPort();
		sip.setServerIp("0.0.192.168.10.3");
		sip.setServerPort(10000);
		mServerIpPorts.add(sip);

	}

	/**
	 * リストから1つのipとportを獲得.
	 * 
	 * @param null
	 * 
	 * @return ipとportの実例
	 */
	static public ServerIpPort serverIpPortGet() {
		mIndex++;
		if (mIndex >= mServerIpPorts.size()) {
			mIndex = 0;
		}
		return mServerIpPorts.get(mIndex);
	}

	public static class ThreadRead extends Thread {
		/* DCMとサーバーの接続のソケット実例 */
		Socket mSocket = null;
		/* DCMからのデータの入力ストリーム */
		InputStream mRead = null;

		/**
		 * 読みスレッドを創建し、初期化.
		 * 
		 * @param sk
		 *            ソケットの実例.
		 * @return null
		 */
		public ThreadRead(Socket sk) {
			Common.printString("ConnectManager.ThreadRead", "ThreadRead create ...");
			try {
				mRead = sk.getInputStream();
				mSocket = sk;
				Common.printString("ConnectManager.ThreadRead", "ThreadRead create success!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		/**
		 * この読みスレッドのSocket実例を獲得.
		 * 
		 * @param null
		 * 
		 * @return Socket実例を返し
		 */
		public Socket getSocket() {
			return mSocket;
		}

		/**
		 * この読みスレッドを運行.
		 * 
		 * @param null
		 * 
		 * @return null
		 */
		public void run() {
			Common.printString("ConnectManager.ThreadRead", "ThreadRead running ...");
			try {
				int startFlag = '#';
				int startFlagCnt = 2;
				int headerCnt = 24;
				byte[] bfh = new byte[headerCnt];

				while (true) {
					if (Common.getServerShutDown()) {
						ConnectManager.withDcmSocketClose(mSocket);
						return;
					}

					Common.zeroMemory(bfh);

					boolean isGetStart = false;
					while (true) {
						int a = mRead.read();
						if (a == -1) {
							ConnectManager.withDcmSocketClose(mSocket);
							return;
						} else if (a == startFlag) {
							if (!isGetStart) {
								isGetStart = true;
							} else {
								bfh[0] = Common.intToByte(startFlag);
								bfh[1] = Common.intToByte(startFlag);
								break;
							}
						} else {
							isGetStart = false;
						}
					}

					int sum = startFlagCnt;
					while (sum < headerCnt) {
						int rt = mRead.read(bfh, sum, headerCnt - sum);
						if (rt == -1) {
							ConnectManager.withDcmSocketClose(mSocket);
							return;
						} else {
							sum += rt;
						}
					}

					int size = 0;
					DcmDataInputStream dataInputStream = new DcmDataInputStream(
							new ByteArrayInputStream(bfh));
					try {
						dataInputStream.skipBytes(headerCnt - 2);
						size = dataInputStream.readUnsignedShort();
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						try {
							dataInputStream.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

					byte[] bf = new byte[headerCnt + size + 1];
					while (sum < bf.length) {
						int rt = mRead.read(bf, sum, bf.length - sum);
						if (rt == -1) {
							ConnectManager.withDcmSocketClose(mSocket);
							return;
						} else {
							sum += rt;
						}
					}

					Common.memcpy(bf, 0, bfh, 0, headerCnt);

					DcmManager.fromDcmDataPacketProcess(mSocket, bf);
//					toDcmDataPacketSend(mSocket,bf);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	/**
	 * サーバーからのデータをDCMに送信.
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @param sdData
	 *            配信のデート.
	 * @return データの送信が正確時trueを返し、でなければfalseを返し
	 */
	static public boolean toDcmDataPacketSend(Socket sk, byte[] sdData) {
		OutputStream wt;
		try {
			wt = sk.getOutputStream();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return false;
		}

		try {
			wt.write(sdData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * DCMとの接続をクロース.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param sk
	 *            ソケットの実例.
	 * @return 接続のクロース時trueを返し、でなければfalseを返し
	 */
	static public boolean withDcmSocketClose(String carNumber, Socket sock) {
		Socket sk;
		if (sock != null) {
			sk = sock;
		} else {
			sk = DataManager.getSocketByString(carNumber);
		}

		if (sk != null) {
			try {
				sk.close();
				return true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}
		// DcmLocalParam dlp = DataManager.getDcmLocalParamByString(carNumber);
		// if(dlp != null) {
		// if(dlp.getDcmStatusChange() != null) {
		// dlp.getDcmStatusChange().callOutLine();
		// }
		// DataManager.deleteDcmLocalParamInList(carNumber);
		// }

		return false;
	}

	/**
	 * DCMとの接続をクロース.
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @return 接続のクロース時trueを返し、でなければfalseを返し
	 */
	static public boolean withDcmSocketClose(String carNumber) {
		return withDcmSocketClose(carNumber, null);
	}

	/**
	 * DCMとの接続をクロース.
	 * 
	 * @param sk
	 *            ソケットの実例.
	 * @return 接続のクロース時trueを返し、でなければfalseを返し
	 */
	static public boolean withDcmSocketClose(Socket sock) {
		return withDcmSocketClose(null, sock);
	}

}
