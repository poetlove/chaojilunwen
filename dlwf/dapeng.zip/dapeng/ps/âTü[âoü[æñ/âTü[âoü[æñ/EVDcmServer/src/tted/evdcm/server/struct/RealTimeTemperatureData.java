/*************************************************************************
 **
 * File Name		RealTimeTemperatureData.java
 * File Summary		DCMからのリアルタイム温度データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class RealTimeTemperatureData {
	/* 車両ナンバー */
	String mCarNumber;
	/* データ採集時間 */
	String mDateTime;

	/* 情報タイプマーク */
	int mInfoTypeFlag = 0x02;

	/* 動力バッテリーバッグ温度プローブ数 */
	int mTemperatureProbeCnt;
	/* 動力バッテリーパック数N */
	int mBatteryPackCount;
	/* 動力バッテリー温度バック表 */
	ArrayList<TemperaturePacket> mTemperaturePackets;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getInfoTypeFlag() {
		return mInfoTypeFlag;
	}

	public void setTemperatureProbeCnt(int cnt) {
		mTemperatureProbeCnt = cnt;
	}

	public int getTemperatureProbeCnt() {
		return mTemperatureProbeCnt;
	}

	public void setBatteryPackCount(int cnt) {
		mBatteryPackCount = cnt;
	}

	public int getBatteryPackCount() {
		return mBatteryPackCount;
	}

	public void setTemperaturePackets(ArrayList<TemperaturePacket> pkts) {
		mTemperaturePackets = pkts;
	}

	public ArrayList<TemperaturePacket> getTemperaturePackets() {
		return mTemperaturePackets;
	}

	/**
	 * 配列のデータをRealTimeTemperatureData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param dateTime
	 *            データの採取時間.
	 * @param byteStream
	 *            含むRealTimeTemperatureData情報の配列.
	 * @param offset
	 *            byteStream配列の位置ずれ.
	 * @return 配列操作が正確時RealTimeTemperatureData実例を返し、でなければnullを返し
	 */
	static public RealTimeTemperatureData fromBytesToPacket(String carNumber,
			String dateTime, byte[] byteStream, int offset) {
		RealTimeTemperatureData rttd = new RealTimeTemperatureData();

		rttd.mCarNumber = carNumber;
		rttd.mDateTime = dateTime;

		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			dataInputStream.skipBytes(offset);
			rttd.mInfoTypeFlag = Common.byteToInt(dataInputStream.readByte());

			rttd.mTemperatureProbeCnt = dataInputStream.readShort();
			rttd.mBatteryPackCount = Common.byteToInt(dataInputStream.readByte());

			if (rttd.mBatteryPackCount > 0) {
				rttd.mTemperaturePackets = new ArrayList<TemperaturePacket>();
				for (int i = 0; i < rttd.mBatteryPackCount; i++) {
					TemperaturePacket tp = new TemperaturePacket();
					tp.setBatteryPacketSequence(Common.byteToInt(dataInputStream.readByte()));
					tp.setTemperatureProbeCount(Common.byteToInt(dataInputStream.readByte()));
					if (tp.getTemperatureProbeCount() > 0) {
						ArrayList<Integer> ai = new ArrayList<Integer>();
						for (int j = 0; j < tp.getTemperatureProbeCount(); j++) {
							ai.add((int) dataInputStream.readShort());
						}
						tp.setTemperatureValues(ai);
					} else {
						tp.setTemperatureValues(null);
					}

					rttd.mTemperaturePackets.add(tp);
				}
			} else {
				rttd.mTemperaturePackets = null;
			}

			return rttd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * RealTimeTemperatureData型のバックは使ったバイト数を計算
	 * 
	 * @param null
	 *            
	 * @return RealTimeTemperatureData型のバックは使ったバイト数
	 */
	public int getDataInfoStructLength() {
		int len = 1 + 2 + 1;

		if (mBatteryPackCount > 0) {
			for (int i = 0; i < mBatteryPackCount; i++) {
				TemperaturePacket tp = mTemperaturePackets.get(i);
				len += 2;
				len += tp.getTemperatureProbeCount();
			}
		}

		return len;
	}

}
