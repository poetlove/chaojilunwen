/*************************************************************************
 **
 * File Name		RealTimeVehicleData.java
 * File Summary		DCMからのリアルタイム車両データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/

package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;

public class RealTimeVehicleData {
	/* ギアのマスク：档位 */
	public static final int MASK_GEAR = 0x0f;
	/* ギアのマスク：制動 */
	public static final int MASK_BRAKE = 0x10;
	/* ギアのマスク：駆動 */
	public static final int MASK_DRIVE = 0x20;

	/* 档位:ニュートラル */
	public static final int GEAR_NONE = 0x00;
	/* 档位:ローギア */
	public static final int GEAR_1 = 0x01;
	/* 档位:セカンドギア */
	public static final int GEAR_2 = 0x02;
	/* 档位:サードギア */
	public static final int GEAR_3 = 0x03;
	/* 档位:フォースギア */
	public static final int GEAR_4 = 0x04;
	/* 档位:第5のギア */
	public static final int GEAR_5 = 0x05;
	/* 档位:第6のギア */
	public static final int GEAR_6 = 0x06;
	/* 档位:後退ギア */
	public static final int GEAR_REVERSE = 0x0e;
	/* 档位:ドライブ */
	public static final int GEAR_AUTO = 0x0f;

	/* 車両ナンバー */
	String mCarNumber;
	/* データ採集時間 */
	String mDateTime;

	/* 情報タイプマーク */
	int mInfoTypeFlag = 0x03;

	/* スピード */
	int mSpeed;
	/* マイレージ */
	int mMileage;
	/* ギヤ */
	int mGear;
	/* 加速ペダルストローク値 */
	int mAcceleratedPedalTrip;
	/* ブレーキペダルストローク値 */
	int mBrakePedalTrip;
	/* 充放電状態 */
	int mChargeStatus;
	/* モータコントローラ温度 */
	int mMotorCntlTemperature;
	/* モータ回転 */
	int mMotorSpeed;
	/* モータ温度 */
	int mMotorTemperature;
	/* モータ電圧 */
	int mMotorVoltage;
	/* モータ電流 */
	int mMotorCurrent;
	/* エアコンの設定温度 */
	int mAirConditionTemperature;
	/* リザーブ */
	byte[] mReserve;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public int getInfoTypeFlag() {
		return mInfoTypeFlag;
	}

	public void setSpeed(int value) {
		mSpeed = value;
	}

	public void setMileage(int value) {
		mMileage = value;
	}

	public void setGear(int value) {
		mGear = value;
	}

	public void setAcceleratedPedalTrip(int value) {
		mAcceleratedPedalTrip = value;
	}

	public void setBrakePedalTrip(int value) {
		mBrakePedalTrip = value;
	}

	public void setChargeStatus(int value) {
		mChargeStatus = value;
	}

	public void setMotorCntlTemperature(int value) {
		mMotorCntlTemperature = value;
	}

	public void setMotorSpeed(int value) {
		mMotorSpeed = value;
	}

	public void setMotorTemperature(int value) {
		mMotorTemperature = value;
	}

	public void setMotorVoltage(int value) {
		mMotorVoltage = value;
	}

	public void setMotorCurrent(int value) {
		mMotorCurrent = value;
	}

	public void setAirConditionTemperature(int value) {
		mAirConditionTemperature = value;
	}

	public int getSpeed() {
		return mSpeed;
	}

	public int getMileage() {
		return mMileage;
	}

	public int getGear() {
		return mGear;
	}

	public int getAcceleratedPedalTrip() {
		return mAcceleratedPedalTrip;
	}

	public int getBrakePedalTrip() {
		return mBrakePedalTrip;
	}

	public int getChargeStatus() {
		return mChargeStatus;
	}

	public int getMotorCntlTemperature() {
		return mMotorCntlTemperature;
	}

	public int getMotorSpeed() {
		return mMotorSpeed;
	}

	public int getMotorTemperature() {
		return mMotorTemperature;
	}

	public int getMotorVoltage() {
		return mMotorVoltage;
	}

	public int getMotorCurrent() {
		return mMotorCurrent;
	}

	public int getAirConditionTemperature() {
		return mAirConditionTemperature;
	}

	/**
	 * 配列のデータをRealTimeVehicleData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param dateTime
	 *            データの採取時間.
	 * @param byteStream
	 *            含むRealTimeVehicleData情報の配列.
	 * @param offset
	 *            byteStream配列の位置ずれ.
	 * @return 配列操作が正確時RealTimeVehicleData実例を返し、でなければnullを返し
	 */
	static public RealTimeVehicleData fromBytesToPacket(String carNumber, String dateTime,
			byte[] byteStream, int offset) {
		RealTimeVehicleData rtvd = new RealTimeVehicleData();

		rtvd.mCarNumber = carNumber;
		rtvd.mDateTime = dateTime;

		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			dataInputStream.skipBytes(offset);
			rtvd.mInfoTypeFlag = Common.byteToInt(dataInputStream.readByte());

			rtvd.mSpeed = dataInputStream.readShort();
			rtvd.mMileage = dataInputStream.readInt();
			rtvd.mGear = Common.byteToInt(dataInputStream.readByte());
			rtvd.mAcceleratedPedalTrip = Common.byteToInt(dataInputStream.readByte());
			rtvd.mBrakePedalTrip = Common.byteToInt(dataInputStream.readByte());
			rtvd.mChargeStatus = Common.byteToInt(dataInputStream.readByte());
			rtvd.mMotorCntlTemperature = Common.byteToInt(dataInputStream.readByte());
			rtvd.mMotorSpeed = dataInputStream.readShort();
			rtvd.mMotorTemperature = Common.byteToInt(dataInputStream.readByte());
			rtvd.mMotorVoltage = dataInputStream.readShort();
			rtvd.mMotorCurrent = dataInputStream.readShort();
			rtvd.mAirConditionTemperature = Common.byteToInt(dataInputStream.readByte());
			return rtvd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * RealTimeVehicleData型のバックは使ったバイト数を計算
	 * 
	 * @param null
	 *            
	 * @return RealTimeVehicleData型のバックは使ったバイト数
	 */
	public static int getDataInfoStructLength() {
		int len = 1 + 2 + 4 + 1 + 1 + 1 + 1 + 1 + 2 + 1 + 2 + 2 + 1 + 7;
		return len;
	}

}
