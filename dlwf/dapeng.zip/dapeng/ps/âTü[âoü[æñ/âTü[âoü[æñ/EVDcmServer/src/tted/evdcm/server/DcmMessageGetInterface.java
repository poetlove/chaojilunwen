/*************************************************************************
 **
 * File Name		ServerInterface.java
 * File Summary		DCMのパラメータの検索時、サーバーからユーザーに情報を送信することのインタフィース
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import tted.evdcm.server.struct.DcmParamData;

public interface DcmMessageGetInterface {
	// 当用户查看DCM参数时，DCM将参数信息返回给服务器，服务器使用此接口通知客户端
	public void callSuccessFunc(DcmParamData pqd);
	public void callErrorFunc(String e);
}
