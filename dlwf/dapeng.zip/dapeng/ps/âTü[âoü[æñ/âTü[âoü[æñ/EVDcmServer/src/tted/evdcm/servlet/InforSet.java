package tted.evdcm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tted.evdcm.server.DataManager;
import tted.evdcm.server.DcmManager;
import tted.evdcm.server.DcmMessageGetInterface;
import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.DcmParam;
import tted.evdcm.server.struct.DcmParamData;
import tted.evdcm.server.struct.ParamItem;

public class InforSet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int IDLE = 0;
	private static final int WAITING = 1;
	private static final int SUCCESS = 2;
	private static final int FAIL = 3;
	/**
	 * idle waiting completed, success completed, fail
	 */
	private int status = IDLE;
	
	private String localSet = "false";

	private String errMsg = null;
	private String carNumber = null;
	private Data datas = null;
	
	class Data {
		 int storageTime = -1;
		 int normalTime = -1;
		 int alarmTime = -1;
		 String ip = null;
		 int port = -1;
		 String hardwareVersion = null;
		 String firmwareVersion = null;
		 int heartBeat = -1;
		 int terminal = -1;
		 int platform = -1;
	}

	

	private void initData() {
		datas = null;
		errMsg = null;
		carNumber = null;
	}

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InforSet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		String set = request.getParameter("set");
		if(!localSet.equals(set)) {
			localSet = set;
			status = IDLE;
		}
		
		if (datas != null && set.equals("false")) {
			successProcess(request,response);
		} else if (status == IDLE) {
			initData();
			String flag = request.getParameter("flag");
			carNumber = request.getParameter("carnum");
			if (flag == null || flag == "") {
				carNumber = new String(carNumber.getBytes("ISO-8859-1"),
						"UTF-8");
			}
			if (set.equals("false")) {
				DcmParam dp = new DcmParam();
				dp.setCarNumber(carNumber);
				SimpleDateFormat df = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				dp.setDateTime(df.format(new Date()));

				dp.setBoolDcmStoragePeriod(DcmParam.CMD_QUERY);
				dp.setBoolDcmInfoReportPeriod(DcmParam.CMD_QUERY);
				dp.setBoolDcmAlarmInfoReportPeriod(DcmParam.CMD_QUERY);
				dp.setBoolIntegratedPlatformIP(DcmParam.CMD_QUERY);
				dp.setBoolIntegratedPlatformPort(DcmParam.CMD_QUERY);
				dp.setBoolDcmHardwareVersion(DcmParam.CMD_QUERY);
				dp.setBoolDcmFirmwareVersion(DcmParam.CMD_QUERY);
				dp.setBoolDcmHeartPeriod(DcmParam.CMD_QUERY);
				dp.setBoolDcmResponseTime(DcmParam.CMD_QUERY);
				dp.setBoolServerResponseTime(DcmParam.CMD_QUERY);

				status = WAITING;
				if (!DcmManager.dcmParamDataGet(dp, dmgi)) {
					status = FAIL;
					request.setAttribute("message", "Parameter set error!!!");
					try {
						request.getRequestDispatcher("ErrorPage.jsp").forward(
								request, response);
					} catch (ServletException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					status = IDLE;
				}
			} else {
//				storageTime = Integer.valueOf(request
//						.getParameter("storagetime"));
//				normalTime = Integer
//						.valueOf(request.getParameter("normaltime"));
//				alarmTime = Integer.valueOf(request.getParameter("alarmtime"));
//				heartBeat = Integer.valueOf(request.getParameter("heartbeat"));
//				terminal = Integer.valueOf(request.getParameter("terminal"));
//				platform = Integer.valueOf(request.getParameter(" platform"));
			}

			waitProcess(request, response);
		} else if (status == WAITING) {
			waitProcess(request, response);
		} else if (status == FAIL) {
			request.setAttribute("message", errMsg);
			try {
				request.getRequestDispatcher("ErrorPage.jsp").forward(request,
						response);

			} catch (ServletException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			status = IDLE;
		} else if (status == SUCCESS) {
			successProcess(request,response);
		}
	}

	private void successProcess(HttpServletRequest request,
	HttpServletResponse response) {
		request.setAttribute("carnum", carNumber);

		request.setAttribute("storagetime", datas.storageTime + "");
		request.setAttribute("normaltime", datas.normalTime + "");
		request.setAttribute("alarmtime", datas.alarmTime + "");
		request.setAttribute("IP", datas.ip);
		request.setAttribute("port", datas.port + "");
		request.setAttribute("hardwareVersion", datas.hardwareVersion);
		request.setAttribute("firmwareVersion", datas.firmwareVersion);
		request.setAttribute("heartbeat", datas.heartBeat + "");
		request.setAttribute("terminal", datas.terminal + "");
		request.setAttribute("platform", datas.platform + "");

		try {
			request.getRequestDispatcher("InforSet.jsp").forward(request,
					response);
		} catch (ServletException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		status = IDLE;
	}
	
	private void waitProcess(HttpServletRequest request,
			HttpServletResponse response) {
		response.setIntHeader("Refresh", 1);
		// Set response content type
		response.setContentType("text/html");
		PrintWriter out;
		try {
			out = response.getWriter();
			String title = "waiting...";
			String docType = "<!doctype html public \"-//w3c//dtd html 4.0 "
					+ "transitional//en\">\n";
			out.println(docType + "<html>\n" + "<head><title>" + title
					+ "</title></head>\n" + "<body bgcolor=\"#f0f0f0\">\n"
					+ "<h1 align=\"center\">" + title + "</h1>\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private DcmMessageGetInterface dmgi = new DcmMessageGetInterface() {

		@Override
		public void callSuccessFunc(DcmParamData pqd) {
			// TODO Auto-generated method stub
			int cnt = pqd.getCount();
			if (pqd.getParamItems().size() != cnt) {
				status = FAIL;
				errMsg = "Data from Dcm error!!!";
				return;
			}

			ArrayList<ParamItem> pis = pqd.getParamItems();
			for (int i = 0; i < cnt; i++) {
				ParamItem pi = pis.get(i);

				if(datas == null) {
					datas = new Data();
				}
				int cmdId = pi.getParamId();
				if (cmdId == DcmParam.PID_DCM_STORE_PERI) {
					datas.storageTime = pi.getParamInt();
				} else if (cmdId == DcmParam.PID_DCM_INFO_REP_PERI) {
					datas.normalTime = pi.getParamInt();
				} else if (cmdId == DcmParam.PID_ALARM_INFO_REP_PERI) {
					datas.alarmTime = pi.getParamInt();
				} else if (cmdId == DcmParam.PID_PLATFORM_IP) {
					datas.ip = pi.getParamString();
				} else if (cmdId == DcmParam.PID_PLATFORM_PORT) {
					datas.port = pi.getParamInt();
				} else if (cmdId == DcmParam.PID_DCM_HW_VERSION) {
					datas.hardwareVersion = pi.getParamString();
				} else if (cmdId == DcmParam.PID_DCM_FW_VERSION) {
					datas.firmwareVersion = pi.getParamString();
				} else if (cmdId == DcmParam.PID_DCM_HEART_PERI) {
					datas.heartBeat = pi.getParamInt();
				} else if (cmdId == DcmParam.PID_DCM_RESPONE_TIME) {
					datas.terminal = pi.getParamInt();
				} else if (cmdId == DcmParam.PID_SERVER_RESPONE_TIME) {
					datas.platform = pi.getParamInt();
				}
			}
			if(datas.heartBeat == -1 || datas.terminal == -1) {
				DcmLocalParam dlp = DataManager.getDcmLocalParamByString(carNumber);
				if (dlp != null) {
					if(datas.heartBeat == -1) {
						datas.heartBeat = dlp.getHeartPeriod();
					}
					if(datas.terminal == -1) {
						datas.terminal = dlp.getDcmResponseTime();
					}
				}
			}
			
			status = SUCCESS;
		}

		@Override
		public void callErrorFunc(String e) {
			// TODO Auto-generated method stub
			status = FAIL;
			errMsg = e;
		}

	};

}
