package tted.evdcm.javabean;

public class CarStatusShowRecord {
	
	StringBuffer presentPageResult; 
	public void setPresentPageResult(StringBuffer p)
	{
		presentPageResult = p;
	}
	public StringBuffer getPresentPageResult()
	{
		return presentPageResult;
	}

}
