/*************************************************************************
 **
 * File Name		VoltagePacket.java
 * File Summary		DCMからの電池電圧データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.util.ArrayList;

public class VoltagePacket {
	/* 動力バッテリーパック番号 */
	int mBatteryPacketSequence;
	/* このバッグ単体バッテリー数 */
	int mBatteryCount;
	/* 単体バッテリー電圧値 */
	ArrayList<Integer> mVoltageValues;

	public void setBatteryPacketSequence(int value) {
		mBatteryPacketSequence = value;
	}

	public void setBatteryCount(int value) {
		mBatteryCount = value;
	}

	public void setVoltageValues(ArrayList<Integer> value) {
		mVoltageValues = value;
	}

	public int getBatteryPacketSequence() {
		return mBatteryPacketSequence;
	}

	public int getBatteryCount() {
		return mBatteryCount;
	}

	public ArrayList<Integer> getVoltageValues() {
		return mVoltageValues;
	}

}
