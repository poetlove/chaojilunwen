/*************************************************************************
 **
 * File Name		DcmLocalParam.java
 * File Summary		DCMのパラメータデータはサーバー側に保存したローカルバージョン
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import tted.evdcm.server.DcmStatusChangeInterface;

public class DcmLocalParam {
	/* サーバー側毎秒で統計のハードの回数 */
	public static final int HEART_HZ = 10;
	/* ミリ秒単位で、サーバー側統計のハードの周期時間 */
	public static final int HEART_PERIOD = 100;
	
	/* DCM応答のタイムアウト時間 */
	int mDcmResponseTime; // 单位是秒 终端应答超时时间
	/* DCM心拍送信週期 */
	int mHeartPeriod; // 单位是秒  车载终端心跳发送周期
	/* 0.１秒単位で、前の心拍送信から現在までサーバーの経過の時間 */
	int mServerHeartCount; // 单位是0.1秒 从上一次心跳到达当前的时间
	
	/* リアルタイムデータの最新の時間 */
	String mRealTimeUpdateTime; // 实时更新数据的时间
	/* リアルタイムの情報ID */
	long mRealTimeInfoId; // 实时信息id
	
	/* 車両識別コード */
	String mVin;
	
	/* サーバーとDCMの接続状態変更時調達のインタフェース */
	DcmStatusChangeInterface mDcmStatusChange;

	public void setDcmResponseTime(int time) {
		mDcmResponseTime = time;
	}
	public int getDcmResponseTime() {
		return mDcmResponseTime;
	}
	public void setHeartPeriod(int period) {
		mHeartPeriod = period;
	}
	public int getHeartPeriod() {
		return mHeartPeriod;
	}
	public void setServerHeartCount(int cnt) {
		mServerHeartCount = cnt;
	}
	public int getServerHeartCount() {
		return mServerHeartCount;
	}
	
	public void setRealTimeUpdateTime(String rtdt) {
		mRealTimeUpdateTime = rtdt;
	}
	public String getRealTimeUpdateTime() {
		return mRealTimeUpdateTime;
	}
	public void setRealTimeInfoId(long id) {
		mRealTimeInfoId = id;
	}
	public long getRealTimeInfoId() {
		return mRealTimeInfoId;
	}
	public void setVin(String v) {
		mVin = v;
	}
	public String getVin() {
		return mVin;
	}
	public void setDcmStatusChange(DcmStatusChangeInterface dsci) {
		mDcmStatusChange = dsci;
	}
	public DcmStatusChangeInterface getDcmStatusChange() {
		return mDcmStatusChange;
	}
	
	/**
	 * サーバー側に保存したローカルパラメータの初期化
	 * 
	 * @param null
	 *           
	 * @return null
	 */
	public void init() {
		mDcmResponseTime = 10;
		mHeartPeriod = 1000;
		mServerHeartCount = 0;
		mRealTimeUpdateTime = null;
		mRealTimeInfoId = 0;
		mVin = null;
		mDcmStatusChange = null;
	}

}
