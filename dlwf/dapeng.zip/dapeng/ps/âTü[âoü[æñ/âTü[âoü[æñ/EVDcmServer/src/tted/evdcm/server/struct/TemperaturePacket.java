/*************************************************************************
 **
 * File Name		TemperaturePacket.java
 * File Summary		DCMからの電池温度データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.util.ArrayList;

public class TemperaturePacket {
	/* 動力バッテリーパック番号 */
	int mBatteryPacketSequence;
	/* このバッグ動力バッテリー温度プローブ数 */
	int mTemperatureProbeCount;
	/* プローブ温度値 */
	ArrayList<Integer> mTemperatureValues;

	public void setBatteryPacketSequence(int value) {
		mBatteryPacketSequence = value;
	}

	public void setTemperatureProbeCount(int value) {
		mTemperatureProbeCount = value;
	}

	public void setTemperatureValues(ArrayList<Integer> value) {
		mTemperatureValues = value;
	}

	public int getBatteryPacketSequence() {
		return mBatteryPacketSequence;
	}

	public int getTemperatureProbeCount() {
		return mTemperatureProbeCount;
	}

	public ArrayList<Integer> getTemperatureValues() {
		return mTemperatureValues;
	}

}
