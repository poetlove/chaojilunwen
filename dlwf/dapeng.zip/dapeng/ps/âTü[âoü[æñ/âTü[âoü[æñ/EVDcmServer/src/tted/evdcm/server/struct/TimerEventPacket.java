/*************************************************************************
 **
 * File Name		TimerEventPacket.java
 * File Summary		サーバー側定時タスクデータの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import tted.evdcm.server.DcmMessageGetInterface;
import tted.evdcm.server.utils.Common;

public class TimerEventPacket {
	/* 車両ナンバー */
	String mCarNumber;
	/* 当面の時計カウント値、この数値の単位は0.1秒 */
	int mTimeCount; // 以0.1s为单位
	/* mTimeCount >= mMaxPeriod 時はタイムアウトで、この数値の単位は0.1秒 */
	int mMaxPeriod;
	/* タイムアウトの回数 */
	int mLoopCount;
	/* タイムアウト時運行のスレッド */
	Thread mThread;
	/* この定時タスクデータパックの削除前執行のインタフェース */
	DcmMessageGetInterface mDcmMessageProcInterface;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}
	public String getCarNumber() {
		return mCarNumber;
	}
	public void setTimeCount(int cnt) {
		mTimeCount = cnt;
	}
	public int getTimeCount() {
		return mTimeCount;
	}
	public void setLoopCount(int cnt) {
		mLoopCount = cnt;
	}
	public int getLoopCount() {
		return mLoopCount;
	}
	public void setMaxPeriod(int period) {
		mMaxPeriod = period;
	}
	public int getMaxPeriod() {
		return mMaxPeriod;
	}
	
	public void setThread(Thread th) {
		mThread = th;
	}
	public void setDcmMessageProcInterface(DcmMessageGetInterface sif) {
		mDcmMessageProcInterface = sif;
	}
	public DcmMessageGetInterface getDcmMessageProcInterface() {
		return mDcmMessageProcInterface;
	}
	
	/**
	 * 定時タスクの週期性調達関数
	 * 
	 * @param null
	 *          
	 * @return null
	 */
	public void schedule() {
		if(mThread != null) {
			try {
				new Thread(mThread).start();
				Common.printString("TimerEventPacket.schedule", "new thread start !!!!");
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

}
