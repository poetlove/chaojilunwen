/*************************************************************************
 **
 * File Name		ServerIpPort.java
 * File Summary		サーバーのipとport番号を保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

public class ServerIpPort {
	/* サーバーのipアドレス */
	String mServerIp;
	/* サーバーのport番号 */
	int mServerPort;
	
	public void setServerIp(String ip) {
		mServerIp = ip;
	}
	public void setServerPort(int port) {
		mServerPort = port;
	}
	public String getServerIp() {
		return mServerIp;
	}
	public int getServerPort() {
		return mServerPort;
	}

}
