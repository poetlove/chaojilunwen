package tted.evdcm.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tted.evdcm.javabean.CarInforShowRecord;
import tted.evdcm.server.DBManager;
import tted.evdcm.server.DataManager;
import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.RegistData;

public class CarInfoList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CarInfoList() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response) 连接数据库，并根据条件显示在CarinforList.jsp的页面上
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		StringBuffer presentPageResult = new StringBuffer();
		CarInforShowRecord databaseBean = null;
		HttpSession session = request.getSession(true);

		/**
		 * 创建javabean对象
		 */
		try {
			databaseBean = (CarInforShowRecord) session
					.getAttribute("database");
			if (databaseBean == null) {
				databaseBean = new CarInforShowRecord();
				session.setAttribute("database", databaseBean);
			}
		} catch (Exception exp) {
			databaseBean = new CarInforShowRecord();
			session.setAttribute("database", databaseBean);
		}

		int showPage = databaseBean.getShowPage(); // 获取javabean中存放的当前显示页
		int pageSize = databaseBean.getPageSize(); // 获取javabean中存放的每页显示记录数

		ArrayList<RegistData> rds = DBManager.registDataGet(null, null);
		
		databaseBean.setRowSet(rds); // 数据存储在databaseBean中
		int m = rds.size(); // 获得总行数
		int n = pageSize;
		int pageAllCount = ((m % n) == 0) ? (m / n) : (m / n + 1); // 计算分页后总页数
		databaseBean.setPageAllCount(pageAllCount); // 数据存储在javabean中

		/**
		 * 获取页面提交信息，控制跳转页面
		 */
		String whichPage = request.getParameter("whichPage"); // 获取上一页下一页
		String toPage = request.getParameter("ToPage"); // 获取要跳转到的指定页数

		// 跳转页面
		if (toPage != null) {
			showPage = Integer.parseInt(toPage); // 取得指定显示的分页页数
			databaseBean.setShowPage(showPage); // 存入javabean

			// 下面的语句判断用户输入的页数是否正确
			if (rds != null) {
				if (showPage >= databaseBean.getPageAllCount()) {
					showPage = databaseBean.getPageAllCount();
					databaseBean.setShowPage(showPage);
				} else if (showPage <= 0) {
					showPage = 1;
					databaseBean.setShowPage(showPage);
				}
				presentPageResult = show(showPage, pageSize, rds);
				databaseBean.setPresentPageResult(presentPageResult);
			}
		}

		// 处理上一页和下一页
		if (whichPage == null || whichPage.length() == 0) {
			showPage = 1;
			databaseBean.setShowPage(showPage);

		} else if (whichPage.equals("nextPage")) {
			showPage++;
			if (showPage > databaseBean.getPageAllCount())
				showPage = 1;
			databaseBean.setShowPage(showPage);

		} else if (whichPage.equals("previousPage")) {
			showPage--;
			if (showPage <= 0)
				showPage = databaseBean.getPageAllCount();
			databaseBean.setShowPage(showPage);
			
		}
		if (rds != null) {
			presentPageResult = show(showPage, pageSize, rds);
		}
		
		databaseBean.setPresentPageResult(presentPageResult);

		// 请求Carinfor显示数据
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("CarinforList.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * 根据传入的参数显示数据
	 */
	public StringBuffer show(int page, int pageSize, ArrayList<RegistData> rds) {
		StringBuffer str = new StringBuffer();

		int idx = (page - 1) * pageSize; // 计算每页起始记录位置
		int allCnt = rds.size();
		HashMap<String, DcmLocalParam> statusList = DataManager
				.getDcmLocalParamList();
		// 循环显示车牌号，车载终端号及状态
		for (int i = 0; i+idx < allCnt; i++) {
			if(i < pageSize) {
				String carNumber = rds.get(idx + i).getCarNumber();
				String status = statusList.containsKey(carNumber) ? "On line"
						: "Off line";

				str.append("<tr>");
				str.append("<td background-color:#F5F5F5 style=color:#4682B4><a href= moreinfor?carnum="
						+ carNumber + ">" + carNumber + "</a></td>");
				str.append("<td background-color:#F5F5F5>" + "---" + "</td>");
				str.append("<td background-color:#F5F5F5>" + status + "</td>");
				str.append("</tr>");
			} else {
				break;
			}
		}

		return str;
	}
}
