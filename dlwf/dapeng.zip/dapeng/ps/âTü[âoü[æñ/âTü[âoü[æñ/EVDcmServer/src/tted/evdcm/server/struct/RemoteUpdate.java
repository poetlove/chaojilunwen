/*************************************************************************
 **
 * File Name		RemoteUpdate.java
 * File Summary		DCMにのリモートのアップグレードデータの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayOutputStream;
import tted.evdcm.server.utils.DcmDataOutputStream;

public class RemoteUpdate {
	/* ダイヤルアップ点名称 */
	String mDialPointName;
	/* ダイヤルユーザー名 */
	String mWirelessDialupUsername;
	/* ダイヤルパスワード */
	String mWirelessDialupPassword;
	/* IPアドレス */
	byte[] mIp;
	/* ポート */
	int mPort;
	/* 自動車端末メーカーID */
	String mDcmTerminalMakerId;
	/* ハードウエアバージョン */
	String mDcmHardwareVersion;
	/* ファームウェアバージョン */
	String mDcmFirmwareVersion;
	/* URLアドレス */
	String mURL;
	/* サーバーに接続の時限 */
	int mConnectedPeriod;

	/**
	 * RemoteUpdate型実例を初期化
	 * 
	 * @param null
	 *            
	 * @return null
	 */
	public RemoteUpdate() {
		mDialPointName = "";
		mWirelessDialupUsername = "";
		mWirelessDialupPassword = "";
		mIp = null;
		mPort = -1;
		mDcmTerminalMakerId = "";
		mDcmHardwareVersion = "";
		mDcmFirmwareVersion = "";
		mURL = "";
		mConnectedPeriod = 0;
	}

	public void setDialPointName(String name) {
		mDialPointName = name;
	}

	public String getDialPointName() {
		return mDialPointName;
	}

	public void setWirelessDialupUsername(String name) {
		mWirelessDialupUsername = name;
	}

	public String getWirelessDialupUsername() {
		return mWirelessDialupUsername;
	}

	public void setWirelessDialupPassword(String passwd) {
		mWirelessDialupPassword = passwd;
	}

	public String getWirelessDialupPassword() {
		return mWirelessDialupPassword;
	}

	public void setIp(byte[] ip) {
		mIp = ip;
	}

	public byte[] getIp() {
		return mIp;
	}

	public void setPort(int pt) {
		mPort = pt;
	}

	public int getPort() {
		return mPort;
	}

	public void setDcmTerminalMakerId(String id) {
		mDcmTerminalMakerId = id;
	}

	public String getDcmTerminalMakerId() {
		return mDcmTerminalMakerId;
	}

	public void setDcmHardwareVersion(String version) {
		mDcmHardwareVersion = version;
	}

	public String getDcmHardwareVersion() {
		return mDcmHardwareVersion;
	}

	public void setDcmFirmwareVersion(String version) {
		mDcmFirmwareVersion = version;
	}

	public String getDcmFirmwareVersion() {
		return mDcmFirmwareVersion;
	}

	public void setURL(String url) {
		mURL = url;
	}

	public String getURL() {
		return mURL;
	}

	public void setConnectedPeriod(int period) {
		mConnectedPeriod = period;
	}

	public int getConnectedPeriod() {
		return mConnectedPeriod;
	}

	/**
	 * RemoteUpdate型のバックを配列のデータに変更
	 * 
	 * @param null
	 *           
	 * @return 操作が正確時配列のデータを返し、でなければnullを返し
	 */
	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			dataOutputStream.writeBytes(mURL + ";");
			dataOutputStream.writeBytes(mDialPointName + ";");
			dataOutputStream.writeBytes(mWirelessDialupUsername + ";");
			dataOutputStream.writeBytes(mWirelessDialupPassword + ";");
			if (mIp != null && mIp.length >= 6) {
				dataOutputStream.write(mIp, 0, 6);
			}
			dataOutputStream.writeByte(';');
			dataOutputStream.writeShort(mPort);
			dataOutputStream.writeByte(';');
			dataOutputStream.writeBytes(mDcmTerminalMakerId + ";");
			dataOutputStream.writeBytes(mDcmHardwareVersion + ";");
			dataOutputStream.writeBytes(mDcmFirmwareVersion + ";");
			dataOutputStream.writeShort(mConnectedPeriod);

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
