/*************************************************************************
 **
 * File Name		DcmDataInputStream.java
 * File Summary		データ入力ストリーム許可アプリケーションは指定の方式で
 *                  基本データを入力ストリームに読み取れるのJavaタイプ。
 *                  アプリケーションを使用することができますデータ出力ストリーム書き込み後ほど
 *                  データから読み取りのデータ入力ストリーム。
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.utils;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class DcmDataInputStream {
	/* java提供の基本的なタイプのデータ入力ストリーム変数 */
	DataInputStream mDataInputStream;
	/* バイト流の順序変数 */
	boolean mNetWorkOrder = true;

	/**
	 * データ入力ストリームの創建と初期化.
	 * 
	 * @param in
	 *            入力ストリーム
	 * @return null
	 */
	public DcmDataInputStream(InputStream in) {
		mDataInputStream = new DataInputStream(in);
	}

	/**
	 * データ入力ストリームの創建と初期化.
	 * 
	 * @param in
	 *            入力ストリーム
	 * @param netWorkOrder
	 *            バイト流の使う順序
	 * @return null
	 */
	public DcmDataInputStream(InputStream in, boolean netWorkOrder) {
		mDataInputStream = new DataInputStream(in);
		mNetWorkOrder = netWorkOrder;
	}

	/**
	 * 整数の高位と低位バイト内容を交換
	 * 
	 * @param n
	 *            処理の整数
	 * @return 交換後の整数
	 */
	public static int intToLH(int n) {
		int ret = 0;
		
		ret |= (n & 0xff) << 24 ;
		ret |= ((n >> 8) & 0xff) << 16 ;
		ret |= ((n >> 16) & 0xff) << 8 ;
		ret |= (n >> 24) & 0xff ;

		return ret;
	}
	
	/**
	 * 文字の高位と低位バイト内容を交換
	 * 
	 * @param n
	 *            処理の文字
	 * @return 交換後の文字
	 */
	public static char charToLH(char n) {
		char ret = 0;
		
		ret |= (n & 0xff) << 8 ;
		ret |= ((n >> 8) & 0xff) ;

		return ret;
	}
	
	/**
	 * short型数の高位と低位バイト内容を交換
	 * 
	 * @param n
	 *            処理のshort型数
	 * @return 交換後のshort型数
	 */
	public static short shortToLH(short n) {
		short ret = 0;
		
		ret |= (n & 0xff) << 8 ;
		ret |= ((n >> 8) & 0xff) ;

		return ret;
	}
	
	/**
	 * unsigned short型数の高位と低位バイト内容を交換
	 * 
	 * @param n
	 *            処理のunsigned short型数
	 * @return 交換後のunsigned short型数
	 */
	public static int unsignedShortToLH(int n) {
		int ret = 0;
		
		ret |= (n & 0xff) << 8 ;
		ret |= ((n >> 8) & 0xff) ;

		return ret;
	}

	/**
	 * long型数の高位と低位バイト内容を交換
	 * 
	 * @param n
	 *            処理のlong型数
	 * @return 交換後のlong型数
	 */
	public static long longToLH(long n) {
		long ret = 0;

		ret |= (n & 0xff) << 56;
		ret |= ((n >> 8) & 0xff) << 48;
		ret |= ((n >> 16) & 0xff) << 40;
		ret |= ((n >> 24) & 0xff) << 32;
		ret |= ((n >> 32) & 0xff) << 24;
		ret |= ((n >> 40) & 0xff) << 16;
		ret |= ((n >> 48) & 0xff) << 8;
		ret |= ((n >> 56) & 0xff);

		return ret;
	}

	/**
	 * バイト配列のデータをリバース
	 * 
	 * @param b
	 *            バイト配列
	 * @return 交換後のバイト配列
	 */
	public static byte[] bytesReverseOrder(byte[] b) {
		int length = b.length;
		byte[] result = new byte[length];
		
		for (int i = 0; i < length; i++) {
			result[length - i - 1] = b[i];
		}
		
		return result;
	}
	
	/**
	 * 含む入力ストリームから読み取れる一定数量のバイトし、それらをストレージバッファ配列b中に保存
	 * 
	 * @param b
	 *            保存データ用のストレージバッファ
	 * @return 読み取れたバイト数
	 */
	public final int read(byte[] b) throws IOException {
		return mDataInputStream.read(b);
	}

	/**
	 * 含む入力ストリームから読み取れる最大lenのバイトし、それらをストレージバッファ配列b中に保存
	 * 
	 * @param b
	 *            保存データ用のストレージバッファ
	 * @param off
	 *            目標配列のスタートオフセット量
	 * @param len
	 *            読み取れる最大バイト数
	 * @return 読み取れたバイト数
	 */
	public final int read(byte[] b, int off, int len) throws IOException,
			NullPointerException, IndexOutOfBoundsException {
		return mDataInputStream.read(b, off, len);
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 読み取れたboolean値
	 */
	public final boolean readBoolean() throws IOException, EOFException {
		return mDataInputStream.readBoolean();
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 読み取れたバイト
	 */
	public final byte readByte() throws IOException, EOFException {
		return mDataInputStream.readByte();
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 二つバイトを読み取れし、それらcharを解釈になる
	 */
	public final char readChar() throws IOException, EOFException {
		if (mNetWorkOrder) {
			return mDataInputStream.readChar();
		} else {
			char num = mDataInputStream.readChar();
			return charToLH(num);
		}
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 8つのバイトを読み取れし、それらdoubleを解釈になる
	 */
	public final double readDouble() throws IOException, EOFException {
		return mDataInputStream.readDouble();
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 4つのバイトを読み取れし、それらfloatを解釈になる
	 */
	public final float readFloat() throws IOException, EOFException {
		return mDataInputStream.readFloat();
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 4つのバイトを読み取れし、それらintを解釈になる
	 */
	public final int readInt() throws IOException, EOFException {
		if (mNetWorkOrder) {
			return mDataInputStream.readInt();
		} else {
			int num = mDataInputStream.readInt();
			return intToLH(num);
		}
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 8つのバイトを読み取れし、それらlongを解釈になる
	 */
	public final long readLong() throws IOException, EOFException {
		if (mNetWorkOrder) {
			return mDataInputStream.readLong();
		} else {
			Long num = mDataInputStream.readLong();
			return longToLH(num);
		}
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 2つのバイトを読み取れし、それらshortを解釈になる
	 */
	public final short readShort() throws IOException, EOFException {
		if (mNetWorkOrder) {
			return mDataInputStream.readShort();
		} else {
			short num = mDataInputStream.readShort();
			return shortToLH(num);
		}
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 1つのバイトを読み取れし、それらunsigned byteを解釈になる
	 */
	public final int readUnsignedByte() throws IOException, EOFException {
		return mDataInputStream.readUnsignedByte();
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param null
	 *            
	 * @return 2つのバイトを読み取れし、それらunsigned shortを解釈になる
	 */
	public final int readUnsignedShort() throws IOException, EOFException {
		if (mNetWorkOrder) {
			return mDataInputStream.readUnsignedShort();
		} else {
			int num = mDataInputStream.readUnsignedShort();
			return unsignedShortToLH(num);
		}
	}

	/**
	 * 含む入力ストリームから必要なバイトを読み取れる
	 * 
	 * @param n
	 *            スキップするバイト数
	 * @return 実際にスキップバイト数
	 */
	public final int skipBytes(int n) throws IOException {
		return mDataInputStream.skipBytes(n);
	}

	/**
	 * このデータ入力ストリームをクロス.
	 * 
	 * @param null
	 *            
	 * @return null
	 */
	public void close() throws IOException {
		mDataInputStream.close();
	}

}
