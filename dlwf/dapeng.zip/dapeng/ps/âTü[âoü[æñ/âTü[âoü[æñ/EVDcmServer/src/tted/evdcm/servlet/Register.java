package tted.evdcm.servlet;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		// 获取jsp页面输入内容
		String psw1 = request.getParameter("password2");
		String name = request.getParameter("name");
		String psw = request.getParameter("password1");
		String Email = request.getParameter("Email");
		String r = request.getParameter("r");

		// 两次密码是否匹配
		if (!(psw.equals(psw1))) {
			request.setAttribute("message1", "两次输入密码不同");
			request.getRequestDispatcher("Register.jsp").forward(request,
					response);
		} else if (r.equals("-1")) {
			request.setAttribute("message2", "请输入正确的邮箱地址");
			request.getRequestDispatcher("Register.jsp").forward(request,
					response);
		} else if ((name.length() * psw.length() * psw1.length() * Email
				.length()) != 0 && psw.equals(psw1)) {// 如果用户名密码和邮箱都不为空则连接数据库
			Connection con = null;
			Statement sql = null;
			ResultSet rs = null;
			try {
				
				try {
					Class.forName(Common.DBDriver);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				con = DriverManager.getConnection(Common.DBUrl, Common.DBUser, Common.DBPassword);
				sql = con.createStatement();

				// 查询数据库是否已有此用户名
				String query1 = "select * from " + Common.USERS_TABLE
						+ " where " + Common.USER_NAME_COLUMN + "= " + "'"
						+ name + "'";
				rs = sql.executeQuery(query1);
				if (rs.next() == true) {
					request.setAttribute("message", "此用户已存在，请重新输入");
					request.getRequestDispatcher("Register.jsp").forward(
							request, response);
				} else {// 向数据库中添加记录
					String condition = "INSERT INTO " + Common.USERS_TABLE
							+ " VALUES" + "(" + "'" + name + "','" + psw
							+ "','" + Email + "'" + ")";
					sql.executeUpdate(condition);
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("Login.jsp");
					dispatcher.forward(request, response);

				}
				con.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
	}

}
