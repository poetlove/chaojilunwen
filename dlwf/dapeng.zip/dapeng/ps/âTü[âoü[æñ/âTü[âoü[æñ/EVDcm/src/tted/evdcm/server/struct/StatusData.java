/*************************************************************************
 **
 * File Name		StatusData.java
 * File Summary		DCMからの端末情報データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;
import tted.evdcm.server.utils.DcmDataOutputStream;

public class StatusData {
	/* DCMの状態標識ビットマスク:通電 */
	static public final int MASK_ENERGIZED = 0x01;
	/* DCMの状態標識ビットマスク:電源状態 */
	static public final int MASK_POWER = 0x02;
	/* DCMの状態標識ビットマスク:通信伝送 */
	static public final int MASK_COMMUNICATION = 0x04;
	/* DCMの状態標識ビットマスク:その他の異常 */
	static public final int MASK_OTHERS = 0x08;

	/* 車両ナンバー */
	String mCarNumber;
	/* 情報収集時間 */
	String mDateTime;
	/* 状態標識 */
	int mStatus;
	/* リザーブ */
	byte[] mReserve = {0,0,0,0};
	
	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			

			dataOutputStream.write(Common.dateTimeToBytes(mDateTime),0,6);
			dataOutputStream.writeByte(mStatus);

			dataOutputStream.write(mReserve,0,mReserve.length);

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void setCarNumber(String num) {
		mCarNumber = num;
	}
	public String getCarNumber() {
		return mCarNumber;
	}
	public void setDateTime(String dt) {
		mDateTime = dt;
	}
	public String getDateTime() {
		return mDateTime;
	}
	public void setStatus(int status) {
		mStatus = status;
	}
	public int getStatus() {
		return mStatus;
	}
	
	/**
	 * 配列のデータをStatusData型のバックに変更
	 * 
	 * @param carNumber
	 *            車のナンバー.
	 * @param byteStream
	 *            含むStatusData情報の配列.
	 * @return 配列操作が正確時StatusData実例を返し、でなければnullを返し
	 */
	static public StatusData fromBytesToPacket(String carNumber, byte[] byteStream) {
		if(byteStream.length < 11) {
			return null;
		}
		
		StatusData statusData = new StatusData();
		statusData.mCarNumber = carNumber;
		
		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			statusData.mDateTime = Common.dateTimeFromBytes(dt);
			statusData.mStatus = Common.byteToInt(dataInputStream.readByte());

			return statusData;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
