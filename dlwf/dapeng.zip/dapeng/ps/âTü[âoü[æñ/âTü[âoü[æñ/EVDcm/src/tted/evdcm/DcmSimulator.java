package tted.evdcm;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import tted.evdcm.server.struct.BatteryPacket;
import tted.evdcm.server.struct.RealTimeExtremumData;
import tted.evdcm.server.struct.RegistData;
import tted.evdcm.server.struct.StatusData;

public class DcmSimulator extends JPanel {
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {

//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {

				try {

					UIManager.setLookAndFeel(UIManager
							.getSystemLookAndFeelClassName());
				} catch (Exception e) {

					e.printStackTrace();
				}

				JFrame sim = new JFrame("Dcm Simulator");

				sim.setContentPane(new DcmSimulator());
				sim.pack();
				sim.setResizable(false);

				sim.setLocationRelativeTo(null);
				sim.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				sim.setVisible(true);
//			}
//		});
	}
	
	private static Socket socket = null;
	private static PrintStream os = null;
	private static BufferedReader is = null;
	
	private static Timer timer = null;

	private static final String vin = "aabbccddee1234567";
	private static int heartTime = 10000;
	
	
	
	private static final String LABEL_SERVER_IP = "服务器地址：";
	private static final String LABEL_SERVER_PORT = "端口号：";
	private static final String LABEL_REAL_TIME = "实时数据：";
	
	private JTextField fieldServerIp;
	private JTextField fieldServerPort;
	private static JTextArea areaMessage;

	// ****** add 1 ***************************************************
	private static final String LABEL_Connect = "连接";
	private static final String LABEL_Disconnect = "断开连接";
	private static final String LABEL_Regist_msg = "注册信息";
	private static final String LABEL_Status_msg = "端末状态信息";
	
	private static final String LABEL_RTExtremum_msg = "极值数据";

	
	
	// ****** add 2 ***************************************************
	private JButton btnConnect;
	private JButton btnDisconnect;
	private JButton btnRegistmsg;
	private JButton btnStatusmsg;
	private JButton btnRTExtremummsg;
	
	// ****** add 3 ***************************************************
	private Action actionConnect;
	private Action actionDisconnect;
	private Action actionRegistmsg;
	private Action actionStatusmsg;
	private Action actionRTExtremummsg;

	DcmSimulator() {

		super(new BorderLayout(5, 5));

		assert SwingUtilities.isEventDispatchThread();

		fieldServerIp = new JTextField(20);
		fieldServerPort = new JTextField(10);
		
		areaMessage = new JTextArea(10,50);
		
		fieldServerIp.setText("127.0.0.1");
		fieldServerPort.setText("12345");

		// ******* add 4 ***************************************************
		actionRTExtremummsg = new AbstractAction(LABEL_RTExtremum_msg) {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {

				// @TODO to be implemented.
				clearAreaMessage();
				try {
					RealTimeExtremumData ed = new RealTimeExtremumData();

					ed.setCarNumber("LB.01234");// must 8 bytes
					SimpleDateFormat df = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					ed.setDateTime(df.format(new Date()));
					
					ed.setMaxVoltageBatteryPackNumber(254);
					ed.setMaxVoltageBatteryNumber(254);
					ed.setBatteryMaxVoltage(15000);
					
					ed.setMinVoltageBatteryPackNumber(1);
					ed.setMinVoltageBatteryNumber(1);
					ed.setBatteryMinVoltage(0);
					
					ed.setMaxTempBatteryPackNumber(254);
					ed.setMaxTempProbeNumber(254);
					ed.setMaxTemperature(165);
					
					ed.setMinTempBatteryPackNumber(1);
					ed.setMinTempProbeNumber(1);
					ed.setMinTemperature(0);
					
					ed.setTotalVoltage(10000);
					ed.setTotalCurrent(20000);
					ed.setSOC(250);
					
					ed.setRemainEnergy(9999);
					ed.setInsulationResistance(9999);
					

					byte[] b = DataManager
							.dcmRealTimePacketSet(vin,
									ed.fromPacketToBytes());
					os.write(b, 0, b.length);
					os.flush();

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		};
		
		actionStatusmsg = new AbstractAction(LABEL_Status_msg) {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {

				// @TODO to be implemented.
				clearAreaMessage();
				try {
					StatusData sd = new StatusData();

					SimpleDateFormat df = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					sd.setDateTime(df.format(new Date()));

					sd.setStatus(StatusData.MASK_POWER
							| StatusData.MASK_COMMUNICATION
							| StatusData.MASK_ENERGIZED
							| StatusData.MASK_OTHERS);

					sd.setCarNumber("LB.01234");// must 8 bytes

					byte[] b = DataManager
							.dcmParamPacketSet(DataManager.CMD_STATUS, vin,
									sd.fromPacketToBytes());
					os.write(b, 0, b.length);
					os.flush();

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		};
		
		actionConnect = new AbstractAction(LABEL_Connect) {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					socket=new Socket(fieldServerIp.getText().trim(),Integer.parseInt(fieldServerPort.getText().trim()));
					is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
					os=new PrintStream(socket.getOutputStream());
					setAllButtonEnableByConnect(true);
					clearAreaMessage();
					new ThreadRead().start();
				} catch (UnknownHostException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		};
		
		actionDisconnect = new AbstractAction(LABEL_Disconnect) {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					os.close();
					is.close();
					socket.close();
					os = null;
					is = null;
					socket = null;
					timer.cancel();
					timer = null;
					setAllButtonEnableByConnect(false);
					clearAreaMessage();
				} catch (UnknownHostException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		};

		actionRegistmsg = new AbstractAction(LABEL_Regist_msg) {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {

				// @TODO to be implemented.
				clearAreaMessage();
				try {
					RegistData rd = new RegistData();
					
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					rd.setDateTime(df.format(new Date()));
					
					rd.setRegistSerialNumber(1);
					rd.setCarNumber("LB.01234");//must 8 bytes
					
					rd.setMakerCode("make");
					rd.setTerminalNumber("000001");
					rd.setSerialNumber(1);
					
					rd.setBatteryPackCount(1);
					
					ArrayList<BatteryPacket> bps = new ArrayList<BatteryPacket>();
					BatteryPacket bp = new BatteryPacket();
					bp.setBatteryPackSerialNumber(1);
					bp.setPackEncodeMaker("btmk");
					bp.setPackEncodeBttyType(100);
					bp.setPackEncodeRatedEnery(1000);
					bp.setPackEncodeRatedVoltage(1002);
					byte[] date = {12,10,15};
					bp.setPackEncodeMakeDate(date);
					bp.setSerialNumber(101);
					bps.add(bp);
					rd.setBatteryPackets(bps);

					byte[] b = DataManager.dcmParamPacketSet(DataManager.CMD_REGIST,vin,rd.fromPacketToBytes());
					os.write(b,0,b.length);
					os.flush();
					
					timer = new Timer();
					timer.scheduleAtFixedRate(new TimerTask() {
						public void run() {
							byte[] p = DataManager.dcmHeartPacketSet(vin);
							try {
								os.write(p);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							os.flush();
							areaMessage.append("\nHeart response:");
						}
					}, heartTime, heartTime);

					setAllButtonEnableByRegist(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		};
		
		// ******* add 5 ***************************************************
		btnConnect = new JButton(actionConnect);
		btnDisconnect = new JButton(actionDisconnect);
		btnRegistmsg = new JButton(actionRegistmsg);
		btnStatusmsg = new JButton(actionStatusmsg);
		btnRTExtremummsg = new JButton(actionRTExtremummsg);
		
		setAllButtonEnableByConnect(false);
		setAllButtonEnableByRegist(false);
		
		add(layoutFields(), BorderLayout.NORTH);
		add(areaMessage,BorderLayout.CENTER);

		setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	}


	private JComponent layoutFields() {

		JComponent result = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;
		gbc.insets = new Insets(5, 5, 5, 5);
		result.add(new JLabel(getBoldHTML(LABEL_SERVER_IP)), gbc);
		gbc.gridx++;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		result.add(fieldServerIp, gbc);
		gbc.gridx++;
		result.add(new JLabel(getBoldHTML(LABEL_SERVER_PORT)), gbc);
		gbc.gridx++;
		result.add(fieldServerPort, gbc);

		gbc.gridx++;
		result.add(btnConnect, gbc);
		gbc.gridx++;
		result.add(btnDisconnect, gbc);
		
		// ****** add 6 ***************************************************
		gbc.gridx = 0;
		gbc.gridy++;
		result.add(btnRegistmsg, gbc);
		
		gbc.gridx ++;
		result.add(btnStatusmsg, gbc);
		
		gbc.gridx = 0;
		gbc.gridy++;
		result.add(new JLabel(getBoldHTML(LABEL_REAL_TIME)), gbc);
		gbc.gridy++;
		result.add(btnRTExtremummsg, gbc);
		
		return result;
	}

	private String getBoldHTML(String s) {

		return "<html><b>" + s + "</b></html>";
	}
	
	public static class ThreadRead extends Thread {
		public void run() {
			int cnt = 0;
			int ycnt = 0;
			char[] b = new char[4096];
			while (DcmSimulator.is != null) {

				try {

					int i = is.read(b, 0, 4096);
					if (i == -1) {
						return;
					} else {
						for (int a = 0; a < i; a++) {
							if (cnt == 20) {
								cnt = 0;
								areaMessage.append("\n");
							} else {
								cnt++;
							}
							areaMessage.append((byte)b[a] + ",");
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return;
				}

				if (ycnt == 3) {
					ycnt = 0;
					areaMessage.setText("");
				} else {
					ycnt++;
				}
			}
		}
	}
	
	private void clearAreaMessage() {
		areaMessage.setText("");
	}
	
	private void setAllButtonEnableByConnect(boolean isConnect) {
		// ****** add 7 ***************************************************
		if(isConnect) {
			btnConnect.setEnabled(false);
			btnDisconnect.setEnabled(true);
			btnRegistmsg.setEnabled(true);
		} else {
			btnConnect.setEnabled(true);
			btnDisconnect.setEnabled(false);
			btnRegistmsg.setEnabled(false);
			btnStatusmsg.setEnabled(false);
		}
	}
	
	private void setAllButtonEnableByRegist(boolean isRegisted) {
		// ****** add 8 ***************************************************
		if(isRegisted) {
			btnStatusmsg.setEnabled(true);
			btnRTExtremummsg.setEnabled(true);
		} else {
			btnStatusmsg.setEnabled(false);
			btnRTExtremummsg.setEnabled(false);
		}
	}
	

}
