package tted.evdcm;

import tted.evdcm.server.struct.DcmDataPacket;

public class DataManager {
	
	static final int CMD_REGIST = 0x01;
	
	static final int CMD_REAL_TIME = 0x02;
	
	static final int CMD_STATUS = 0x03;
	
	static final int CMD_HEART = 0x04;
	
	static final int CMD_REISSUED = 0x05;
	
	static final int CMD_QUERY = 0x80;
	
	static final int CMD_SET = 0x81;
	
	static final int CMD_DCM_CONTROL = 0x82;

	
	static final int RESPONSE_SUCCESS = 0x01;
	
	static final int RESPONSE_MODIFY_ERR = 0x02;
	
	static final int RESPONSE_CMD = 0xfe;
	// ////////////////////////////////////////
	static public byte[] responsePacketSet(int cmd, String vin) {
		DcmDataPacket ddp = new DcmDataPacket();
		ddp.setStartFlag("##");
		ddp.setCmdFlag(cmd);
		ddp.setResponseFlag(RESPONSE_SUCCESS);
		ddp.setIdentifier(vin);
		ddp.setRsa(0x00);
		ddp.setDataLength(0);
		ddp.setData(null);
		ddp.setBcc(0);
		byte[] temp = ddp.fromPacketToBytes();
		ddp.setBcc(getBcc(temp, 0, temp.length - 1));

		return ddp.fromPacketToBytes();
	}
	
	static public byte[] dcmHeartPacketSet(String vin) {
		DcmDataPacket ddp = new DcmDataPacket();
		ddp.setStartFlag("##");
		ddp.setCmdFlag(CMD_HEART);
		ddp.setResponseFlag(RESPONSE_CMD);
		ddp.setIdentifier(vin);
		ddp.setRsa(0x00);
		ddp.setDataLength(0);
		ddp.setData(null);
		ddp.setBcc(0);
		byte[] temp = ddp.fromPacketToBytes();
		ddp.setBcc(getBcc(temp, 0, temp.length - 1));

		return ddp.fromPacketToBytes();
	}


	static public byte[] dcmParamPacketSet(int command, String vin, byte[] data) {
		DcmDataPacket ddp = new DcmDataPacket();
		ddp.setStartFlag("##");
		ddp.setCmdFlag(command);
		ddp.setResponseFlag(RESPONSE_CMD);
		ddp.setIdentifier(vin);
		ddp.setRsa(0x00);
		ddp.setDataLength(data.length);
		ddp.setData(data);
		ddp.setBcc(0);
		byte[] temp = ddp.fromPacketToBytes();
		ddp.setBcc(getBcc(temp, 0, temp.length - 1));

		return ddp.fromPacketToBytes();
	}
	
	static public byte[] dcmRealTimePacketSet(String vin, byte[] data) {
		DcmDataPacket ddp = new DcmDataPacket();
		ddp.setStartFlag("##");
		ddp.setCmdFlag(CMD_REAL_TIME);
		ddp.setResponseFlag(200);
		ddp.setIdentifier(vin);
		ddp.setRsa(0x00);
		ddp.setDataLength(data.length);
		ddp.setData(data);
		ddp.setBcc(0);
		byte[] temp = ddp.fromPacketToBytes();
		ddp.setBcc(getBcc(temp, 0, temp.length - 1));

		return ddp.fromPacketToBytes();
	}

	static byte getBcc(byte[] bf, int offset, int length) {
		byte bcc = 0;
		if (offset + length > bf.length) {
			return bcc;
		}
		for (int i = 0; i < length; i++) {
			bcc = (byte) (bcc ^ bf[offset + i]);
		}
		return bcc;
	}

	static boolean bccCheck(byte[] bf) {
		if (bf.length < 2) {
			return false;
		}

		byte calcBcc = getBcc(bf, 0, bf.length - 1);
		byte bcc = bf[bf.length - 1];
		if (calcBcc == bcc) {
			return true;
		} else {
			return false;
		}
	}

	
}
