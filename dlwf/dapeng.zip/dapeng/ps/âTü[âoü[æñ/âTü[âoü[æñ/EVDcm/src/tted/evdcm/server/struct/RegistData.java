/*************************************************************************
 **
 * File Name		RegistData.java
 * File Summary		DCMからの登録データの保存用
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataOutputStream;

public class RegistData {
	/* 登録の時間 */
	String mDateTime;
	/* 登録通し番号 */
	int mRegistSerialNumber;
	/* 車両ナンバー */
	String mCarNumber;

	// String mCarTerminalNumber;
	/* 車載端末番号 メーカーのコード */
	String mMakerCode;
	/* 車載端末番号 端末ロット */
	String mTerminalNumber;
	/* 車載端末番号 通し番号 */
	int mSerialNumber;

	/* 動力バッテリーパック数N */
	int mBatteryPackCount;
	/* 動力バッテリーパック表 */
	ArrayList<BatteryPacket> mBatteryPackets;
	/* リザーブ */
	byte[] mReserve = {0,0,0,0,0,0,0,0,0,0,0};

	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			

			dataOutputStream.write(Common.dateTimeToBytes(mDateTime),0,6);
			dataOutputStream.writeShort(mRegistSerialNumber);
			dataOutputStream.writeBytes(mCarNumber);
			dataOutputStream.writeBytes(mMakerCode);
			dataOutputStream.writeBytes(mTerminalNumber);
			dataOutputStream.writeShort(mSerialNumber);
			dataOutputStream.writeByte(mBatteryPackCount);
			if(mBatteryPackets != null && mBatteryPackets.size() > 0) {
				for(int i=0; i<mBatteryPackets.size(); i++) {
					dataOutputStream.write(mBatteryPackets.get(i).fromPacketToBytes(),0,20);
				}
			}
			dataOutputStream.write(mReserve,0,11);

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void setDateTime(String dt) {
		mDateTime = dt;
	}

	public String getDateTime() {
		return mDateTime;
	}

	public void setRegistSerialNumber(int num) {
		mRegistSerialNumber = num;
	}

	public int getRegistSerialNumber() {
		return mRegistSerialNumber;
	}

	public void setCarNumber(String num) {
		mCarNumber = num;
	}

	public String getCarNumber() {
		return mCarNumber;
	}

	// public void setCarTerminalNumber(String num) {
	// mCarTerminalNumber = num;
	// }
	// public String getCarTerminalNumber() {
	// return mCarTerminalNumber;
	// }
	public void setMakerCode(String v) {
		mMakerCode = v;
	}

	public String getMakerCode() {
		return mMakerCode;
	}

	public void setTerminalNumber(String v) {
		mTerminalNumber = v;
	}

	public String getTerminalNumber() {
		return mTerminalNumber;
	}

	public void setSerialNumber(int v) {
		mSerialNumber = v;
	}

	public int getSerialNumber() {
		return mSerialNumber;
	}

	public void setBatteryPackCount(int cnt) {
		mBatteryPackCount = cnt;
	}

	public int getBatteryPackCount() {
		return mBatteryPackCount;
	}

	public void setBatteryPackets(ArrayList<BatteryPacket> abp) {
		mBatteryPackets = abp;
	}

	public ArrayList<BatteryPacket> getBatteryPackets() {
		return mBatteryPackets;
	}

}
