/*************************************************************************
 **
 * File Name		Common.java
 * File Summary		常用の共通の関数
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Common {
	/**
	 * サーバーの閉じる状態の標識.
	 */
	public static boolean mServerShutDown = false;

	/**
	 * サーバーの閉じる状態を設定.
	 * 
	 * @param shutdown
	 *            サーバーがシャットダウン時、この変数がtrue、でなければ変数がfalse.
	 * @return null
	 */
	public static void setServerShutDown(boolean shutdown) {
		mServerShutDown = shutdown;
	}

	/**
	 * サーバーの閉じる状態を獲得.
	 * 
	 * @param null
	 *            
	 * @return サーバーのシャットダウン状態
	 */
	public static boolean getServerShutDown() {
		return mServerShutDown;
	}

	/**
	 * 指定配列を初期化.
	 * 
	 * @param paramArrayOfByte
	 *            初期化の必要がある配列
	 * @return null
	 */
	public static void zeroMemory(byte[] paramArrayOfByte) {
		Arrays.fill(paramArrayOfByte, (byte) 0x00);
	}

	/**
	 * 指定配列のデータを目標配列にコピー.
	 * 
	 * @param destArrayOfByte
	 *            目標配列
	 * @param destOffset
	 *            目標配列のスタート場所
	 * @param srcArrayOfByte
	 *            指定配列
	 * @param srcOffset
	 *            指定配列のスタート場所
	 * @param length
	 *            コピーのデータの長さ
	 * @return null
	 */
	public static void memcpy(byte[] destArrayOfByte, int destOffset,
			byte[] srcArrayOfByte, int srcOffset, int length) {
		System.arraycopy(srcArrayOfByte, srcOffset, destArrayOfByte,
				destOffset, length);
	}

	/**
	 * 指定のIP配列を文字列型に変更.
	 * 
	 * @param ipBytes
	 *            指定のIP配列       [0][0][192][168][10][3]
	 * @return 文字列型のIPアドレス "0.0.192.168.10.3"
	 */
	public static String ipFromBytes(byte[] ipBytes) {
		if (ipBytes == null || ipBytes.length != 6) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		for (byte b : ipBytes) {
			sb.append(byteToInt(b)).append(".");
		}
		String retStr = sb.substring(0, sb.length() - 1);
		return retStr;
	}

	/**
	 * 文字列IPを配列型に変更.
	 * 
	 * @param ipString
	 *            文字列IP         "0.0.192.168.10.3"
	 * @return 配列型のIPアドレス [0][0][192][168][10][3]
	 */
	public static byte[] ipToBytes(String ipString) {
		String[] sa = ipString.split("\\.");
		byte[] ipBytes = new byte[sa.length];
		for (int i = 0; i < sa.length; i++) {
			ipBytes[i] = Byte.valueOf(sa[i]);
		}
		return ipBytes;
	}

	/**
	 * 指定の時間配列を文字列型に変更.
	 * 
	 * @param dateTimeBytes
	 *            指定の時間配列 [15][03][10][16][31][20]
	 * @return 文字列型の時間   "2015-03-10 16:31:20"
	 */
	public static String dateTimeFromBytes(byte[] dateTimeBytes) {
		if (dateTimeBytes == null || dateTimeBytes.length != 6) {
			return null;
		}

		StringBuilder sb = new StringBuilder();
		sb.append(20).append(dateTimeBytes[0]).append("-")
				.append(dateTimeBytes[1]).append("-").append(dateTimeBytes[2])
				.append(" ").append(dateTimeBytes[3]).append(":")
				.append(dateTimeBytes[4]).append(":").append(dateTimeBytes[5]);

		return sb.toString();
	}

	/**
	 * 文字列型時間を配列型に変更.
	 * 
	 * @param dateTimeString
	 *            文字列型時間 "2015-03-10 16:31:20"
	 * @return 配列型の時間   [15][03][10][16][31][20]
	 */
	public static byte[] dateTimeToBytes(String dateTimeString) {
		if (dateTimeString == null) {
			return null;
		}
		String dateTime = dateTimeString.substring(2);
		String[] sa = dateTime.split(" ");
		if (sa.length != 2) {
			return null;
		}

		try {
			byte[] dateTimeBytes = new byte[6];

			String[] date = sa[0].split("-");
			if (date.length != 3) {
				return null;
			}
			dateTimeBytes[0] = Byte.valueOf(date[0]);
			dateTimeBytes[1] = Byte.valueOf(date[1]);
			dateTimeBytes[2] = Byte.valueOf(date[2]);

			String[] time = sa[1].split(":");
			if (time.length != 3) {
				return null;
			}
			dateTimeBytes[3] = Byte.valueOf(time[0]);
			dateTimeBytes[4] = Byte.valueOf(time[1]);
			dateTimeBytes[5] = Byte.valueOf(time[2]);
			return dateTimeBytes;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 指定配列を文字列型に変更.
	 * 
	 * @param b
	 *            指定配列
	 * @return 文字列
	 */
	public static String strFromBytes(byte[] b) {
		StringBuffer result = new StringBuffer("");
		int length = b.length;
		for (int i = 0; i < length; i++) {
			result.append((byte) (b[i] & 0xff));
		}
		return result.toString();

	}

	/**
	 * 文字列を配列型に変更.
	 * 
	 * @param str
	 *            文字列
	 * @return 配列
	 */
	public static byte[] strToBytes(String str) {
		return str.getBytes();
	}

	/**
	 * 整数をバイトに変更.
	 * 
	 * @param a
	 *            整数
	 * @return バイト
	 */
	public static byte intToByte(int a) {
		byte res = (byte) a;
		return res;
	}

	/**
	 * バイトを整数に変更.
	 * 
	 * @param a
	 *            バイト
	 * @return 整数
	 */
	public static int byteToInt(byte a) {
		int res = 0x00FF & a;
		return res;
	}

	/**
	 * バイトを符号無しバイトに変更.
	 * 
	 * @param a
	 *            バイト
	 * @return 符号無しバイト
	 */
	public static byte getUnsignedByte(byte a) {
		int temp = 0x00FF & a;
		byte res = (byte) temp;
		return res;
	}

	/**
	 * 整数リストをバイト配列に変更.
	 * 
	 * @param temp
	 *            整数リスト
	 * @return バイト配列
	 */
	public static byte[] getByteArrayByList(ArrayList<Integer> temp) {
		byte[] res = new byte[temp.size()];
		for (int i = 0; i < res.length; i++) {
			res[i] = intToByte(temp.get(i));
		}
		return res;
	}

	/**
	 * 文字列はすべてが数字で構成を判断.
	 * 
	 * @param str
	 *            判断必要の文字列
	 * @return すべてが数字で構成時trueを返し、でなければfalseを返し
	 */
	public static boolean isNumeric(String str) {
		Pattern pattern = Pattern.compile("[0-9]*");
		Matcher isNum = pattern.matcher(str);
		if (!isNum.matches()) {
			return false;
		}
		return true;
	}

	/**
	 * 文字列はすべてが数字とアルファベットで構成を判断.
	 * 
	 * @param str
	 *            判断必要の文字列
	 * @return すべてが数字とアルファベットで構成時trueを返し、でなければfalseを返し
	 */
	public static boolean isCharNumeric(String str) {
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher isCharNum = pattern.matcher(str);
		if (!isCharNum.matches()) {
			return false;
		}
		return true;
	}

	/**
	 * 二つ時間点を比べる.
	 * 
	 * @param dateTime1
	 *            比べる必要の時間点1
	 * @param dateTime2
	 *            比べる必要の時間点2
	 * @return dateTime1がdateTime2の後時、1を返し、
	 *          dateTime1とdateTime2が同じ時、0を返し、
	 *          dateTime2がdateTime1の後時、-1を返し、
	 *          dateTime1かdateTime2かエラーがある時、0xfeを返し
	 */
	public static int compareWithDateTime(String dateTime1, String dateTime2) {

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		try {
			Date dt1 = df.parse(dateTime1);
			Date dt2 = df.parse(dateTime2);
			if (dt1.getTime() > dt2.getTime()) {
				// System.out.println("dt1 after dt2");
				return 1;
			} else if (dt1.getTime() < dt2.getTime()) {
				// System.out.println("dt1 before dt2");
				return -1;
			} else {
				return 0;
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			return 0xfe;
		}
	}

	/**
	 * 文字列は空を判断.
	 * 
	 * @param str
	 *            判断必要の文字列
	 * @return 文字列が空時trueを返し、でなければfalseを返し
	 */
	public static boolean isStringNull(String str) {
		if (str == null || str.equals("")) {
			return true;
		}
		return false;
	}
}
