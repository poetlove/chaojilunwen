/*************************************************************************
 **
 * File Name		BatteryPacket.java
 * File Summary		電池バックの情報を保存
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import tted.evdcm.server.utils.Common;
import tted.evdcm.server.utils.DcmDataInputStream;
import tted.evdcm.server.utils.DcmDataOutputStream;

public class BatteryPacket {
	/* 動力バッテリーパック番号 */
	int mBatteryPackSerialNumber;
	/* 動力バッテリーパックメーカーのコード */
	String mPackEncodeMaker;
	/* 動力バッテリーパックバッテリーコード */
	int mPackEncodeBttyType;
	/* 動力バッテリーパック定格ポワー */
	int mPackEncodeRatedEnery;
	/* 動力バッテリーパック定格電圧 */
	int mPackEncodeRatedVoltage;
	/* 動力バッテリーパックバッテリー生産日コード */
	byte[] mPackEncodeMakeDate;
	/* 動力バッテリーパック通し番号 */
	int mSerialNumber;
	/* リザーブ */
	byte[] mReserve = {0,0,0,0,0};

	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DcmDataOutputStream dataOutputStream = new DcmDataOutputStream(
				byteArrayOutputStream);
		try {
			dataOutputStream.writeByte(mBatteryPackSerialNumber);
			dataOutputStream.writeBytes(mPackEncodeMaker);
			dataOutputStream.writeByte(mPackEncodeBttyType);
			dataOutputStream.writeShort(mPackEncodeRatedEnery);
			dataOutputStream.writeShort(mPackEncodeRatedVoltage);
			dataOutputStream.write(mPackEncodeMakeDate,0,3);
			dataOutputStream.writeShort(mSerialNumber);

			dataOutputStream.write(mReserve,0,5);

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void setBatteryPackSerialNumber(int num) {
		mBatteryPackSerialNumber = num;
	}
	public int getBatteryPackSerialNumber() {
		return mBatteryPackSerialNumber;
	}
	public void setPackEncodeMaker(String maker) {
		mPackEncodeMaker = maker;
	}
	public String getPackEncodeMaker() {
		return mPackEncodeMaker;
	}
	public void setPackEncodeBttyType(int type) {
		mPackEncodeBttyType = type;
	}
	public int getPackEncodeBttyType() {
		return mPackEncodeBttyType;
	}
	public void setPackEncodeRatedEnery(int enery) {
		mPackEncodeRatedEnery = enery;
	}
	public int getPackEncodeRatedEnery() {
		return mPackEncodeRatedEnery;
	}
	public void setPackEncodeRatedVoltage(int voltage) {
		mPackEncodeRatedVoltage = voltage;
	}
	public int getPackEncodeRatedVoltage() {
		return mPackEncodeRatedVoltage;
	}
	public void setPackEncodeMakeDate(byte[] makerDate) {
		mPackEncodeMakeDate = makerDate;
	}
	public byte[] getPackEncodeMakeDate() {
		return mPackEncodeMakeDate;
	}
	public void setSerialNumber(int num) {
		mSerialNumber = num;
	}
	public int getSerialNumber() {
		return mSerialNumber;
	}
	
	/**
	 * 配列のデータをBatteryPacket型のバックに変更
	 * 
	 * @param byteStream
	 *            含むBatteryPacket情報の配列.
	 * @return 配列操作が正確時BatteryPacket実例を返し、でなければnullを返し
	 */
	static public BatteryPacket fromBytesToPacket(byte[] byteStream) {
		BatteryPacket batteryPacket = new BatteryPacket();
		DcmDataInputStream dataInputStream = new DcmDataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			batteryPacket.mBatteryPackSerialNumber = dataInputStream.readByte();

			byte[] encodeMaker = new byte[4];
			dataInputStream.read(encodeMaker, 0, encodeMaker.length);
			batteryPacket.mPackEncodeMaker = Common.strFromBytes(encodeMaker);
			
			batteryPacket.mPackEncodeBttyType = dataInputStream.readByte();
			
			batteryPacket.mPackEncodeRatedEnery = dataInputStream.readShort();
			batteryPacket.mPackEncodeRatedVoltage = dataInputStream.readShort();
			
			batteryPacket.mPackEncodeMakeDate = new byte[3];
			dataInputStream.read(batteryPacket.mPackEncodeMakeDate, 0, batteryPacket.mPackEncodeMakeDate.length);
			
			batteryPacket.mSerialNumber = dataInputStream.readShort();
			
			return batteryPacket;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
