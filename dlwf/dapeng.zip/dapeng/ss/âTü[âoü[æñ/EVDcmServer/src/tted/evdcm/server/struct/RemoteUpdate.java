package tted.evdcm.server.struct;

public class RemoteUpdate {
	String mDialPointName;
	String mWirelessDialupUsername;
	String mWirelessDialupPassword;
	byte[] mIp;
	int mPort;
	String mDcmTerminalMakerId;
	String mDcmHardwareVersion;
	String mDcmFirmwareVersion;
	String mURL;
	int mConnectedPeriod;
	
	public void setDialPointName(String name) {
		mDialPointName = name;
	}
	public String getDialPointName() {
		return mDialPointName;
	}
	public void setWirelessDialupUsername(String name) {
		mWirelessDialupUsername = name;
	}
	public String getWirelessDialupUsername() {
		return mWirelessDialupUsername;
	}
	public void setWirelessDialupPassword(String passwd) {
		mWirelessDialupPassword = passwd;
	}
	public String getWirelessDialupPassword() {
		return mWirelessDialupPassword;
	}
	public void setIp(byte[] ip) {
		mIp = ip;
	}
	public byte[] getIp() {
		return mIp;
	}
	public void setPort(int pt) {
		mPort = pt;
	}
	public int getPort() {
		return mPort;
	}
	public void setDcmTerminalMakerId(String id) {
		mDcmTerminalMakerId = id;
	}
	public String getDcmTerminalMakerId() {
		return mDcmTerminalMakerId;
	}
	public void setDcmHardwareVersion(String version) {
		mDcmHardwareVersion = version;
	}
	public String getDcmHardwareVersion() {
		return mDcmHardwareVersion;
	}
	public void setDcmFirmwareVersion(String version) {
		mDcmFirmwareVersion = version;
	}
	public String getDcmFirmwareVersion() {
		return mDcmFirmwareVersion;
	}
	public void setURL(String url) {
		mURL = url;
	}
	public String getURL() {
		return mURL;
	}
	public void setConnectedPeriod(int period) {
		mConnectedPeriod = period;
	}
	public int getConnectedPeriod() {
		return mConnectedPeriod;
	}
}
