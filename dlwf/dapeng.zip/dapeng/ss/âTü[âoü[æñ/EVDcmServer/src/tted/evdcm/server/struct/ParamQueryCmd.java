/*************************************************************************
 **
 * File Name		ParamQueryData.java
 * File Summary		command used to query the EVDCM parameters
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-12
 **************************************************************************/
package tted.evdcm.server.struct;

import java.util.ArrayList;

public class ParamQueryCmd {
	String mDateTime;
	int mCount;
	ArrayList<Integer> mParamIds;

	public ParamQueryCmd(DcmParam dp) {
		// 根据当前时间填写mDateTime
		// 根据DcmParam包的设置值，填写mCount值和mParamIds值
	}

	static public ParamQueryCmd fromBytesToPacket(byte[] byteStream) {
		return null;
	}

	Byte[] fromPacketToBytes() {
		return null;
	}

}
