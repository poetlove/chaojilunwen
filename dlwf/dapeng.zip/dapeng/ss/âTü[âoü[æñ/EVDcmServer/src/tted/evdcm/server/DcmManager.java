/*************************************************************************
 **
 * File Name		DcmManager.java
 * File Summary		The control and management of EVDCM
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.net.Socket;
import java.util.ArrayList;

import tted.evdcm.server.struct.DataPacket;
import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.DcmParam;
import tted.evdcm.server.struct.DcmParamData;
import tted.evdcm.server.struct.ParamItem;
import tted.evdcm.server.struct.ParamQueryData;
import tted.evdcm.server.struct.ParamSetData;
import tted.evdcm.server.struct.RegistData;
import tted.evdcm.server.struct.TimerEventPacket;

public class DcmManager {
	/**
	 * process the data from DCM.
	 * 
	 * @param sk
	 *            socket instance.
	 * @param byteBuffer
	 *            data from DCM.
	 * @return true if send data success, else false
	 */
	static public boolean fromDcmDataPacketProcess(Socket sk, byte[] byteBuffer) {
		DataPacket dp = new DataPacket();
		int cmd = DataManager.fromDcmDataPacketCheck(byteBuffer, dp);
		switch (cmd) {
		case DataManager.CMD_REGIST:
		{
			boolean ret = DataManager.dataProcess(null, dp,
					DataManager.CMD_REGIST);
			RegistData registData = RegistData.fromBytesToPacket(dp.getData());
			DataManager.saveSocketInList(registData.getCarNumber(), sk);
			DcmLocalParam dlp = new DcmLocalParam();
			dlp.init();
			DataManager.saveDcmLocalParamInList(registData.getCarNumber(), dlp);
			if (ret) {
				byte[] buffer = DataManager.responsePacketSet(cmd);
				ConnectManager.toDcmDataPacketSend(sk, buffer);
				return true;
			} else {
				return false;
			}
		}
		case DataManager.CMD_QUERY:
		{
			DcmParamData dcmParamData = DcmParamData.fromBytesToPacket(dp.getData());
			if(dcmParamData == null) {
				return false;
			}
			String carNumber = DataManager.getStringBySocket(sk);
			if(carNumber == null) {
				return false;
			}
			DcmLocalParam dcmLocalParam = DataManager.getDcmLocalParamByString(carNumber);
			if(dcmLocalParam == null) {
				return false;
			}
			int cnt = dcmParamData.getCount();
			ArrayList<ParamItem> pis = dcmParamData.getParamItems();
			for(int i=0; i<cnt; i++) {
				ParamItem pi = pis.get(i);
				if(pi.getParamId() == DcmParam.PID_DCM_RESPONE_TIME) {
					dcmLocalParam.setDcmResponseTime(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_DCM_HEART_PERI) {
					dcmLocalParam.setHeartPeriod(pi.getParamInt());
				}
			}
			TimerEventPacket timerEventPacket  = TimerManager.timerQueueRemove(carNumber);
			if(timerEventPacket != null) {
				timerEventPacket.getServerInterface().callFunc(dcmParamData);
			}
			return true;
		}
		case DataManager.CMD_SET:
		{
			ParamSetData paramSetData = ParamSetData.fromBytesToPacket(dp.getData());
			if(paramSetData == null) {
				return false;
			}
			String carNumber = DataManager.getStringBySocket(sk);
			if(carNumber == null) {
				return false;
			}
			DcmLocalParam dcmLocalParam = DataManager.getDcmLocalParamByString(carNumber);
			if(dcmLocalParam == null) {
				return false;
			}
			int cnt = paramSetData.getCount();
			ArrayList<ParamItem> pis = paramSetData.getParamItems();
			for(int i=0; i<cnt; i++) {
				ParamItem pi = pis.get(i);
				if(pi.getParamId() == DcmParam.PID_DCM_RESPONE_TIME) {
					dcmLocalParam.setDcmResponseTime(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_DCM_HEART_PERI) {
					dcmLocalParam.setHeartPeriod(pi.getParamInt());
				}
			}
			TimerEventPacket timerEventPacket  = TimerManager.timerQueueRemove(carNumber);
			if(timerEventPacket != null) {
				// none
			}
			return true;
		}
		case DataManager.CMD_DCM_CONTROL:
		{
			return true;
		}
		case DataManager.CMD_REAL_TIME:
		{
			String carNumber = DataManager.getStringBySocket(sk);
			if(carNumber == null) {
				return false;
			}
			DataManager.dataProcess(carNumber, dp, DataManager.CMD_REAL_TIME);
			return true;
		}
		case DataManager.CMD_STATUS:
		{
			return true;
		}
		case DataManager.CMD_HEART:
		{
			String carNumber = DataManager.getStringBySocket(sk);
	        if(carNumber != null) {
	        	DcmLocalParam dcmLocalParam = DataManager.getDcmLocalParamByString(carNumber);
	        	if(dcmLocalParam == null) {
					return false;
				}
	        	dcmLocalParam.setServerHeartCount(0);
	        } 
	        return true;
		}
		default:
			return false;
				
		}
	}
	
	/**
	 * To obtain the EVDCM's parameters.
	 * 
	 * @param dp
	 *            class used to set or get EVDCM's parameters.
	 * @param si
	 *            calls this interface to get parameters from EVDCM.
	 * @return true if set data success, else false
	 */
	static public boolean dcmParamDataGet(final DcmParam dp, ServerInterface si) {
		TimerEventPacket timerEventPacket = new TimerEventPacket();
		timerEventPacket.setCarNumber(dp.getCarNumber());
		timerEventPacket.setServerInterface(si);
		timerEventPacket.setTimeCount(0);
		DcmLocalParam dcmLocalParam = DataManager.getDcmLocalParamByString(dp
				.getCarNumber());
		timerEventPacket.setMaxPeriod(dcmLocalParam.getDcmResponseTime() * 10);
		timerEventPacket.setLoopCount(3);
		timerEventPacket.setThread(new Thread() {
			public void run() {
				ParamQueryData pqd = new ParamQueryData(dp);
				Socket sk = DataManager.getSocketByString(dp.getCarNumber());
				byte[] bf = DataManager.dcmParamPacketSet(DataManager.CMD_QUERY,
						pqd.fromPacketToBytes());
				ConnectManager.toDcmDataPacketSend(sk, bf);
			}
		});
		TimerManager.timerQueueAdd(timerEventPacket);
		return true;
	}
	
	/**
	 * To set the EVDCM's parameters.
	 * 
	 * @param dp
	 *            class used to set or get EVDCM's parameters.
	 * @return true if set data success, else false
	 */
	static public boolean dcmParamDataSet(final DcmParam dp) {
		TimerEventPacket timerEventPacket = new TimerEventPacket();
		timerEventPacket.setCarNumber(dp.getCarNumber());
		timerEventPacket.setServerInterface(null);
		timerEventPacket.setTimeCount(0);
		DcmLocalParam dcmLocalParam = DataManager.getDcmLocalParamByString(dp
				.getCarNumber());
		timerEventPacket.setMaxPeriod(dcmLocalParam.getDcmResponseTime() * 10);
		timerEventPacket.setLoopCount(3);
		timerEventPacket.setThread(new Thread() {
			public void run() {
				ParamSetData psd = new ParamSetData(dp);
				Socket sk = DataManager.getSocketByString(dp.getCarNumber());
				byte[] bf = DataManager.dcmParamPacketSet(DataManager.CMD_SET,
						psd.fromPacketToBytes());
				ConnectManager.toDcmDataPacketSend(sk, bf);
			}
		});
		TimerManager.timerQueueAdd(timerEventPacket);
		return true;
	}
	
	/**
	 * To control the EVDCM.
	 * 
	 * @param dp
	 *            class used to control EVDCM.
	 * @return true if set data success, else false
	 */
	static public boolean dcmTerminalCtrl(DcmParam dp) {
		return true;
	}
}
