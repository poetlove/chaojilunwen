package tted.evdcm.server.struct;

public class StatusData {
	String mCarNumber;
	String mDateTime;
	int mStatus;
	Byte[] mReserve;

	static public StatusData fromBytesToPacket(String carNumber, byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
