package tted.evdcm.server.struct;

import java.util.ArrayList;

public class RealTimeVoltageData {
	String mCarNumber;
	String mDateTime;
	int mBatteryCount;
	int mBatteryPackCount;
	ArrayList<VoltagePacket> mVoltagePacket;

	static public RealTimeVoltageData fromBytesToPacket(String carNumber, byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
