/*************************************************************************
 **
 * File Name		DcmParam.java
 * File Summary		Set or get EVDCM's parameters
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

public class DcmParam {
	public static final int CMD_NONE = 0x00;
	public static final int CMD_QUERY = 0x01;
	public static final int CMD_SET = 0x02;
	
	public static final int PID_DCM_STORE_PERI = 0x01;
	public static final int PID_DCM_INFO_REP_PERI = 0x02;
	public static final int PID_ALARM_INFO_REP_PERI = 0x03;
	public static final int PID_PLATFORM_IP = 0x04;
	public static final int PID_PLATFORM_PORT = 0x05;
	public static final int PID_DCM_HW_VERSION = 0x06;
	public static final int PID_DCM_FW_VERSION = 0x07;
	public static final int PID_DCM_HEART_PERI = 0x08;
	public static final int PID_DCM_RESPONE_TIME = 0x09;
	public static final int PID_SERVER_RESPONE_TIME = 0x0A;
	
	public static final int CTRLID_REMOTE_UPDATE = 0x01;
	public static final int CTRLID_DCM_SHUTDOWN = 0x02;
	public static final int CTRLID_DCM_RESET = 0x03;
	public static final int CTRLID_DCM_RESTORE_SETTINGS = 0x04;
	public static final int CTRLID_CLOSE_CONNECTION = 0x05;
	public static final int CTRLID_DCM_ALARM = 0x06;
	
	public DcmParam() {
		mCarNumber = "";
		mDateTime = "";
		mBoolDcmStoragePeriod = CMD_NONE;
		mValueDcmStoragePeriod = 0;
		mBoolDcmInfoReportPeriod = CMD_NONE;
		mValueDcmInfoReportPeriod = 0;
		mBoolDcmAlarmInfoReportPeriod = CMD_NONE;
		mValueDcmAlarmInfoReportPeriod = 0;
		mBoolIntegratedPlatformIP = CMD_NONE;
		mValueIntegratedPlatformIP = null;
		mBoolIntegratedPlatformPort = CMD_NONE;
		mValueIntegratedPlatformPort = 0;
		mBoolDcmHardwareVersion = CMD_NONE;
		mValueDcmHardwareVersion = "";
		mBoolDcmFirmwareVersion = CMD_NONE;
		mValueDcmFirmwareVersion = "";
		mBoolDcmHeartPeriod = CMD_NONE;
		mValueDcmHeartPeriod = 0;
		mBoolDcmResponseTime = CMD_NONE;
		mValueDcmResponseTime = 0;
		mBoolServerResponseTime = CMD_NONE;
		mValueServerResponseTime = 0;
		
		mBoolRemoteUpdate = false;
		mValueRemoteUpdate = null;
		mBoolDcmShutdown = false;
		mBoolDcmReset = false;
		mBoolDcmRestoreFactorySettings = false;
		mBoolCloseConnection = false;
		mBoolDcmAlarm = false;
		mValueDcmAlarm = null;
	}
	
	String mCarNumber;
	String mDateTime;
	
	// 查询参数 设置参数
	int mBoolDcmStoragePeriod; // 0x00表示此参数无处理，0x01表示查询，0x02表示设置
	int mValueDcmStoragePeriod; // 参数设置时使用，用来保存设置值
	int mBoolDcmInfoReportPeriod;
	int mValueDcmInfoReportPeriod;
	int mBoolDcmAlarmInfoReportPeriod;
	int mValueDcmAlarmInfoReportPeriod;
	int mBoolIntegratedPlatformIP;
	byte[] mValueIntegratedPlatformIP;
	int mBoolIntegratedPlatformPort;
	int mValueIntegratedPlatformPort;
	int mBoolDcmHardwareVersion;
	String mValueDcmHardwareVersion;
	int mBoolDcmFirmwareVersion;
	String mValueDcmFirmwareVersion;
	int mBoolDcmHeartPeriod;
	int mValueDcmHeartPeriod;
	int mBoolDcmResponseTime;
	int mValueDcmResponseTime;
	int mBoolServerResponseTime;
	int mValueServerResponseTime;

	// 控制参数
	boolean mBoolRemoteUpdate;
	RemoteUpdate mValueRemoteUpdate;
	boolean mBoolDcmShutdown;
	boolean mBoolDcmReset;
	boolean mBoolDcmRestoreFactorySettings;
	boolean mBoolCloseConnection;
	boolean mBoolDcmAlarm;
	DcmAlarm mValueDcmAlarm;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}
	public String getCarNumber() {
		return mCarNumber;
	}
	public void setDateTime(String dt) {
		mDateTime = dt;
	}
	public String getDateTime() {
		return mDateTime;
	}
	public void setBoolDcmStoragePeriod(int setCmd) {
		mBoolDcmStoragePeriod =  setCmd;
	}
	public int getBoolDcmStoragePeriod() {
		return mBoolDcmStoragePeriod;
	}
	public void setValueDcmStoragePeriod(int period) {
		mValueDcmStoragePeriod =  period;
	}
	public int getValueDcmStoragePeriod() {
		return mValueDcmStoragePeriod;
	}
	public void setBoolDcmInfoReportPeriod(int setCmd) {
		mBoolDcmInfoReportPeriod =  setCmd;
	}
	public int getBoolDcmInfoReportPeriod() {
		return mBoolDcmInfoReportPeriod;
	}
	public void setValueDcmInfoReportPeriod(int period) {
		mValueDcmInfoReportPeriod =  period;
	}
	public int getValueDcmInfoReportPeriod() {
		return mValueDcmInfoReportPeriod;
	}
	public void setBoolDcmAlarmInfoReportPeriod(int setCmd) {
		mBoolDcmAlarmInfoReportPeriod = setCmd;
	}
	public int getBoolDcmAlarmInfoReportPeriod() {
		return mBoolDcmAlarmInfoReportPeriod;
	}
	public void setValueDcmAlarmInfoReportPeriod(int period) {
		mValueDcmAlarmInfoReportPeriod = period;
	}
	public int getValueDcmAlarmInfoReportPeriod() {
		return mValueDcmAlarmInfoReportPeriod;
	}
	public void setBoolIntegratedPlatformIP(int setCmd) {
		mBoolIntegratedPlatformIP = setCmd;
	}
	public int getBoolIntegratedPlatformIP() {
		return mBoolIntegratedPlatformIP;
	}
	public void setValueIntegratedPlatformIP(byte[] ip) {
		mValueIntegratedPlatformIP = ip;
	}
	public byte[] getValueIntegratedPlatformIP() {
		return mValueIntegratedPlatformIP;
	}
	public void setBoolIntegratedPlatformPort(int setCmd) {
		mBoolIntegratedPlatformPort =  setCmd;
	}
	public int getBoolIntegratedPlatformPort() {
		return mBoolIntegratedPlatformPort;
	}
	public void setValueIntegratedPlatformPort(int period) {
		mValueIntegratedPlatformPort =  period;
	}
	public int getValueIntegratedPlatformPort() {
		return mValueIntegratedPlatformPort;
	}
	public void setBoolDcmHardwareVersion(int setCmd) {
		mBoolDcmHardwareVersion =  setCmd;
	}
	public int getBoolDcmHardwareVersion() {
		return mBoolDcmHardwareVersion;
	}
	public void setValueDcmHardwareVersion(String num) {
		mValueDcmHardwareVersion = num;
	}
	public String getValueDcmHardwareVersion() {
		return mValueDcmHardwareVersion;
	}
	public void setBoolDcmFirmwareVersion(int setCmd) {
		mBoolDcmFirmwareVersion =  setCmd;
	}
	public int getBoolDcmFirmwareVersion() {
		return mBoolDcmFirmwareVersion;
	}
	public void setValueDcmFirmwareVersion(String num) {
		mValueDcmFirmwareVersion = num;
	}
	public String getValueDcmFirmwareVersion() {
		return mValueDcmFirmwareVersion;
	}
	public void setBoolDcmHeartPeriod(int setCmd) {
		mBoolDcmHeartPeriod =  setCmd;
	}
	public int getBoolDcmHeartPeriod() {
		return mBoolDcmHeartPeriod;
	}
	public void setValueDcmHeartPeriod(int period) {
		mValueDcmHeartPeriod =  period;
	}
	public int getValueDcmHeartPeriod() {
		return mValueDcmHeartPeriod;
	}
	public void setBoolDcmResponseTime(int setCmd) {
		mBoolDcmResponseTime =  setCmd;
	}
	public int getBoolDcmResponseTime() {
		return mBoolDcmResponseTime;
	}
	public void setValueDcmResponseTime(int period) {
		mValueDcmResponseTime =  period;
	}
	public int getValueDcmResponseTime() {
		return mValueDcmResponseTime;
	}
	public void setBoolServerResponseTime(int setCmd) {
		mBoolServerResponseTime =  setCmd;
	}
	public int getBoolServerResponseTime() {
		return mBoolServerResponseTime;
	}
	public void setValueServerResponseTime(int period) {
		mValueServerResponseTime =  period;
	}
	public int getValueServerResponseTime() {
		return mValueServerResponseTime;
	}
	public void setBoolRemoteUpdate(boolean update) {
		mBoolRemoteUpdate = update;
	}
	public boolean getBoolRemoteUpdate() {
		return mBoolRemoteUpdate;
	}
	public void setValueRemoteUpdate(RemoteUpdate update) {
		mValueRemoteUpdate = update;
	}
	public RemoteUpdate getValueRemoteUpdate() {
		return mValueRemoteUpdate;
	}
	public void setBoolDcmShutdown(boolean shutdown) {
		mBoolDcmShutdown = shutdown;
	}
	public boolean getBoolDcmShutdown() {
		return mBoolDcmShutdown;
	}
	public void setBoolDcmReset(boolean reset) {
		mBoolDcmReset = reset;
	}
	public boolean getBoolDcmReset() {
		return mBoolDcmReset;
	}
	public void setBoolDcmRestoreFactorySettings(boolean restore) {
		mBoolDcmRestoreFactorySettings = restore;
	}
	public boolean getBoolDcmRestoreFactorySettings() {
		return mBoolDcmRestoreFactorySettings;
	}
	public void setBoolCloseConnection(boolean close) {
		mBoolCloseConnection = close;
	}
	public boolean getBoolCloseConnection() {
		return mBoolCloseConnection;
	}
	public void setBoolDcmAlarm(boolean alarm) {
		mBoolDcmAlarm = alarm;
	}
	public boolean getBoolDcmAlarm() {
		return mBoolDcmAlarm;
	}
	public void setValueDcmAlarm(DcmAlarm da) {
		mValueDcmAlarm = da;
	}
	public DcmAlarm getValueDcmAlarm() {
		return mValueDcmAlarm;
	}
}
