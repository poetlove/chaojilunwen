package tted.evdcm.server.struct;

public class DcmLocalParam {
	int mDcmResponseTime; // 单位是秒 终端应答超时时间
	int mHeartPeriod; // 单位是秒  车载终端心跳发送周期
	int mServerHeartCount; // 单位是0.1秒 从上一次心跳到达当前的时间

	public void setDcmResponseTime(int time) {
		mDcmResponseTime = time;
	}
	public int getDcmResponseTime() {
		return mDcmResponseTime;
	}
	public void setHeartPeriod(int period) {
		mHeartPeriod = period;
	}
	public int getHeartPeriod() {
		return mHeartPeriod;
	}
	public void setServerHeartCount(int cnt) {
		mServerHeartCount = cnt;
	}
	public int getServerHeartCount() {
		return mServerHeartCount;
	}
	
	public void init() {
		mDcmResponseTime = 10;
		mHeartPeriod = 10;
		mServerHeartCount = 0;
	}

}
