package tted.evdcm.server.struct;

import java.util.ArrayList;

public class RegistData {
	String mDateTime;
	int mRegistNumber;
	String mCarNumber;
	String mCarTerminalNumber;
	int mBatteryPackCount;
	ArrayList<BatteryPacket> mBatteryPacket;
	byte[] mReserve;

	public void setDateTime(String dt) {
		mDateTime = dt;
	}
	public String getDateTime() {
		return mDateTime;
	}
	public void setRegistNumber(int num) {
		mRegistNumber = num;
	}
	public int getRegistNumber() {
		return mRegistNumber;
	}
	public void setCarNumber(String num) {
		mCarNumber = num;
	}
	public String getCarNumber() {
		return mCarNumber;
	}
	public void setCarTerminalNumber(String num) {
		mCarTerminalNumber = num;
	}
	public String getCarTerminalNumber() {
		return mCarTerminalNumber;
	}
	public void setBatteryPackCount(int cnt) {
		mBatteryPackCount = cnt;
	}
	public int getBatteryPackCount() {
		return mBatteryPackCount;
	}
	
	static public RegistData fromBytesToPacket(byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
