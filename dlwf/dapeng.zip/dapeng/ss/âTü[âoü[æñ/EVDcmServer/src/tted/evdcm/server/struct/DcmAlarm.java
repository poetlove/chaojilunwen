package tted.evdcm.server.struct;

public class DcmAlarm {
	int mAlarmLevel;
	public void setAlarmLevel(int lvl) {
		mAlarmLevel = lvl;
	}
	public int getAlarmLevel() {
		return mAlarmLevel;
	}
}
