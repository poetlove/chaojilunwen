/*************************************************************************
 **
 * File Name		ParamQueryData.java
 * File Summary		used to get the EVDCM parameters
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;

public class DcmParamData {
	String mDateTime;
	int mCount;
	ArrayList<ParamItem> mParamItems;
	
	public String getDateTime() {
		return mDateTime;
	}
	public int getCount() {
		return mCount;
	}
	public ArrayList<ParamItem> getParamItems() {
		return mParamItems;
	}
	static public DcmParamData fromBytesToPacket(byte[] byteStream) {
		DcmParamData dpd = new DcmParamData();
		DataInputStream dataInputStream = new DataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			dpd.mDateTime = Common.strFromBytes(dt);
			dpd.mCount = dataInputStream.readByte();

			int bsSize = byteStream.length;
			if ((dpd.mCount > 0) && (bsSize > (6 + 1))) {
				dpd.mParamItems = new ArrayList<ParamItem>();
				ParamItem pi;
				int paramSize = bsSize - (6 + 1);
				while (paramSize > 0) {
					int cmdId = dataInputStream.readByte();
					if (cmdId == DcmParam.PID_DCM_STORE_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_DCM_INFO_REP_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_ALARM_INFO_REP_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_PLATFORM_IP) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] ip = new byte[6];
						dataInputStream.read(ip);
						pi.setParamString(Common.ipFromBytes(ip));
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 6);
					} else if (cmdId == DcmParam.PID_PLATFORM_PORT) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_DCM_HW_VERSION) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] str = new byte[5];
						dataInputStream.read(str);
						pi.setParamString(Common.strFromBytes(str));
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 5);
					} else if (cmdId == DcmParam.PID_DCM_FW_VERSION) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] str = new byte[5];
						dataInputStream.read(str);
						pi.setParamString(Common.strFromBytes(str));
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 5);
					} else if (cmdId == DcmParam.PID_DCM_HEART_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readByte());
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 1);
					} else if (cmdId == DcmParam.PID_DCM_RESPONE_TIME) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_SERVER_RESPONE_TIME) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						dpd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					}
				}
				if(dpd.mCount != dpd.mParamItems.size()) {
					return null;
				}
			}

			return dpd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
