/*************************************************************************
 **
 * File Name		ConnectManager.java
 * File Summary		Communicate with EVDCM
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class ConnectManager {
	public static class Thread_read extends Thread {
		Socket mSocket = null;
		InputStream mRead = null;

		public Thread_read(Socket sk) {
			try {
				mRead = sk.getInputStream();
				mSocket = sk;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public Socket getSocket() {
			return mSocket;
		}

		public void run() {
			try {
				while (true) {
					int size = mRead.available();
					byte[] b = new byte[size];

					int rt = mRead.read(b);
					DcmManager.fromDcmDataPacketProcess(mSocket, b);
					
					if(rt == -1) {
						ConnectManager.withDcmSocketClose(mSocket);
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
	
	/**
	 * send data to DCM.
	 * 
	 * @param sk
	 *            socket instance.
	 * @param sdData
	 *            data from DCM.
	 * @return true if send data success, else false
	 */
	static public boolean toDcmDataPacketSend(Socket sk, byte[] sdData) {
		return true;
	}
	
	/**
	 * close socket with DCM.
	 * 
	 * @param sk
	 *            socket instance.
	 * @return true if close success, else false
	 */
	static public boolean withDcmSocketClose(Socket sk) {
		return true;
	}

}
