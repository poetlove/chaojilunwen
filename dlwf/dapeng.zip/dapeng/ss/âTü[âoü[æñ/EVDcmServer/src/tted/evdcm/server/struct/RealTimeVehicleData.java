package tted.evdcm.server.struct;

public class RealTimeVehicleData {
	String mCarNumber;
	String mDateTime;
	int mSpeed;
	int mMileage;
	int mGear;
	int mAcceleratedPedalTrip;
	int mBrakePedalTrip;
	int mChargeStatus;
	int mMotorCntlTemperature;
	int mMotorSpeed;
	int mMotorTemperature;
	int mMotorVoltage;
	int mMotorCurrent;
	int mAirConditionTemperature;
	byte[] mReserve;

	static public RealTimeVehicleData fromBytesToPacket(String carNumber, byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
