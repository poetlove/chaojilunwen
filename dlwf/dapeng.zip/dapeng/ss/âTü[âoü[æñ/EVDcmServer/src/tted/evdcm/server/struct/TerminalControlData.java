package tted.evdcm.server.struct;

public class TerminalControlData {
	String mCarNumber;
	String mDateTime;
	int mCmdId;
	byte[] mParams;
}
