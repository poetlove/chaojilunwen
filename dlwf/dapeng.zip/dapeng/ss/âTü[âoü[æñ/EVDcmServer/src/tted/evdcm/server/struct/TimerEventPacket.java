package tted.evdcm.server.struct;

import tted.evdcm.server.ServerInterface;

public class TimerEventPacket {
	String mCarNumber;
	int mTimeCount; // 以0.1s为单位
	int mMaxPeriod;
	int mLoopCount;
	Thread mThread;
	ServerInterface mServerInterface;

	public void setCarNumber(String num) {
		mCarNumber = num;
	}
	public String getCarNumber() {
		return mCarNumber;
	}
	public void setTimeCount(int cnt) {
		mTimeCount = cnt;
	}
	public int getTimeCount() {
		return mTimeCount;
	}
	public void setLoopCount(int cnt) {
		mLoopCount = cnt;
	}
	public int getLoopCount() {
		return mLoopCount;
	}
	public void setMaxPeriod(int period) {
		mMaxPeriod = period;
	}
	public int getMaxPeriod() {
		return mMaxPeriod;
	}
	
	public void setThread(Thread th) {
		mThread = th;
	}
	public void setServerInterface(ServerInterface sif) {
		mServerInterface = sif;
	}
	public ServerInterface getServerInterface() {
		return mServerInterface;
	}
	
	public void schedule() {
		mThread.start();
	}

}
