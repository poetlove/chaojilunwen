/*************************************************************************
 **
 * File Name		DataManager.java
 * File Summary		Data processing
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.net.Socket;
import java.util.HashMap;

import tted.evdcm.server.struct.DataPacket;
import tted.evdcm.server.struct.DcmDataPacket;
import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.RealTimeAlarmData;
import tted.evdcm.server.struct.RegistData;
import tted.evdcm.server.utils.Common;

public class DataManager {
	static final int CMD_ERROR = -1;
	static final int CMD_REGIST = 0x01;
	static final int CMD_REAL_TIME = 0x02;
	static final int CMD_STATUS = 0x03;
	static final int CMD_HEART = 0x04;
	static final int CMD_REISSUED = 0x05;
	static final int CMD_QUERY = 0x80;
	static final int CMD_SET = 0x81;
	static final int CMD_DCM_CONTROL = 0x82;

	static final int RESPONSE_SUCCESS = 0x01;
	static final int RESPONSE_MODIFY_ERR = 0x02;
	static final int RESPONSE_CMD = 0xfe;

	static final int REAL_TIME_VOLTAGE = 0x01;
	static final int REAL_TIME_TEMPERATURE = 0x02;
	static final int REAL_TIME_VEHICLE = 0x03;
	static final int REAL_TIME_GPS = 0x04;
	static final int REAL_TIME_EXTERMUM = 0x05;
	static final int REAL_TIME_ALARM = 0x06;
	
	static HashMap<String, Socket> mSocketCarNumberMap  = new HashMap<String, Socket >();
	static HashMap<String, DcmLocalParam > mDcmLocalParamMap = new HashMap<String, DcmLocalParam >();
	/**
	 * Analysis and verification of EVDCM data.
	 * 
	 * @param indata
	 *            EVDCM data.
	 * @param outdata
	 *            data packet in EVDCM data.
	 * @return command id if check success, else CMD_ERROR
	 */
	static public int fromDcmDataPacketCheck(byte[] indata, DataPacket dp) {
		if (!bccCheck(indata)) {
			return CMD_ERROR;
		}
		
		DcmDataPacket dcmDataPacket = DcmDataPacket.fromBytesToPacket(indata);

		if (!basicCheck(dcmDataPacket)) {
			return CMD_ERROR;
		}

		switch (dcmDataPacket.getCmdFlag()) {
		case CMD_REGIST:
		{
			if (!registCheck(dcmDataPacket)) {
				return CMD_ERROR;
			} else {
				byte[] outdata = new byte[dcmDataPacket.getDataLength()];
				Common.memcpy(outdata, 0, indata, 24,
						dcmDataPacket.getDataLength());
				dp.setLength(dcmDataPacket.getDataLength());
				dp.setData(outdata);
				return CMD_REGIST;
			}
		}
		case CMD_REAL_TIME:
		{
			if (!realTimeDataCheck(dcmDataPacket)) {
				return CMD_ERROR;
			} else {
				byte[] outdata = new byte[dcmDataPacket.getDataLength()];
				Common.memcpy(outdata, 0, indata, 24,
						dcmDataPacket.getDataLength());
				dp.setLength(dcmDataPacket.getDataLength());
				dp.setData(outdata);
				return CMD_REAL_TIME;
			}

		}
		default:
			break;
		}
		return CMD_ERROR;
	}

	/**
	 * EVDCM data processing.
	 * 
	 * @param carNumber
	 *            License plate number.
	 * @param data
	 *            data packet in EVDCM data.
	 * @param command
	 *            the flag of command.
	 * @return command id if check success, else CMD_ERROR
	 */
	static public boolean dataProcess(String carNumber, DataPacket dp,
			int command) {
		switch(command) {
		case CMD_REGIST:
		{
			RegistData registData = RegistData.fromBytesToPacket(dp.getData());
			DBManager.registDataSave(registData);
			break;
		}
		case CMD_REAL_TIME:
		{
			return  realTimeDataProcess(carNumber, dp);
		}
		default:
	         return false;
		}
		return true;
	}
	
	/**
	 * The response to EVDCM.
	 * 
	 * @param command
	 *            the flag of command.
	 * @return The data of response
	 */
	static public byte[] responsePacketSet(int cmd) {
		return null;
	}
	
	/**
	 * The data send to EVDCM.
	 * 
	 * @param command
	 *            the flag of command.
	 * @param data
	 *            data packet in EVDCM data.
	 * @return The data send to EVDCM
	 */
	static public byte[] dcmParamPacketSet(int command, byte[] data) {
		return null;
	}
	
	/**
	 * get socket by license plate number.
	 * 
	 * @param carNumber
	 *            license plate number.
	 * @return The socket which car is logged in
	 */
	static public Socket getSocketByString(String carNumber) {
		return null;
	}
	
	/**
	 * get socket by license plate number.
	 * 
	 * @param sk
	 *            socket instance.
	 * @return license plate number
	 */
	static public String getStringBySocket(Socket sk) {
		return null;
	}
	
	/**
	 * save socket and license plate number to the list.
	 * 
	 * @param carNumber
	 *            license plate number.
	 * @param sk
	 *            socket instance.
	 * @return true if save data success, else false
	 */
	static public boolean saveSocketInList(String carNumber, Socket sk) {
		if (mSocketCarNumberMap.containsKey(carNumber)) {
			ConnectManager.withDcmSocketClose((Socket) mSocketCarNumberMap
					.get(carNumber));
			mSocketCarNumberMap.remove(carNumber);
		}
		mSocketCarNumberMap.put(carNumber, sk);
		return true;

	}
	
	/**
	 * delete socket and license plate number in the list.
	 * 
	 * @param carNumber
	 *            license plate number.
	 * @return true if delete data success, else false
	 */
	static public boolean deleteSocketInList(String carNumber) {
		return true;
	}
	
	/**
	 * to obtain the local parameters list on EVDCM.
	 * 
	 * @param null
	 *            
	 * @return EVDCM's local parameters list
	 */
	static public HashMap<String, DcmLocalParam > getDcmLocalParamList() {
		return mDcmLocalParamMap;
	}
	
	/**
	 * to get the local parameters by license plate number.
	 * 
	 * @param carNumber
	 *            license plate number.
	 * @return EVDCM's local parameters
	 */
	static public DcmLocalParam getDcmLocalParamByString(String carNumber) {
		return null;
	}
	
	/**
	 * save local parameters and license plate number to the list.
	 * 
	 * @param carNumber
	 *            license plate number.
	 * @param dlp
	 *            EVDCM's local parameters.
	 * @return true if save data success, else false
	 */
	static public boolean saveDcmLocalParamInList(String carNumber,
			DcmLocalParam dlp) {
		if (mDcmLocalParamMap.containsKey(carNumber)) {
			mDcmLocalParamMap.remove(carNumber);
		}
		mDcmLocalParamMap.put(carNumber, dlp);
		return true;

	}
	
	static byte getBcc(byte[] bf, int offset, int length) {
		byte bcc = 0;
		if (offset + length > bf.length) {
			return bcc;
		}
		for (int i = 0; i < length; i++) {
			bcc = (byte) (bcc ^ bf[offset + i]);
		}
		return bcc;
	}
	
	static boolean bccCheck(byte[] bf) {
		if(bf.length < 2) {
			return false;
		}
		
		byte calcBcc = getBcc(bf,0,bf.length-1);
		byte bcc = bf[bf.length-1];
	    if(calcBcc == bcc) {
	    	return true;
	    } else {
	    	return false;
	    }
	}
	
	static boolean basicCheck(DcmDataPacket dp) {
		if (!dp.getStartFlag().equals("##")) {
			return false;
		}
		if (!dp.getIdentifier().equals("")) {
			return false;
		}
		if (dp.getDataLength() != dp.getData().length) {
			return false;
		}
		return true;
	}

	static boolean registCheck(DcmDataPacket dp) {
		if (dp.getData().length != dp.getDataLength()) {
			return false;
		}
		return true;
	}
	static boolean realTimeDataCheck(DcmDataPacket dp) {
		if (dp.getData().length != dp.getDataLength()) {
			return false;
		}
		return true;
	}
	
	static boolean realTimeDataProcess(String carNumber, DataPacket dp) {
		byte[] b = dp.getData();
		switch (b[6]) {
		case REAL_TIME_VOLTAGE:
			// realTimeVoltageData =
			// RealTimeVoltageData.fromBytesToPacket(carNumber, data)
			// dbManagerRealTimeVoltageDataSave(realTimeVoltageData)
			break;
		case REAL_TIME_TEMPERATURE:
			// realTimeTemperatureData =
			// RealTimeTemperatureData.fromBytesToPacket(carNumber, data)
			// dbManagerRealTimeTemperatureDataSave(realTimeTemperatureData)
			break;
		case REAL_TIME_VEHICLE:
			// realTimeVehicleData =
			// RealTimeVehicleData.fromBytesToPacket(carNumber, data)
			// dbManagerRealTimeVehicleDataSave(realTimeVehicleData)
			break;
		case REAL_TIME_GPS:
			break;
		case REAL_TIME_EXTERMUM:
			break;
		case REAL_TIME_ALARM:
		{
			RealTimeAlarmData realTimeAlarmData = RealTimeAlarmData.fromBytesToPacket(carNumber, b, 0);
			DBManager.realTimeAlarmDataSave(realTimeAlarmData);
			break;
		}
		default:
			return false;
		}
		return true;

	}

}
