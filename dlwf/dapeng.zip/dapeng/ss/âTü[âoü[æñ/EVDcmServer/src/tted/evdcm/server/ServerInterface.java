/*************************************************************************
 **
 * File Name		ServerInterface.java
 * File Summary		server's interface
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import tted.evdcm.server.struct.DcmParamData;

public interface ServerInterface {
	public void callFunc(DcmParamData pqd);
}
