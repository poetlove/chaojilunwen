package tted.evdcm.server.struct;

import java.util.ArrayList;

public class VoltagePacket {
	String mBatteryPacketSequence;
	int mBatteryCount;
	int mBatteryPackCount;
	ArrayList<Integer> mVoltageValues;

	static public VoltagePacket fromBytesToPacket(byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
