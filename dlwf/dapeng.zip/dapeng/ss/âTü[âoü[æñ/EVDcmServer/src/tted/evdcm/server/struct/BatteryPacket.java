package tted.evdcm.server.struct;

public class BatteryPacket {
	int mBatteryPackNumber;
	String mPackEncodeMaker;
	int mPackEncodeBttyType;
	int mPackEncodeRatedEnery;
	int mPackEncodeRatedVoltage;
	String mPackEncodeMakeDate;
	int mSerialNumber;
	Byte[] mReserve;

	public void setBatteryPackNumber(int num) {
		mBatteryPackNumber = num;
	}
	public int getBatteryPackNumber() {
		return mBatteryPackNumber;
	}
	public void setPackEncodeMaker(String maker) {
		mPackEncodeMaker = maker;
	}
	public String getPackEncodeMaker() {
		return mPackEncodeMaker;
	}
	public void setPackEncodeBttyType(int type) {
		mPackEncodeBttyType = type;
	}
	public int getPackEncodeBttyType() {
		return mPackEncodeBttyType;
	}
	public void setPackEncodeRatedEnery(int enery) {
		mPackEncodeRatedEnery = enery;
	}
	public int getPackEncodeRatedEnery() {
		return mPackEncodeRatedEnery;
	}
	public void setPackEncodeRatedVoltage(int voltage) {
		mPackEncodeRatedVoltage = voltage;
	}
	public int getPackEncodeRatedVoltage() {
		return mPackEncodeRatedVoltage;
	}
	public void setPackEncodeMakeDate(String makerDate) {
		mPackEncodeMakeDate = makerDate;
	}
	public String getPackEncodeMakeDate() {
		return mPackEncodeMakeDate;
	}
	public void setSerialNumber(int num) {
		mSerialNumber = num;
	}
	public int getSerialNumber() {
		return mSerialNumber;
	}
	
	static public BatteryPacket fromBytesToPacket(byte[] byteStream) {
		return null;
	}

	Byte[] fromPacketToBytes() {
		return null;
	}

}
