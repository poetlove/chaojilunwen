package tted.evdcm.server.struct;

public class RealTimeExtremumData {
	String mCarNumber;
	String mDateTime;
	int mMaxVoltageBatteryPackNumber;
	int mMaxVoltageBatteryNumber;
	int mBatteryMaxVoltage;
	int mMinVoltageBatteryPackNumber;
	int mMinVoltageBatteryNumber;
	int mBatteryMinVoltage;
	int mMaxTempBatteryPackNumber;
	int mMaxTempProbeNumber;
	int mMaxTemperature;
	int mMinTempBatteryPackNumber;
	int mMinTempProbeNumber;
	int mMinTemperature;
	int mTotalVoltage;
	int mTotalCurrent;
	int mSOC;
	int mRemainEnergy;
	int mInsulationResistance;
	Byte[] mReserve;

	static public RealTimeExtremumData fromBytesToPacket(String carNumber, byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
