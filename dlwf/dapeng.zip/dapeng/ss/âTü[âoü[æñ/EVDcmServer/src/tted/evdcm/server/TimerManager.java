package tted.evdcm.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TimerTask;

import tted.evdcm.server.struct.DcmLocalParam;
import tted.evdcm.server.struct.TimerEventPacket;

public class TimerManager {
	static ArrayList<TimerEventPacket> timerEventPackets = new ArrayList<TimerEventPacket>();

	static TimerTask mTimerTask = new TimerTask() {
		public void run() {
			TimerManager.timeEventProcess();
		}
	};
	
	static public TimerTask getTimeTask() {
		return mTimerTask;
	}
	static public boolean timerQueueAdd(TimerEventPacket tep) {
		timerEventPackets.add(tep);
		return true;
	}

	static public TimerEventPacket timerQueueRemove(String carNumber) {
		if (timerEventPackets.isEmpty()) {
			return null;
		}
		int cnt = timerEventPackets.size();
		for (int i = 0; i < cnt; i++) {
			TimerEventPacket timerEventPacket = timerEventPackets.get(i);
			if (carNumber.equals(timerEventPacket.getCarNumber())) {
				timerEventPackets.remove(timerEventPacket);
				return timerEventPacket;
			}
		}
		return null;
	}

	static public boolean timeEventProcess() {
		HashMap<String, DcmLocalParam> dlps = DataManager
				.getDcmLocalParamList();
		if (!dlps.isEmpty()) {
			ArrayList<String> carNums = null;
			Iterator<String> iter = dlps.keySet().iterator();
			while (iter.hasNext()) {
				String carNumber = (String) iter.next();
				DcmLocalParam dlp = dlps.get(carNumber);
				int temp = dlp.getServerHeartCount();
				temp++;
				dlp.setServerHeartCount(temp);
				if (dlp.getServerHeartCount() >= dlp.getHeartPeriod() * 10) {
					carNums = new ArrayList<String>();
					carNums.add(carNumber);
					DataManager.deleteSocketInList(carNumber);
				}
			}
			if (carNums != null && carNums.size() > 0) {
				int cnt = carNums.size();
				for (int i = 0; i < cnt; i++) {
					dlps.remove(carNums.get(i));
				}
			}
		}
		// 下面内容是处理参数设置，查询，控制的代码
		if (!timerEventPackets.isEmpty()) {
			int cnt = timerEventPackets.size();
			for (int i = cnt - 1; i >= 0; i--) {
				TimerEventPacket timerEventPacket = timerEventPackets.get(i);
				if (timerEventPacket.getLoopCount() <= 0) {
					timerEventPackets.remove(timerEventPacket);
				}
			}

			cnt = timerEventPackets.size();
			for (int i = 0; i < cnt; i++) {
				TimerEventPacket timerEventPacket = timerEventPackets.get(i);
				if (timerEventPacket.getTimeCount() < timerEventPacket
						.getLoopCount()) {
					int temp = timerEventPacket.getTimeCount();
					temp++;
					timerEventPacket.setTimeCount(temp);
				} else {
					if (timerEventPacket.getLoopCount() > 0) {
						timerEventPacket.schedule();
						timerEventPacket.setTimeCount(0);
						int temp = timerEventPacket.getLoopCount();
						temp--;
						timerEventPacket.setLoopCount(temp);
					}
				}
			}
		}
		return true;
	}
}
