/*************************************************************************
 **
 * File Name		ParamQueryData.java
 * File Summary		EVDCM parameters
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-12
 **************************************************************************/
package tted.evdcm.server.struct;

public class ParamItem {
	int mParamId;
	int mParamInt;
	String mParamString;
	
	public ParamItem() {
		mParamId = 0;
		mParamInt = 0;
		mParamString = "";
	}
	
	public void setParamId(int id) {
		mParamId = id;
	}
	public int getParamId() {
		return mParamId;
	}
	public void setParamInt(int it) {
		mParamInt = it;
	}
	public int getParamInt() {
		return mParamInt;
	}
	public void setParamString(String param) {
		mParamString = param;
	}
	public String getParamString() {
		return mParamString;
	}
}
