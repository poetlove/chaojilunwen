/*************************************************************************
 **
 * File Name		ParamQueryData.java
 * File Summary		command used to query the EVDCM parameters
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-12
 **************************************************************************/
package tted.evdcm.server.struct;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;

public class ParamQueryData {
	String mCarNumber;
	String mDateTime;
	int mCount;
	ArrayList<Integer> mParamIds;

	public ParamQueryData(DcmParam dp) {
		mCarNumber = dp.getCarNumber();
		mDateTime = dp.getDateTime();
		mParamIds = new ArrayList<Integer>();
		if(dp.getBoolDcmStoragePeriod() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_DCM_STORE_PERI);
		}
		if(dp.getBoolDcmInfoReportPeriod() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_DCM_INFO_REP_PERI);
		}
		if(dp.getBoolDcmAlarmInfoReportPeriod() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_ALARM_INFO_REP_PERI);
		}
		if(dp.getBoolIntegratedPlatformIP() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_PLATFORM_IP);
		}
		if(dp.getBoolIntegratedPlatformPort() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_PLATFORM_PORT);
		}
		if(dp.getBoolDcmHardwareVersion() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_DCM_HW_VERSION);
		}
		if(dp.getBoolDcmFirmwareVersion() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_DCM_FW_VERSION);
		}
		if(dp.getBoolDcmHeartPeriod() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_DCM_HEART_PERI);
		}
		if(dp.getBoolDcmResponseTime() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_DCM_RESPONE_TIME);
		}
		if(dp.getBoolServerResponseTime() == DcmParam.CMD_QUERY) {
			mParamIds.add(DcmParam.PID_SERVER_RESPONE_TIME);
		}
		mCount = mParamIds.size();
		
	}

//	static public ParamQueryCmd fromBytesToPacket(byte[] byteStream) {
//		return null;
//	}

	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DataOutputStream dataOutputStream = new DataOutputStream(
				byteArrayOutputStream);
		try {
			byte[] dt = Common.dateTimeToBytes(mDateTime);
			dataOutputStream.write(dt, 0, dt.length);
			dataOutputStream.writeByte(mCount);
			
			byte[] paramIds = Common.getByteArrayByList(mParamIds);
			dataOutputStream.write(paramIds, 0, paramIds.length);

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
