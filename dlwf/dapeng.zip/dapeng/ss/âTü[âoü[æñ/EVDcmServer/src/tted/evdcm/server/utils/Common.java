package tted.evdcm.server.utils;

import java.util.ArrayList;
import java.util.Arrays;

public class Common {
	public static boolean mDebug;
	
	public static void zeroMemory(byte[] paramArrayOfByte) {
		Arrays.fill(paramArrayOfByte, (byte) 0x00);
	}
	
	public static void memcpy(byte[] destArrayOfByte, int destOffset, byte[] srcArrayOfByte, int srcOffset, int length) {
		System.arraycopy(srcArrayOfByte, srcOffset, destArrayOfByte, destOffset, length);
	}
	
	public static String ipFromBytes(byte[] ipBytes) {
		StringBuilder sb = new StringBuilder();
		for(byte b : ipBytes) {
			sb.append((int)b).append(".");
		}
		String retStr = sb.substring(0,sb.length()-2);
		return retStr;
	}
	
	public static byte[] ipToBytes(String ipString) {
		String[] sa = ipString.split(".");
		byte[] ipBytes = new byte[sa.length];
		for(int i=0; i<sa.length; i++) {
			ipBytes[i] = Byte.valueOf(sa[i]);
		}
		return ipBytes;
	}
	
	public static String dateTimeFromBytes(byte[] dateTimeBytes) {
		StringBuilder sb = new StringBuilder();
		for(byte b : dateTimeBytes) {
			sb.append((int)b).append("-");
		}
		String retStr = sb.substring(0,sb.length()-2);
		return retStr;
	}
	
	public static byte[] dateTimeToBytes(String dateTimeString) {
		String[] sa = dateTimeString.split("-");
		byte[] dateTimeBytes = new byte[sa.length];
		for(int i=0; i<sa.length; i++) {
			dateTimeBytes[i] = Byte.valueOf(sa[i]);
		}
		return dateTimeBytes;
	}
	
	public static String strFromBytes(byte[] b) {
		return new String(b);
	}
	
	public static byte[] strToBytes(String str) {
		return str.getBytes();
	}

	public static byte intToByte(int a) {
		byte res = (byte) a;
		return res;
	}

	public static int byteToInt(byte a) {
		int res = 0x00FF & a;
		return res;
	}

	public static byte getUnsignedByte(byte a) {
		int temp = 0x00FF & a;
		byte res = (byte) temp;
		return res;
	}
	
	public static byte[] getByteArrayByList(ArrayList<Integer> temp) {
		byte[] res = new byte[temp.size()];
		for (int i = 0; i < res.length; i++) {
			res[i] = intToByte(temp.get(i));
		}
		return res;
	}
}
