package tted.evdcm.server.struct;

public class RealTimeTemperatureData {
	String mCarNumber;
	String mDateTime;

	static public RealTimeTemperatureData fromBytesToPacket(String carNumber, byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
