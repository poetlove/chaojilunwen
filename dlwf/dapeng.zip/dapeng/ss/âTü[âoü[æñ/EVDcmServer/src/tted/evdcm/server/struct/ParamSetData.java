package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;

public class ParamSetData {
	String mCarNumber;
	String mDateTime;
	int mCount;
	ArrayList<ParamItem> mParamItems;

	public ParamSetData() {
		
	}
	
	public ParamSetData(DcmParam dp) {
		mCarNumber = dp.getCarNumber();
		mDateTime = dp.getDateTime();
		mParamItems = new ArrayList<ParamItem>();
		ParamItem pi;
		if(dp.getBoolDcmStoragePeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem(); 
			pi.setParamId(DcmParam.PID_DCM_STORE_PERI);
			pi.setParamInt(dp.getValueDcmStoragePeriod());
			mParamItems.add(pi);
		}
		if(dp.getBoolDcmInfoReportPeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_INFO_REP_PERI);
			pi.setParamInt(dp.getValueDcmInfoReportPeriod());
			mParamItems.add(pi);
		}
		if(dp.getBoolDcmAlarmInfoReportPeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_ALARM_INFO_REP_PERI);
			pi.setParamInt(dp.getValueDcmAlarmInfoReportPeriod());
			mParamItems.add(pi);
		}
		if(dp.getBoolIntegratedPlatformIP() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_PLATFORM_IP);
			pi.setParamString(Common.ipFromBytes(dp.getValueIntegratedPlatformIP()));
			mParamItems.add(pi);
		}
		if(dp.getBoolIntegratedPlatformPort() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_PLATFORM_PORT);
			pi.setParamInt(dp.getValueIntegratedPlatformPort());
			mParamItems.add(pi);
		}
		if(dp.getBoolDcmHardwareVersion() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_HW_VERSION);
			pi.setParamString(dp.getValueDcmHardwareVersion());
			mParamItems.add(pi);
		}
		if(dp.getBoolDcmFirmwareVersion() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_FW_VERSION);
			pi.setParamString(dp.getValueDcmFirmwareVersion());
			mParamItems.add(pi);
		}
		if(dp.getBoolDcmHeartPeriod() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_HEART_PERI);
			pi.setParamInt(dp.getValueDcmHeartPeriod());
			mParamItems.add(pi);
		}
		if(dp.getBoolDcmResponseTime() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_DCM_RESPONE_TIME);
			pi.setParamInt(dp.getValueDcmResponseTime());
			mParamItems.add(pi);
		}
		if(dp.getBoolServerResponseTime() == DcmParam.CMD_SET) {
			pi = new ParamItem();
			pi.setParamId(DcmParam.PID_SERVER_RESPONE_TIME);
			pi.setParamInt(dp.getValueServerResponseTime());
			mParamItems.add(pi);
		}
		mCount = mParamItems.size();
	}

	public String getCarNumber() {
		return mCarNumber;
	}
	public String getDateTime() {
		return mDateTime;
	}
	public int getCount() {
		return mCount;
	}
	public ArrayList<ParamItem> getParamItems() {
		return mParamItems;
	}
	
	static public ParamSetData fromBytesToPacket(byte[] byteStream) {
		ParamSetData psd = new ParamSetData();
		DataInputStream dataInputStream = new DataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			psd.mDateTime = Common.strFromBytes(dt);
			psd.mCount = dataInputStream.readByte();

			int bsSize = byteStream.length;
			if ((psd.mCount > 0) && (bsSize > (6 + 1))) {
				psd.mParamItems = new ArrayList<ParamItem>();
				ParamItem pi;
				int paramSize = bsSize - (6 + 1);
				while (paramSize > 0) {
					int cmdId = dataInputStream.readByte();
					if (cmdId == DcmParam.PID_DCM_STORE_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_DCM_INFO_REP_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_ALARM_INFO_REP_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_PLATFORM_IP) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] ip = new byte[6];
						dataInputStream.read(ip);
						pi.setParamString(Common.ipFromBytes(ip));
						psd.mParamItems.add(pi);
						paramSize -= (1 + 6);
					} else if (cmdId == DcmParam.PID_PLATFORM_PORT) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_DCM_HW_VERSION) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] str = new byte[5];
						dataInputStream.read(str);
						pi.setParamString(Common.strFromBytes(str));
						psd.mParamItems.add(pi);
						paramSize -= (1 + 5);
					} else if (cmdId == DcmParam.PID_DCM_FW_VERSION) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						byte[] str = new byte[5];
						dataInputStream.read(str);
						pi.setParamString(Common.strFromBytes(str));
						psd.mParamItems.add(pi);
						paramSize -= (1 + 5);
					} else if (cmdId == DcmParam.PID_DCM_HEART_PERI) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readByte());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 1);
					} else if (cmdId == DcmParam.PID_DCM_RESPONE_TIME) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					} else if (cmdId == DcmParam.PID_SERVER_RESPONE_TIME) {
						pi = new ParamItem();
						pi.setParamId(cmdId);
						pi.setParamInt(dataInputStream.readShort());
						psd.mParamItems.add(pi);
						paramSize -= (1 + 2);
					}
				}
				if(psd.mCount != psd.mParamItems.size()) {
					return null;
				}
			}

			return psd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public byte[] fromPacketToBytes() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		DataOutputStream dataOutputStream = new DataOutputStream(
				byteArrayOutputStream);
		try {
			byte[] dt = Common.dateTimeToBytes(mDateTime);
			dataOutputStream.write(dt, 0, dt.length);
			dataOutputStream.writeByte(mCount);
			
			int cnt = mParamItems.size();
			for(int i=0; i<cnt; i++) {
				ParamItem pi = mParamItems.get(i);
				if(pi.getParamId() == DcmParam.PID_DCM_STORE_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_DCM_INFO_REP_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_ALARM_INFO_REP_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_PLATFORM_IP) {
					dataOutputStream.writeByte(pi.getParamId());
					String str = pi.getParamString();
					byte[] ip = Common.ipToBytes(str);
					dataOutputStream.write(ip, 0, ip.length);
				} else if(pi.getParamId() == DcmParam.PID_PLATFORM_PORT) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_DCM_HW_VERSION) {
					dataOutputStream.writeByte(pi.getParamId());
					String str = pi.getParamString();
					byte[] b = Common.strToBytes(str);
					dataOutputStream.write(b, 0, b.length);
				} else if(pi.getParamId() == DcmParam.PID_DCM_FW_VERSION) {
					dataOutputStream.writeByte(pi.getParamId());
					String str = pi.getParamString();
					byte[] b = Common.strToBytes(str);
					dataOutputStream.write(b, 0, b.length);
				} else if(pi.getParamId() == DcmParam.PID_DCM_HEART_PERI) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_DCM_RESPONE_TIME) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				} else if(pi.getParamId() == DcmParam.PID_SERVER_RESPONE_TIME) {
					dataOutputStream.writeByte(pi.getParamId());
					dataOutputStream.writeShort(pi.getParamInt());
				}
			}

			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
