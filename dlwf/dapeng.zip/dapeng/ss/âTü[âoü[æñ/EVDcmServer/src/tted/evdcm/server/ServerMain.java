/*************************************************************************
 **
 * File Name		ServerMain.java
 * File Summary		main of EVDCM servlet
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-10
 **************************************************************************/
package tted.evdcm.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class ServerMain extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		DBManager.getDbThread().start();
		new Timer().scheduleAtFixedRate(TimerManager.getTimeTask(), 0, 100);
		Thread_server ss = new Thread_server(1234);
		if (ss != null && ss.getServerSocket() != null) {
			ss.start();
		}

	}

	public class Thread_server extends Thread {
		ServerSocket mServerSocket = null;

		public Thread_server(int port) {
			try {
				mServerSocket = new ServerSocket(port);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public ServerSocket getServerSocket() {
			return mServerSocket;
		}

		public void run() {
			Socket sk;
			try {
				sk = mServerSocket.accept();
				ConnectManager.Thread_read thrd = new ConnectManager.Thread_read(sk);
				if (thrd != null && thrd.getSocket() != null) {
					thrd.start();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	

}
