package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.util.ArrayList;

import tted.evdcm.server.utils.Common;

public class RealTimeAlarmData {
	String mCarNumber;
	String mDateTime;
	
	int mInfoTypeFlag;
	
	int mBatteryAlarmFlag;
	int mBatteryOtherFaultsCnt;
	ArrayList<Integer> mBatteryOtherFaultCodes;
	int mMotorFaultsCnt;
	ArrayList<Integer> mMotorFaultCodes;
	int mOtherFaultsCnt;
	ArrayList<Integer> mOtherFaultCodes;


	static public RealTimeAlarmData fromBytesToPacket(String carNumber, byte[] byteStream, int offset) {
		RealTimeAlarmData rtad = new RealTimeAlarmData();
		
		rtad.mCarNumber = carNumber;
		
		DataInputStream dataInputStream = new DataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] dt = new byte[6];
			dataInputStream.read(dt, 0, dt.length);
			rtad.mDateTime = Common.strFromBytes(dt);
			
			rtad.mInfoTypeFlag = dataInputStream.readByte();
			
			rtad.mBatteryAlarmFlag = dataInputStream.readShort();
			rtad.mBatteryOtherFaultsCnt = dataInputStream.readByte();
			if(rtad.mBatteryOtherFaultsCnt > 0) {
				rtad.mBatteryOtherFaultCodes = new ArrayList<Integer>();
				for(int i=0; i<rtad.mBatteryOtherFaultsCnt; i++) {
					rtad.mBatteryOtherFaultCodes.add((int) dataInputStream.readByte());
				}
			}
			rtad.mMotorFaultsCnt = dataInputStream.readByte();
			if(rtad.mMotorFaultsCnt > 0) {
				rtad.mMotorFaultCodes = new ArrayList<Integer>();
				for(int i=0; i<rtad.mMotorFaultsCnt; i++) {
					rtad.mMotorFaultCodes.add((int) dataInputStream.readByte());
				}
			}
			rtad.mOtherFaultsCnt = dataInputStream.readByte();
			if(rtad.mOtherFaultsCnt > 0) {
				rtad.mOtherFaultCodes = new ArrayList<Integer>();
				for(int i=0; i<rtad.mOtherFaultsCnt; i++) {
					rtad.mOtherFaultCodes.add((int) dataInputStream.readByte());
				}
			}
			
			return rtad;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public int realTimeAlarmDataInfoStructLenght() {
		int len = 0;
		
		len += 2;
		len += 1;
		len += mBatteryOtherFaultsCnt;
		len += 1;
		len += mMotorFaultsCnt;
		len += 1;
		len += mOtherFaultsCnt;
		
		return len;
	}

}
