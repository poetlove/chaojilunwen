/*************************************************************************
 **
 * File Name		DBManager.java
 * File Summary		DataBase processing
 * Revision			001
 * Author  			Zhu Changliang
 * Date				2015-03-11
 **************************************************************************/
package tted.evdcm.server;

import java.sql.DriverManager;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import tted.evdcm.server.struct.RealTimeAlarmData;
import tted.evdcm.server.struct.RealTimeExtremumData;
import tted.evdcm.server.struct.RealTimeGPSData;
import tted.evdcm.server.struct.RealTimeTemperatureData;
import tted.evdcm.server.struct.RealTimeVehicleData;
import tted.evdcm.server.struct.RealTimeVoltageData;
import tted.evdcm.server.struct.RegistData;
import tted.evdcm.server.struct.StatusData;


public class DBManager {
	static final int MAX_SIZE = 1000;
	
	static Thread_db dbThread = new Thread_db();
	
	static ArrayList<RegistData> mRegistDataList = new ArrayList<RegistData>();
	static ArrayList<StatusData> mStatusDataList = new ArrayList<StatusData>();
	static ArrayList< RealTimeVoltageData > mRealTimeVoltageDataList = new ArrayList< RealTimeVoltageData >();
	static ArrayList< RealTimeAlarmData > mRealTimeAlarmDataList = new ArrayList< RealTimeAlarmData >();

	static ArrayList<RegistData> mRegistDataSleepThreads = new ArrayList<RegistData>();
	
	public static Thread_db getDbThread() {
		return dbThread;
	}
	public static class Thread_db extends Thread {
		public void run() {
			if (dataPoolIsempty()) {
				threadWait();
			}

			int cnt = mRegistDataSleepThreads.size();
			if (cnt > 0) {
				if(mRegistDataList.size() < MAX_SIZE) {
					RegistData rd = mRegistDataSleepThreads.remove(0);
					synchronized (rd) {
						rd.notify();
					}
				}
			}
			
			if (!mRegistDataList.isEmpty()) {
				RegistData registData = mRegistDataList.get(0);
				String cmd = registDataBasicInfoInsert(registData);
				DBInsert(cmd); // �\1
				cmd = registDataBatteryEncodeInsert(registData);
				DBInsert(cmd); // �\2
				cmd = registDataLoginInsert(registData);
				DBInsert(cmd); // �\3
			}

		}
	}
	
	static boolean dataPoolIsempty() {
		if (!mRegistDataList.isEmpty() || !mStatusDataList.isEmpty()) {
			return false;
		}
		return true;
	}
	  

	
	//register 
	static String registDataBasicInfoInsert(RegistData rd) {
		return null;
	}

	static String registDataBatteryEncodeInsert(RegistData rd) {
		return null;
	}

	static String registDataLoginInsert(RegistData rd) {
		return null;
	}

	static String dbManagerRegistDataBasicInfoUpdate(RegistData rd) {
		return null;
	}

	static String registDataBatteryEncodeUpdate(RegistData rd) {
		return null;
	}

	static String registDataLoginUpdate(RegistData rd) {
		return null;
	}

	static String registDataBasicInfoDelete(RegistData rd) {
		return null;
	}

	static String registDataBatteryEncodeDelete(RegistData rd) {
		return null;
	}

	static String registDataLoginDelete(RegistData rd) {
		return null;
	}

	static String registDataBasicInfoQuery(RegistData rd) {
		return null;
	}

	static String registDataBatteryEncodeQuery(RegistData rd) {
		return null;
	}

	static String registDataLoginQuery(RegistData rd) {
		return null;
	}

	

	
	static boolean DBInsert(String cmd) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:microsoft:sqlserver://<server_name>:<1433>", "name",
					"pwd");
			conn.setAutoCommit(false);
			st = conn.createStatement();
			String sqlStr = cmd;
			st.executeUpdate(sqlStr);
			conn.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				// connectManagerDcmSocketClose(st)
				if (conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	static boolean DBUpdate(String cmd) {
		return true;
	}

	static boolean DBDelete(String cmd) {
		return true;
	}

	static boolean DBQuery(String cmd) {
		return true;
	}

	static void threadWait() {
		synchronized (dbThread) {
			try {
				dbThread.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	static void threadNotify() {
		synchronized (dbThread) {
			dbThread.notify();
		}
	}


	
	/**
	 * Save register data to database.
	 * 
	 * @param rd
	 *            register data.
	 * @return true if save data success, else false
	 */
	static public boolean registDataSave(RegistData rd) {
		if(mRegistDataList.size() >= MAX_SIZE) {
			mRegistDataSleepThreads.add(rd);
			synchronized (rd) {
				try {
					rd.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		mRegistDataList.add(rd);
		
		if(!dbThread.isAlive()) {
			threadNotify();
		}
		
		return true;
	}
	
	/**
	 * Save EVDCM's status data to database.
	 * 
	 * @param sd
	 *            EVDCM's status data.
	 * @return true if save data success, else false
	 */
	static public boolean statusDataSave(StatusData sd) {
		return true;
	}
	
	/**
	 * Save EVDCM's real time voltage data to database.
	 * 
	 * @param rtvd
	 *            EVDCM's real time voltage data.
	 * @return true if save data success, else false
	 */
	static public boolean realTimeVoltageDataSave (RealTimeVoltageData rtvd) {
		return true;
	}
	
	/**
	 * Save EVDCM's real time temperature data to database.
	 * 
	 * @param rttd
	 *            EVDCM's real time temperature data.
	 * @return true if save data success, else false
	 */
	static public boolean realTimeTemperatureDataSave (RealTimeTemperatureData rttd) {
		return true;
	}
	
	/**
	 * Save EVDCM's real time vehicle data to database.
	 * 
	 * @param rtvd
	 *            EVDCM's real time vehicle data.
	 * @return true if save data success, else false
	 */
	static public boolean realTimeVehicleDataSave (RealTimeVehicleData rtvd) {
		return true;
	}
	
	/**
	 * Save EVDCM's real time GPS data to database.
	 * 
	 * @param rtgpsd
	 *            EVDCM's real time GPS data.
	 * @return true if save data success, else false
	 */
	static public boolean realTimeGPSDataSave (RealTimeGPSData rtgpsd) {
		return true;
	}
	
	/**
	 * Save EVDCM's real time extremum data to database.
	 * 
	 * @param rted
	 *            EVDCM's real time extremum data.
	 * @return true if save data success, else false
	 */
	static public boolean realTimeExtremumDataSave (RealTimeExtremumData rted) {
		return true;
	}
	
	/**
	 * Save EVDCM's real time alarm data to database.
	 * 
	 * @param rtad
	 *            EVDCM's real time alarm data.
	 * @return true if save data success, else false
	 */
	static public boolean realTimeAlarmDataSave (RealTimeAlarmData rtad) {
		return true;
	}
	
	/**
	 * Get EVDCM's registed data from database.
	 * 
	 * @param srd
	 *            the initial conditions to find registed data.
	 * @param erd
	 *            the end conditions to find registed data.
	 * @return registed data list if get data success, else null
	 */
	static public ArrayList<RegistData> registDataGet(RegistData srd, RegistData erd) {
		return null;
	}
	
	/**
	 * Get EVDCM's status data from database.
	 * 
	 * @param ssd
	 *            the initial conditions to find status data.
	 * @param esd
	 *            the end conditions to find status data.
	 * @return status data list if get data success, else null
	 */
	static public ArrayList<StatusData> statusDataGet(StatusData ssd, StatusData esd) {
		return null;
	}
	
	/**
	 * Get EVDCM's real time voltage data from database.
	 * 
	 * @param srtvd
	 *            the initial conditions to find real time voltage data.
	 * @param ertvd
	 *            the end conditions to find real time voltage data.
	 * @return real time voltage data list if get data success, else null
	 */
	static public ArrayList<RealTimeVoltageData> realTimeVoltageDataGet(RealTimeVoltageData srtvd, RealTimeVoltageData ertvd) {
		return null;
	}
	
	/**
	 * Get EVDCM's real time temperature data from database.
	 * 
	 * @param srttd
	 *            the initial conditions to find real time temperature data.
	 * @param erttd
	 *            the end conditions to find real time temperature data.
	 * @return real time temperature data list if get data success, else null
	 */
	static public ArrayList<RealTimeTemperatureData> realTimeTemperatureDataGet(RealTimeTemperatureData srttd, RealTimeTemperatureData erttd ) {
		return null;
	}
	
	/**
	 * Get EVDCM's real time vehicle data from database.
	 * 
	 * @param srtvd
	 *            the initial conditions to find real time vehicle data.
	 * @param ertvd
	 *            the end conditions to find real time vehicle data.
	 * @return real time vehicle data list if get data success, else null
	 */
	static public ArrayList<RealTimeVehicleData> realTimeVehicleDataGet(RealTimeVehicleData srtvd, RealTimeVehicleData ertvd) {
		return null;
	}
	
	/**
	 * Get EVDCM's real time GPS data from database.
	 * 
	 * @param srtgpsd
	 *            the initial conditions to find real time GPS data.
	 * @param ertgpsd
	 *            the end conditions to find real time GPS data.
	 * @return real time GPS data list if get data success, else null
	 */
	static public ArrayList<RealTimeGPSData> realTimeGPSDataGet (RealTimeGPSData srtgpsd, RealTimeGPSData ertgpsd) {
		return null;
	}
	
	/**
	 * Get EVDCM's real time extremum data from database.
	 * 
	 * @param srted
	 *            the initial conditions to find real time extremum data.
	 * @param erted
	 *            the end conditions to find real time extremum data.
	 * @return real time extremum data list if get data success, else null
	 */
	static public ArrayList<RealTimeExtremumData> realTimeExtremumDataGet (RealTimeExtremumData srted, RealTimeExtremumData erted) {
		return null;
	}
	
	/**
	 * Get EVDCM's real time alarm data from database.
	 * 
	 * @param srtad
	 *            the initial conditions to find real time alarm data.
	 * @param ertad
	 *            the end conditions to find real time alarm data.
	 * @return real time alarm data list if get data success, else null
	 */
	static public ArrayList<RealTimeAlarmData> realTimeExtremumDataGet (RealTimeAlarmData srtad, RealTimeAlarmData ertad) {
		return null;
	}
	
	
}
