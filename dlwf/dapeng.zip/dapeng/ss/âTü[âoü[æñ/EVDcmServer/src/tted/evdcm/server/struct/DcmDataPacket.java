package tted.evdcm.server.struct;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;

public class DcmDataPacket {
	String mStartFlag;
	int mCmdFlag;
	int mResponseFlag;
	String mIdentifier;
	int mRsa;
	int mDataLength;
	byte[] mData;
	int mBcc;
	
	public void setStartFlag(String flag) {
		mStartFlag = flag;
	}
	public String getStartFlag() {
		return mStartFlag;
	}
	public void setCmdFlag(int flag) {
		mCmdFlag = flag;
	}
	public int getCmdFlag() {
		return mCmdFlag;
	}
	public void setResponseFlag(int flag) {
		mResponseFlag = flag;
	}
	public int getResponseFlag() {
		return mResponseFlag;
	}
	public void setIdentifier(String identifier) {
		mIdentifier = identifier;
	}
	public String getIdentifier() {
		return mIdentifier;
	}
	public void setRsa(int rsa) {
		mRsa = rsa;
	}
	public int getRsa() {
		return mRsa;
	}
	public void setDataLength(int len) {
		mDataLength = len;
	}
	public int getDataLength() {
		return mDataLength;
	}
	public void setData(byte[] data) {
		mData = data;
	}
	public byte[] getData() {
		return mData;
	}
	public void setBcc(int bcc) {
		mBcc = bcc;
	}
	public int getBcc() {
		return mBcc;
	}

	static public DcmDataPacket fromBytesToPacket(byte[] byteStream) {
		DcmDataPacket dcmDataPacket = new DcmDataPacket();
		DataInputStream dataInputStream = new DataInputStream(
				new ByteArrayInputStream(byteStream));
		try {
			byte[] tempB = new byte[2];
			dataInputStream.read(tempB, 0, 2);
			dcmDataPacket.mStartFlag = new String(tempB);
			dcmDataPacket.mCmdFlag = dataInputStream.readByte();
			// �c.
			return dcmDataPacket;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	byte[] fromPacketToBytes() {
		int size = 24 + mDataLength + 1;
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(
				size);
		DataOutputStream dataOutputStream = new DataOutputStream(
				byteArrayOutputStream);
		try {
			byte[] tempB = mStartFlag.getBytes();
			dataOutputStream.writeByte(tempB[0]);
			dataOutputStream.writeByte(tempB[1]);
			// �c.
			return byteArrayOutputStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				dataOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
