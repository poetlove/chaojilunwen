package tted.evdcm.server.struct;

public class DataPacket {
	public int mLength = -1;
	public byte[] mData = null;

	public DataPacket() {

	}
	
	public void setLength(int len) {
		mLength = len;
	}
	public int getLength() {
		return mLength;
	}
	public void setData(byte[] data) {
		mData = data;
	}
	public byte[] getData() {
		return mData;
	}
}
