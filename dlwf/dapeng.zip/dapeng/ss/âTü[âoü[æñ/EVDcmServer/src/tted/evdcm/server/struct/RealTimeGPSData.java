package tted.evdcm.server.struct;

public class RealTimeGPSData {
	String mCarNumber;
	String mDateTime;
	int mPositioningState;
	int mLongitude;
	int mLatitude;
	int mSpeed;
	int mDirection;
	Byte[] mReserve;

	static public RealTimeGPSData fromBytesToPacket(String carNumber, byte[] byteStream) {
		return null;
	}

	public byte[] fromPacketToBytes() {
		return null;
	}

}
